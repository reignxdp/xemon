# Xemon Obfuscator

## XVM-1 bytecode backend

The backend now compiles supported Luau source into a custom `XVM1` instruction stream and emits a data-only Lua interpreter. The runtime does not use `load`, `loadstring`, or runtime source compilation.

## Protection

`Xemon Anti-Tamper V2` is integrated before the VM payload. The supplied V2 checks are preserved as the runtime gate.

## Bot

`.obf` still accepts `.lua` / `.txt` attachments and returns `obfuscated_vm.lua`. The Discord embed reports the XVM-1 runtime and Anti-Tamper V2 status.

## Server

`POST /api/obfuscate` keeps the existing response fields and additionally reports:

- `backend: "xvm-1"`
- `anti_tamper: true`
- `loadstring_free: true`

## Scope

The custom compiler covers the practical subset implemented by `backend/bytecode_vm.py`: literals, locals/globals, assignments, table/index access, calls, arithmetic/comparison/logical/unary operators, conditions, loops, function declarations/literals, closures, and returns.


## XVM-3 Pro

The obfuscation pipeline now uses a build-polymorphic XVM-3 bytecode format with randomized opcode IDs, constant/name pool permutation, instruction diversification (NOP/opaque predicates), payload integrity checks, per-build nonce/masking, chunk permutation, and a compact one-line runtime. The VM contains no dynamic source compilation (`load`/`loadstring`).

## XVM-5 Major Update

The obfuscation pipeline is now a multi-stage compiler/VM pipeline: IR optimization, constant/name pool permutation, jump relocation, harmless instruction diversification, per-build opcode randomization, protected constants, build seed + nonce, payload chunk permutation, integrity validation, one-line output, and an XVM5 interpreter. Anti-Tamper V2 is compiled into a separate XVM5 bytecode payload and executed through the same VM instead of being emitted as readable Lua source. Runtime source compilation via `load`/`loadstring` is not used.

The compiler supports the practical Lua/Luau subset implemented by `backend/bytecode_vm.py`.


## XVM-5 Diagnostics

`.config obfuscator debug on` enables stage-by-stage diagnostics during `.obf`. The bot attaches `xemon_obfuscation_report.txt` with preflight, bytecode header checks, generated-Lua validation, host smoke-test results, metrics, and structured errors.

The compiler now rejects unsupported constructs before bytecode emission instead of allowing them to produce runtime `nil`/stack errors. See `BUG_AUDIT.md` for the full audit.
## XVM-5.1 Luau compatibility

The compiler now lowers these common Lua/Luau control-flow features into XVM bytecode: `repeat ... until`, `break`, `continue`, generic `for ... in`, and vararg functions / `...` argument expansion.

The Discord bot now uses separate daily and bonus credit pools, atomic credit reservation, automatic refund on failed obfuscation, per-user history/statistics, premium gift quotas, owner credit administration, and `.ping` / `.about` / `.daily` / `.stats` / `.history` commands.

Daily credits reset at UTC 00:00. Premium and whitelisted users bypass obfuscation consumption.
