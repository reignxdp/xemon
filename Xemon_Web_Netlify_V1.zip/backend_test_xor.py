#!/usr/bin/env python3
"""
Enhanced backend test for Lua Obfuscator API with XOR encryption verification
Tests XOR encryption of anti-tamper strings and code chunks to ensure AI cannot decode them
"""

import requests
import sys
import re
from datetime import datetime

class XORLuaObfuscatorTester:
    def __init__(self, base_url="https://dense-script.preview.emergentagent.com"):
        self.base_url = base_url
        self.api_url = f"{base_url}/api"
        self.tests_run = 0
        self.tests_passed = 0
        self.failed_tests = []
        self.test_results = []
        self.obfuscated_samples = {}

    def log_test(self, name, success, details=""):
        """Log test result"""
        self.tests_run += 1
        if success:
            self.tests_passed += 1
            print(f"✅ {name} - PASSED")
        else:
            print(f"❌ {name} - FAILED: {details}")
            self.failed_tests.append(f"{name}: {details}")
        
        self.test_results.append({
            "test": name,
            "passed": success,
            "details": details
        })
        return success

    def test_api_root(self):
        """Test GET /api/ returns API info"""
        try:
            response = requests.get(f"{self.api_url}/", timeout=10)
            success = response.status_code == 200
            if success:
                data = response.json()
                expected_msg = "Lua Obfuscator API - Extreme Edition"
                success = data.get("message") == expected_msg
                details = f"Response: {data}" if not success else ""
            else:
                details = f"Status: {response.status_code}"
            return self.log_test("API Root", success, details)
        except Exception as e:
            return self.log_test("API Root", False, str(e))

    def test_empty_code_error(self):
        """Test empty code returns 400 error"""
        try:
            response = requests.post(
                f"{self.api_url}/obfuscate",
                json={"code": ""},
                timeout=10
            )
            success = response.status_code == 400
            details = f"Status: {response.status_code}" if not success else ""
            return self.log_test("Empty code error", success, details)
        except Exception as e:
            return self.log_test("Empty code error", False, str(e))

    def test_small_code_obfuscation(self):
        """Test small code produces ~35 KB output and store for XOR tests"""
        small_code = 'print("Hello World")'
        try:
            response = requests.post(
                f"{self.api_url}/obfuscate",
                json={"code": small_code},
                timeout=15
            )
            if response.status_code != 200:
                return self.log_test("Small code obfuscation", False, f"Status: {response.status_code}")
            
            data = response.json()
            obfuscated = data["obfuscated_code"]
            size_kb = len(obfuscated) / 1024
            
            # Store for XOR testing
            self.obfuscated_samples['small'] = obfuscated
            
            # Check size is proportional (30-35 KB for small code)
            size_ok = 25 <= size_kb <= 40
            success = size_ok and len(obfuscated) > len(small_code) * 100
            details = f"Size: {size_kb:.1f} KB"
            
            return self.log_test("Small code obfuscation", success, details)
        except Exception as e:
            return self.log_test("Small code obfuscation", False, str(e))

    def test_complex_code_obfuscation(self):
        """Test complex code with various Lua constructs"""
        complex_code = '''
local players = game:GetService("Players")
local workspace = game:GetService("Workspace")
local part = Instance.new("Part")
part.Name = "TestPart"
part.Parent = workspace
local cf = CFrame.new(0, 10, 0)
part.CFrame = cf
local vector = Vector3.new(1, 2, 3)
print("Complex code test")
'''
        try:
            response = requests.post(
                f"{self.api_url}/obfuscate",
                json={"code": complex_code},
                timeout=20
            )
            if response.status_code != 200:
                return self.log_test("Complex code obfuscation", False, f"Status: {response.status_code}")
            
            data = response.json()
            obfuscated = data["obfuscated_code"]
            
            # Store for XOR testing
            self.obfuscated_samples['complex'] = obfuscated
            
            success = len(obfuscated) > len(complex_code) * 50
            details = f"Size: {len(obfuscated)/1024:.1f} KB"
            
            return self.log_test("Complex code obfuscation", success, details)
        except Exception as e:
            return self.log_test("Complex code obfuscation", False, str(e))

    def test_xor_anti_tamper_strings_encrypted(self):
        """Test that anti-tamper strings are XOR-encrypted (no readable words)"""
        if 'complex' not in self.obfuscated_samples:
            return self.log_test("XOR anti-tamper strings", False, "No complex obfuscated code to test")
        
        code = self.obfuscated_samples['complex']
        
        # These words should NOT appear as readable text in the obfuscated code
        # They should be XOR-encrypted in the anti-tamper string array
        forbidden_words = [
            'CFrame', 'Players', 'math', 'workspace', 'Instance', 'GetService',
            'Vector3', 'RemoteEvent', 'game', 'typeof', 'pcall', 'task',
            'tostring', 'Vector2', 'UDim2', 'Region3int16', 'Vector3int16'
        ]
        
        found_readable = []
        for word in forbidden_words:
            # Check if word appears as readable text (not as byte escapes)
            if word in code:
                # Make sure it's not just part of a comment or variable name
                if re.search(rf'\b{re.escape(word)}\b', code):
                    found_readable.append(word)
        
        success = len(found_readable) == 0
        details = f"Found readable words: {found_readable}" if found_readable else "All anti-tamper strings properly encrypted"
        
        return self.log_test("XOR anti-tamper strings", success, details)

    def test_xor_code_chunks_encrypted(self):
        """Test that user code content is XOR-encrypted (not decodable from byte escapes)"""
        if 'complex' not in self.obfuscated_samples:
            return self.log_test("XOR code chunks", False, "No complex obfuscated code to test")
        
        code = self.obfuscated_samples['complex']
        
        # These user code words should NOT be decodable from byte sequences
        user_code_words = ['print', 'hello', 'TestPart', 'Complex', 'test']
        
        # Extract all byte escape sequences
        byte_sequences = re.findall(r'\\(\d{1,3})', code)
        
        # Try to decode byte sequences as ASCII and look for readable words
        found_decodable = []
        for word in user_code_words:
            word_bytes = [str(ord(c)) for c in word]
            # Check if the word's byte sequence appears consecutively
            word_pattern = ''.join(f'\\{b}' for b in word_bytes)
            if word_pattern in code:
                found_decodable.append(word)
        
        success = len(found_decodable) == 0
        details = f"Found decodable words: {found_decodable}" if found_decodable else "All code chunks properly XOR-encrypted"
        
        return self.log_test("XOR code chunks", success, details)

    def test_xor_decoder_infrastructure(self):
        """Test that XOR decoder infrastructure is present (bit32.bxor, string.byte, string.char)"""
        if 'small' not in self.obfuscated_samples:
            return self.log_test("XOR decoder infrastructure", False, "No obfuscated code to test")
        
        code = self.obfuscated_samples['small']
        
        # Look for the bootstrap entries that should be unencoded
        # These are needed to build the XOR decoder
        bootstrap_words = ['string', 'byte', 'char', 'bit32', 'bxor']
        
        # These should appear as individual character encodings
        infrastructure_present = []
        for word in bootstrap_words:
            # Check if individual characters are present as byte escapes
            chars_found = all(f'\\{ord(c)}' in code for c in word)
            if chars_found:
                infrastructure_present.append(word)
        
        # Should have all 5 bootstrap components
        success = len(infrastructure_present) >= 4  # Allow some variance
        details = f"Found infrastructure: {infrastructure_present}"
        
        return self.log_test("XOR decoder infrastructure", success, details)

    def test_frame_markers_present(self):
        """Test @# frame markers are present in code chunks"""
        if 'small' not in self.obfuscated_samples:
            return self.log_test("Frame markers present", False, "No obfuscated code to test")
        
        code = self.obfuscated_samples['small']
        
        # Look for \64\35 (=@#) and \35\64 (=#@) byte sequences
        prefix_pattern = r'\\64\\35'  # @# prefix
        suffix_pattern = r'\\35\\64'  # #@ suffix
        
        prefix_count = len(re.findall(prefix_pattern, code))
        suffix_count = len(re.findall(suffix_pattern, code))
        
        success = prefix_count > 0 and suffix_count > 0 and prefix_count == suffix_count
        details = f"Prefix markers: {prefix_count}, Suffix markers: {suffix_count}"
        
        return self.log_test("Frame markers present", success, details)

    def test_anti_tamper_checks_count(self):
        """Test all 31 anti-tamper checks are present"""
        if 'small' not in self.obfuscated_samples:
            return self.log_test("Anti-tamper checks count", False, "No obfuscated code to test")
        
        code = self.obfuscated_samples['small']
        
        # Look for anti-tamper check patterns - check for numbers 1-31
        found_checks = set()
        for i in range(1, 32):  # 1-31
            if f'({i})' in code:
                found_checks.add(i)
        
        # Should have most of the 31 checks
        success = len(found_checks) >= 25  # Allow some variance
        details = f"Found {len(found_checks)}/31 anti-tamper checks: {sorted(found_checks)}"
        
        return self.log_test("Anti-tamper checks count", success, details)

    def test_ai_static_analysis_resistance(self):
        """Test that AI cannot perform static analysis on the obfuscated code"""
        if 'complex' not in self.obfuscated_samples:
            return self.log_test("AI static analysis resistance", False, "No complex obfuscated code to test")
        
        code = self.obfuscated_samples['complex']
        
        # Simulate AI static analysis attempts
        analysis_failures = []
        
        # 1. Try to find function calls by looking for readable function names
        lua_functions = ['print', 'pairs', 'ipairs', 'next', 'type', 'getmetatable', 'setmetatable']
        readable_functions = [func for func in lua_functions if func in code]
        if not readable_functions:
            analysis_failures.append("function_names_hidden")
        
        # 2. Try to find string literals by looking for quoted strings
        string_literals = re.findall(r'"([^"\\]|\\.)*"', code)
        readable_strings = [s for s in string_literals if len(s) > 10 and any(c.isalpha() for c in s)]
        if len(readable_strings) < 3:  # Should have very few readable strings
            analysis_failures.append("string_literals_hidden")
        
        # 3. Try to find variable assignments by looking for readable variable names
        # Most variables should be obfuscated with confusing names
        readable_vars = re.findall(r'\b[a-zA-Z][a-zA-Z0-9_]*\s*=', code)
        confusing_vars = [var for var in readable_vars if 'l' in var or 'I' in var or '1' in var]
        if len(confusing_vars) > len(readable_vars) * 0.7:  # Most vars should be confusing
            analysis_failures.append("variable_names_obfuscated")
        
        # 4. Check that control flow is obfuscated
        if 'do' in code and 'end' in code:  # Should have do...end blocks for junk
            analysis_failures.append("control_flow_obfuscated")
        
        success = len(analysis_failures) >= 3  # Should fail most static analysis attempts
        details = f"AI analysis resistance: {analysis_failures}"
        
        return self.log_test("AI static analysis resistance", success, details)

    def test_byte_sequence_gibberish(self):
        """Test that decoding byte sequences produces gibberish, not readable text"""
        if 'complex' not in self.obfuscated_samples:
            return self.log_test("Byte sequence gibberish", False, "No complex obfuscated code to test")
        
        code = self.obfuscated_samples['complex']
        
        # Extract byte escape sequences and try to decode them
        byte_sequences = re.findall(r'\\(\d{1,3})', code)
        
        # Group consecutive byte sequences and try to decode
        gibberish_count = 0
        readable_count = 0
        
        # Take samples of consecutive byte sequences
        for i in range(0, min(len(byte_sequences) - 5, 100), 6):
            try:
                # Take 6 consecutive bytes and try to decode
                byte_group = byte_sequences[i:i+6]
                decoded = ''.join(chr(int(b)) for b in byte_group if int(b) < 128)
                
                # Check if decoded text is readable (contains common English patterns)
                if len(decoded) >= 4:
                    if any(word in decoded.lower() for word in ['the', 'and', 'for', 'are', 'but', 'not', 'you', 'all']):
                        readable_count += 1
                    else:
                        gibberish_count += 1
            except (ValueError, UnicodeDecodeError):
                gibberish_count += 1
        
        # Most decoded sequences should be gibberish
        total_samples = gibberish_count + readable_count
        success = total_samples > 0 and (gibberish_count / total_samples) > 0.8
        details = f"Gibberish: {gibberish_count}, Readable: {readable_count}, Total: {total_samples}"
        
        return self.log_test("Byte sequence gibberish", success, details)

    def run_all_tests(self):
        """Run all tests and return summary"""
        print("🚀 Starting Enhanced XOR Lua Obfuscator Backend Tests")
        print("=" * 60)
        
        # Basic API tests
        self.test_api_root()
        self.test_empty_code_error()
        
        # Obfuscation functionality tests
        self.test_small_code_obfuscation()
        self.test_complex_code_obfuscation()
        
        # XOR encryption tests
        self.test_xor_anti_tamper_strings_encrypted()
        self.test_xor_code_chunks_encrypted()
        self.test_xor_decoder_infrastructure()
        
        # Frame marker and anti-tamper tests
        self.test_frame_markers_present()
        self.test_anti_tamper_checks_count()
        
        # AI resistance tests
        self.test_ai_static_analysis_resistance()
        self.test_byte_sequence_gibberish()
        
        print("=" * 60)
        print(f"📊 Test Results: {self.tests_passed}/{self.tests_run} passed")
        
        if self.tests_passed == self.tests_run:
            print("🎉 All XOR encryption tests passed!")
            return True
        else:
            print("❌ Some tests failed")
            for failure in self.failed_tests:
                print(f"  - {failure}")
            return False

def main():
    tester = XORLuaObfuscatorTester()
    success = tester.run_all_tests()
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())