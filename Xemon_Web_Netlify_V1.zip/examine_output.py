import requests

# Get a sample obfuscated output to examine
url = "https://integrity-validator.preview.emergentagent.com/api/obfuscate"
response = requests.post(url, json={"code": 'print("test")'})

if response.status_code == 200:
    data = response.json()
    obfuscated = data['obfuscated_code']
    
    # Save first 5000 characters to examine structure
    print("First 5000 characters of obfuscated output:")
    print("=" * 50)
    print(obfuscated[:5000])
    print("=" * 50)
    
    # Look for patterns that might indicate check calls
    import re
    
    # Look for function call patterns with numbers
    patterns = [
        r'(\w+)\((\d+)\)',  # any function call with number
        r'(\w+)\((\d{1,3})\)',  # function calls with 1-3 digit numbers
    ]
    
    for pattern in patterns:
        matches = re.findall(pattern, obfuscated)
        if matches:
            print(f"\nFunction calls with numbers (pattern: {pattern}):")
            # Show unique function names and their number arguments
            unique_calls = {}
            for func, num in matches:
                if func not in unique_calls:
                    unique_calls[func] = []
                if int(num) not in unique_calls[func]:
                    unique_calls[func].append(int(num))
            
            for func, nums in unique_calls.items():
                if len(nums) > 5:  # Only show functions called with many different numbers
                    print(f"  {func}: {sorted(nums)[:20]}...")  # Show first 20 numbers
                elif any(n in [1,2,3,4,5,101,102] for n in nums):  # Or if it contains our target numbers
                    print(f"  {func}: {sorted(nums)}")
    
    # Look for specific check-related patterns
    check_indicators = ['pcall', 'error', 'CFrame', 'Vector3', 'game', 'workspace']
    print(f"\nCheck indicators found:")
    for indicator in check_indicators:
        count = obfuscated.count(indicator)
        print(f"  {indicator}: {count} occurrences")
        
else:
    print(f"Error: {response.status_code} - {response.text}")