#!/usr/bin/env python3

import requests
import re

def test_detailed_noise_analysis():
    """Detailed analysis of noise characters in obfuscated output"""
    
    base_url = "https://dense-script.preview.emergentagent.com"
    api_url = f"{base_url}/api"
    
    # Test with small code
    test_code = 'print("Test")'
    
    print(f"🔍 Testing detailed noise analysis for small code: {test_code}")
    print(f"Original code length: {len(test_code)} characters")
    
    try:
        response = requests.post(
            f"{api_url}/obfuscate",
            json={"code": test_code},
            headers={'Content-Type': 'application/json'}
        )
        
        if response.status_code != 200:
            print(f"❌ API call failed: {response.status_code}")
            return
            
        data = response.json()
        obfuscated = data['obfuscated_code']
        
        print(f"Obfuscated code length: {len(obfuscated)} characters ({len(obfuscated)/1024:.1f} KB)")
        
        # Count individual noise characters
        noise_chars = {
            '@': obfuscated.count('@'),
            '#': obfuscated.count('#'),
            '!': obfuscated.count('!'),
            '$': obfuscated.count('$'),
            '%': obfuscated.count('%'),
            '^': obfuscated.count('^'),
            '&': obfuscated.count('&'),
            '*': obfuscated.count('*'),
            '~': obfuscated.count('~'),
            '<': obfuscated.count('<'),
            '>': obfuscated.count('>'),
            '|': obfuscated.count('|'),
        }
        
        print("\n📊 Individual noise character counts:")
        for char, count in noise_chars.items():
            print(f"  {char}: {count}")
        
        # Calculate totals
        at_hash_total = noise_chars['@'] + noise_chars['#']
        all_noise_total = sum(noise_chars.values())
        
        print(f"\n📈 Summary:")
        print(f"  @# characters: {at_hash_total}")
        print(f"  All noise characters: {all_noise_total}")
        
        # Check requirements
        print(f"\n✅ Requirements check:")
        print(f"  @# chars >= 5000: {'✅' if at_hash_total >= 5000 else '❌'} ({at_hash_total}/5000)")
        print(f"  All noise >= 10000: {'✅' if all_noise_total >= 10000 else '❌'} ({all_noise_total}/10000)")
        
        # Analyze noise comment patterns
        print(f"\n🔍 Noise comment analysis:")
        
        # Pattern 1: --[[@#...@#]]
        pattern1 = r'--\[\[@#.*?@#\]\]'
        matches1 = re.findall(pattern1, obfuscated, re.DOTALL)
        print(f"  --[[@#...@#]] patterns: {len(matches1)}")
        
        # Pattern 2: --!@#...@#!
        pattern2 = r'--!@#.*?@#!'
        matches2 = re.findall(pattern2, obfuscated, re.DOTALL)
        print(f"  --!@#...@#! patterns: {len(matches2)}")
        
        # Pattern 3: Any comment with @#
        pattern3 = r'--.*?@#.*?(?=\n|$)'
        matches3 = re.findall(pattern3, obfuscated, re.DOTALL)
        print(f"  Comments with @#: {len(matches3)}")
        
        # Count @# in comments specifically
        comment_at_hash = 0
        for match in matches1 + matches2:
            comment_at_hash += match.count('@') + match.count('#')
        
        print(f"  @# chars in comments: {comment_at_hash}")
        print(f"  @# chars outside comments: {at_hash_total - comment_at_hash}")
        
        # Test with 5000+ character code to verify scaling
        print(f"\n🔍 Testing large code scaling...")
        large_code = 'print("This is a large test code.") ' * 200  # ~5000+ chars
        print(f"Large code length: {len(large_code)} characters")
        
        large_response = requests.post(
            f"{api_url}/obfuscate",
            json={"code": large_code},
            headers={'Content-Type': 'application/json'}
        )
        
        if large_response.status_code == 200:
            large_data = large_response.json()
            large_obfuscated = large_data['obfuscated_code']
            large_kb = len(large_obfuscated) / 1024
            
            print(f"Large obfuscated length: {len(large_obfuscated)} characters ({large_kb:.1f} KB)")
            print(f"Scaling ratio: {large_kb / (len(obfuscated)/1024):.1f}x")
            print(f"Meets 200+ KB requirement: {'✅' if large_kb >= 200 else '❌'}")
            
            # Count noise in large code
            large_at_hash = large_obfuscated.count('@') + large_obfuscated.count('#')
            print(f"Large code @# characters: {large_at_hash}")
        else:
            print(f"❌ Large code test failed: {large_response.status_code}")
            
    except Exception as e:
        print(f"❌ Error: {str(e)}")

if __name__ == "__main__":
    test_detailed_noise_analysis()