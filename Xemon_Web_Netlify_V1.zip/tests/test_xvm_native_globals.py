from pathlib import Path
VM = Path(__file__).resolve().parents[1] / "backend" / "bytecode_vm.py"
def test_runtime_has_builtin_global_fallback():
    src=VM.read_text(encoding="utf-8")
    assert "local _builtins={" in src
    assert "local b=_builtins[key]" in src
    assert "print=print" in src
def test_getv_prefers_env_and_g_then_builtins():
    src=VM.read_text(encoding="utf-8")
    assert src.index('if type(_G)=="table"') < src.index("local b=_builtins[key]")

