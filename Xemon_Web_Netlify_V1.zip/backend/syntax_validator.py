"""Lightweight Lua/Luau output validator for Xemon generated source.
It focuses on syntax hazards introduced by code generation and one-line packing,
especially tokens that are not valid in Lua 5.1-compatible parsers.
"""

PAIR = {'(': ')', '[': ']', '{': '}'}


def validate_generated_lua(source: str) -> None:
    if '\x00' in source:
        raise SyntaxError('generated Lua contains NUL byte')
    if not source.strip():
        raise SyntaxError('generated Lua is empty')

    stack = []
    i = 0
    n = len(source)
    state = 'code'
    quote = None
    while i < n:
        c = source[i]
        if state == 'code':
            if source.startswith('--[[', i):
                state = 'long_comment'; i += 4; continue
            if source.startswith('--', i):
                state = 'line_comment'; i += 2; continue
            if c in ('"', "'"):
                quote = c; state = 'string'; i += 1; continue
            if c in PAIR:
                stack.append((c, i)); i += 1; continue
            if c in PAIR.values():
                if not stack or PAIR[stack[-1][0]] != c:
                    raise SyntaxError(f'unbalanced delimiter {c!r} at {i}')
                stack.pop(); i += 1; continue

            # Lua 5.1 does not support the Luau/Lua-5.3 bitwise single '~'.
            if c == '~' and (i + 1 >= n or source[i + 1] != '='):
                raise SyntaxError(f'unsupported bare bitwise ~ at {i}')
            if c == '&' or c == '|':
                raise SyntaxError(f'unsupported bitwise operator {c!r} at {i}')
            if source.startswith('<<', i) or source.startswith('>>', i) or source.startswith('//', i):
                raise SyntaxError(f'unsupported operator at {i}')
            i += 1; continue

        if state == 'string':
            if c == '\\':
                i += 2; continue
            if c == quote:
                state = 'code'; quote = None
            i += 1; continue

        if state == 'line_comment':
            if c == '\n' or c == '\r':
                state = 'code'
            i += 1; continue

        if state == 'long_comment':
            if source.startswith(']]', i):
                state = 'code'; i += 2; continue
            i += 1

    if state == 'string':
        raise SyntaxError('unterminated string literal')
    if state == 'long_comment':
        raise SyntaxError('unterminated long comment')
    if stack:
        opener, pos = stack[-1]
        raise SyntaxError(f'unclosed delimiter {opener!r} at {pos}')
