import asyncio
import io
import json
import logging
import os
import time
from datetime import datetime, timezone
from pathlib import Path

import discord
from discord.ext import commands
from dotenv import load_dotenv

from lua_obfuscator import LuaObfuscator

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger("xemon-bot")

DISCORD_TOKEN = os.environ.get("DISCORD_BOT_TOKEN")
if not DISCORD_TOKEN:
    raise RuntimeError("DISCORD_BOT_TOKEN is missing from backend/.env")

FREE_DAILY_CREDITS = 6
PREMIUM_GIFT_DAILY = 25
MAX_GIFT = 25
MAX_FILE_BYTES = 512 * 1024
HISTORY_LIMIT = 12
WHITELISTED_ROLE = "WHITELISTED"
PREMIUM_ROLE = "PREMIUM"
DEFAULT_ANTI_TAMPER = True
DEFAULT_ANTI_TAMPER_DEBUG = False
DEFAULT_ANTI_TAMPER_STRICT = False
DEFAULT_OBFUSCATOR_DEBUG = False
WHITELIST_USER_IDS = {1351998310306549760}
OWNER_IDS = {1351998310306549760}

DATA_FILE = ROOT_DIR / "xemon_data.json"
DATA_LOCK = asyncio.Lock()
DATA_TEMPLATE = {"version": 2, "credits": {}, "config": {}}


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def today_key() -> str:
    return utc_now().date().isoformat()


def _load_data_sync():
    if not DATA_FILE.exists():
        return json.loads(json.dumps(DATA_TEMPLATE))
    try:
        data = json.loads(DATA_FILE.read_text(encoding="utf-8"))
    except Exception:
        logger.exception("Could not read xemon_data.json; starting from empty data")
        return json.loads(json.dumps(DATA_TEMPLATE))
    if not isinstance(data, dict):
        data = {}
    data.setdefault("version", 2)
    data.setdefault("credits", {})
    data.setdefault("config", {})
    return data


def _save_data_sync(data):
    tmp = DATA_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(DATA_FILE)


async def read_data():
    async with DATA_LOCK:
        return _load_data_sync()


async def mutate_data(mutator):
    async with DATA_LOCK:
        data = _load_data_sync()
        result = mutator(data)
        _save_data_sync(data)
        return result


def _new_user_doc(user_id: int):
    now = utc_now().isoformat()
    return {
        "user_id": str(user_id),
        "daily_used": 0,
        "bonus_credits": 0,
        "last_reset": today_key(),
        "gift_used": 0,
        "last_gift_reset": today_key(),
        "successful_obfuscations": 0,
        "failed_obfuscations": 0,
        "total_input_chars": 0,
        "total_output_chars": 0,
        "created_at": now,
        "history": [],
    }


def _normalize_user(doc, user_id: int):
    if not isinstance(doc, dict):
        doc = _new_user_doc(user_id)
    # Migrate the old single-counter schema without losing earned bonus credits.
    if "daily_used" not in doc:
        doc["daily_used"] = int(doc.get("credits_used", 0) or 0)
    doc.pop("credits_used", None)
    doc.setdefault("bonus_credits", 0)
    doc.setdefault("last_reset", today_key())
    doc.setdefault("gift_used", 0)
    doc.setdefault("last_gift_reset", today_key())
    doc.setdefault("successful_obfuscations", 0)
    doc.setdefault("failed_obfuscations", 0)
    doc.setdefault("total_input_chars", 0)
    doc.setdefault("total_output_chars", 0)
    doc.setdefault("created_at", utc_now().isoformat())
    doc.setdefault("history", [])
    if not isinstance(doc["history"], list):
        doc["history"] = []
    return doc


def _reset_daily_fields(doc):
    today = today_key()
    changed = False
    if doc.get("last_reset") != today:
        doc["daily_used"] = 0
        doc["last_reset"] = today
        changed = True
    if doc.get("last_gift_reset") != today:
        doc["gift_used"] = 0
        doc["last_gift_reset"] = today
        changed = True
    return changed


def get_remaining_from_doc(doc):
    daily = max(0, FREE_DAILY_CREDITS - int(doc.get("daily_used", 0)))
    bonus = max(0, int(doc.get("bonus_credits", 0)))
    return daily + bonus


async def get_user_credits(user_id):
    def mutate(data):
        key = str(user_id)
        doc = _normalize_user(data["credits"].get(key), user_id)
        _reset_daily_fields(doc)
        data["credits"][key] = doc
        return dict(doc)
    return await mutate_data(mutate)


async def reserve_credit(user_id):
    """Atomically reserve one credit. Returns a charge receipt or None."""
    def mutate(data):
        key = str(user_id)
        doc = _normalize_user(data["credits"].get(key), user_id)
        _reset_daily_fields(doc)
        if doc["daily_used"] < FREE_DAILY_CREDITS:
            doc["daily_used"] += 1
            source = "daily"
        elif doc["bonus_credits"] > 0:
            doc["bonus_credits"] -= 1
            source = "bonus"
        else:
            return None
        data["credits"][key] = doc
        return {"source": source, "user_id": str(user_id)}
    return await mutate_data(mutate)


async def refund_credit(user_id, receipt):
    if not receipt:
        return
    def mutate(data):
        key = str(user_id)
        doc = _normalize_user(data["credits"].get(key), user_id)
        _reset_daily_fields(doc)
        if receipt.get("source") == "daily" and doc["daily_used"] > 0:
            doc["daily_used"] -= 1
        else:
            doc["bonus_credits"] += 1
        data["credits"][key] = doc
    await mutate_data(mutate)


async def record_obfuscation(user_id, *, success, filename, input_chars=0, output_chars=0, error=None):
    def mutate(data):
        key = str(user_id)
        doc = _normalize_user(data["credits"].get(key), user_id)
        _reset_daily_fields(doc)
        now = utc_now().isoformat()
        if success:
            doc["successful_obfuscations"] += 1
            doc["total_input_chars"] += int(input_chars)
            doc["total_output_chars"] += int(output_chars)
        else:
            doc["failed_obfuscations"] += 1
        doc["history"].append({
            "timestamp": now,
            "success": bool(success),
            "filename": filename[:120],
            "input_chars": int(input_chars),
            "output_chars": int(output_chars),
            "error": (str(error)[:240] if error else None),
        })
        doc["history"] = doc["history"][-HISTORY_LIMIT:]
        data["credits"][key] = doc
    await mutate_data(mutate)


async def add_bonus_credits(user_id, amount):
    amount = int(amount)
    if amount <= 0:
        raise ValueError("amount must be positive")
    def mutate(data):
        key = str(user_id)
        doc = _normalize_user(data["credits"].get(key), user_id)
        _reset_daily_fields(doc)
        doc["bonus_credits"] += amount
        data["credits"][key] = doc
        return dict(doc)
    return await mutate_data(mutate)


async def gift_credit(user_id, target_id, amount, unlimited=False):
    amount = int(amount)
    if amount < 1 or amount > MAX_GIFT:
        raise ValueError(f"Gift amount must be between 1 and {MAX_GIFT}.")
    def mutate(data):
        source = _normalize_user(data["credits"].get(str(user_id)), user_id)
        target = _normalize_user(data["credits"].get(str(target_id)), target_id)
        _reset_daily_fields(source)
        _reset_daily_fields(target)
        if not unlimited:
            remaining = PREMIUM_GIFT_DAILY - int(source["gift_used"])
            if amount > remaining:
                raise ValueError(f"You have {max(0, remaining)} gift credits left today.")
            source["gift_used"] += amount
        target["bonus_credits"] += amount
        source_key = str(user_id)
        data["credits"][source_key] = source
        data["credits"][str(target_id)] = target
        return target["bonus_credits"], (FREE_DAILY_CREDITS - source["daily_used"]), source["bonus_credits"], source["gift_used"]
    return await mutate_data(mutate)


def has_role(member, role_name):
    return any(r.name.upper() == role_name.upper() for r in getattr(member, "roles", []))


def is_whitelisted_user(member):
    return member.id in WHITELIST_USER_IDS or has_role(member, WHITELISTED_ROLE)


def is_config_owner():
    async def predicate(ctx):
        if ctx.author.id in OWNER_IDS:
            return True
        return await ctx.bot.is_owner(ctx.author)
    return commands.check(predicate)


async def get_guild_config(guild_id):
    if guild_id is None:
        return {}
    data = await read_data()
    return dict(data["config"].get(str(guild_id), {}))


async def _set_guild_config(guild_id, key, value):
    def mutate(data):
        data["config"].setdefault(str(guild_id), {})[key] = value
    await mutate_data(mutate)


async def get_anti_tamper_enabled(guild_id):
    cfg = await get_guild_config(guild_id)
    return bool(cfg.get("anti_tamper", DEFAULT_ANTI_TAMPER))

async def get_anti_tamper_debug(guild_id):
    cfg = await get_guild_config(guild_id)
    return bool(cfg.get("anti_tamper_debug", DEFAULT_ANTI_TAMPER_DEBUG))

async def get_anti_tamper_strict(guild_id):
    cfg = await get_guild_config(guild_id)
    return bool(cfg.get("anti_tamper_strict", DEFAULT_ANTI_TAMPER_STRICT))

async def get_obfuscator_debug(guild_id):
    cfg = await get_guild_config(guild_id)
    return bool(cfg.get("obfuscator_debug", DEFAULT_OBFUSCATOR_DEBUG))


intents = discord.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix=".", intents=intents, help_command=None)


@bot.event
async def on_ready():
    logger.info("xemon bot online as %s (ID: %s)", bot.user, bot.user.id)
    await bot.change_presence(activity=discord.Game(name=".obf | XVM-5 Xemon"))


@bot.command(name="obf", aliases=["obfuscate"])
@commands.cooldown(1, 3, commands.BucketType.user)
async def obfuscate_cmd(ctx):
    if not ctx.message.attachments:
        await ctx.reply("📎 `.lua` veya `.txt` dosyasını mesaja ekleyip `.obf` yaz.")
        return
    attachment = ctx.message.attachments[0]
    filename = attachment.filename
    lower = filename.lower()
    if not lower.endswith((".lua", ".txt")):
        await ctx.reply("❌ Sadece `.lua` ve `.txt` dosyaları destekleniyor.")
        return
    if attachment.size > MAX_FILE_BYTES:
        await ctx.reply(f"❌ Dosya çok büyük. Maksimum boyut: **{MAX_FILE_BYTES // 1024} KB**.")
        return

    member = ctx.author
    privileged = is_whitelisted_user(member) or has_role(member, PREMIUM_ROLE)
    receipt = None
    if not privileged:
        receipt = await reserve_credit(member.id)
        if receipt is None:
            doc = await get_user_credits(member.id)
            await ctx.reply(
                f"⛔ Kredin bitti. Günlük: **{FREE_DAILY_CREDITS}**, bonus: **{doc.get('bonus_credits', 0)}**.\n"
                "Yeni gün UTC 00:00'da günlük hak yenilenir."
            )
            return

    try:
        file_bytes = await attachment.read()
        code = file_bytes.decode("utf-8-sig")
        if not code.strip():
            raise ValueError("Dosya boş.")
        if len(code) > 1_000_000:
            raise ValueError("Kaynak kod maksimum 1,000,000 karakter olabilir.")
    except Exception as exc:
        await refund_credit(member.id, receipt)
        await record_obfuscation(member.id, success=False, filename=filename, error=exc)
        await ctx.reply(f"❌ Dosya okunamadı: `{str(exc)[:180]}`")
        return

    processing = await ctx.reply("⏳ XVM-5 derleniyor ve korunuyor...")
    started = time.perf_counter()
    diagnostic = None
    anti_tamper_enabled = await get_anti_tamper_enabled(ctx.guild.id if ctx.guild else None)
    anti_tamper_debug = await get_anti_tamper_debug(ctx.guild.id if ctx.guild else None)
    anti_tamper_strict = await get_anti_tamper_strict(ctx.guild.id if ctx.guild else None)
    obfuscator_debug = await get_obfuscator_debug(ctx.guild.id if ctx.guild else None)

    try:
        obfuscator = LuaObfuscator()
        if obfuscator_debug:
            result, diagnostic = obfuscator.obfuscate_with_report(
                code,
                include_anti_tamper=anti_tamper_enabled,
                anti_tamper_debug=anti_tamper_debug,
                anti_tamper_strict=anti_tamper_strict,
                run_host_smoke=True,
            )
            if result is None:
                raise ValueError(diagnostic.to_text()[-3500:])
        else:
            result = obfuscator.obfuscate(
                code,
                include_anti_tamper=anti_tamper_enabled,
                anti_tamper_debug=anti_tamper_debug,
                anti_tamper_strict=anti_tamper_strict,
            )
    except Exception as exc:
        await refund_credit(member.id, receipt)
        await record_obfuscation(member.id, success=False, filename=filename, input_chars=len(code), error=exc)
        logger.exception("Obfuscation failure for %s", member.id)
        await processing.edit(content=f"❌ Obfuscation başarısız. Kredi iade edildi.\n`{str(exc)[:600]}`")
        return

    elapsed = time.perf_counter() - started
    await record_obfuscation(
        member.id, success=True, filename=filename,
        input_chars=len(code), output_chars=len(result),
    )

    if privileged:
        credit_text = "Unlimited"
    else:
        doc = await get_user_credits(member.id)
        credit_text = f"{get_remaining_from_doc(doc)}/{FREE_DAILY_CREDITS + doc.get('bonus_credits', 0)}"

    output_file = discord.File(io.BytesIO(result.encode("utf-8")), filename="obfuscated_vm.lua")
    attachments = [output_file]
    if diagnostic is not None:
        attachments.append(discord.File(io.BytesIO(diagnostic.to_text().encode("utf-8")), filename="xemon_report.txt"))

    embed = discord.Embed(title="✅ Xemon obfuscation complete", color=0x00FF88)
    embed.add_field(name="Input", value=f"`{len(code):,}` chars", inline=True)
    embed.add_field(name="Output", value=f"`{len(result):,}` chars", inline=True)
    embed.add_field(name="Time", value=f"`{elapsed:.2f}s`", inline=True)
    embed.add_field(name="Anti-Tamper", value="ON" if anti_tamper_enabled else "OFF", inline=True)
    embed.add_field(name="XVM", value="XVM-5 / Luau extended", inline=True)
    embed.add_field(name="Credit", value=credit_text, inline=True)
    embed.set_footer(text="Failed jobs automatically refund the reserved credit.")
    await processing.edit(content=None, embed=embed, attachments=attachments)


@bot.command(name="credits", aliases=["balance", "bal"])
async def credits_cmd(ctx):
    member = ctx.author
    if is_whitelisted_user(member) or has_role(member, PREMIUM_ROLE):
        role = WHITELISTED_ROLE if is_whitelisted_user(member) else PREMIUM_ROLE
        doc = await get_user_credits(member.id)
        embed = discord.Embed(title="💳 Xemon Credits", color=0x00FF88)
        embed.add_field(name="Status", value=f"**{role}** / Unlimited obfuscation", inline=False)
        if role == PREMIUM_ROLE:
            gift_left = max(0, PREMIUM_GIFT_DAILY - doc.get("gift_used", 0))
            embed.add_field(name="Gift quota", value=f"**{gift_left}/{PREMIUM_GIFT_DAILY}** today", inline=True)
        embed.add_field(name="Lifetime", value=f"Success: **{doc.get('successful_obfuscations', 0)}**\nFailed: **{doc.get('failed_obfuscations', 0)}**", inline=True)
    else:
        doc = await get_user_credits(member.id)
        daily = max(0, FREE_DAILY_CREDITS - doc.get("daily_used", 0))
        bonus = max(0, doc.get("bonus_credits", 0))
        embed = discord.Embed(title="💳 Xemon Credits", color=0x00FF88)
        embed.add_field(name="Daily", value=f"**{daily}/{FREE_DAILY_CREDITS}**", inline=True)
        embed.add_field(name="Bonus", value=f"**{bonus}**", inline=True)
        embed.add_field(name="Total available", value=f"**{daily + bonus}**", inline=True)
        embed.add_field(name="Usage", value=f"Success: **{doc.get('successful_obfuscations', 0)}**\nFailed: **{doc.get('failed_obfuscations', 0)}**", inline=True)
        embed.set_footer(text="Daily credits reset at UTC 00:00.")
    await ctx.reply(embed=embed)


@bot.command(name="daily")
async def daily_cmd(ctx):
    doc = await get_user_credits(ctx.author.id)
    if is_whitelisted_user(ctx.author) or has_role(ctx.author, PREMIUM_ROLE):
        await ctx.reply("✅ Premium/whitelisted üyelerde obfuscation limiti yok.")
        return
    daily = max(0, FREE_DAILY_CREDITS - doc.get("daily_used", 0))
    await ctx.reply(f"🎁 Günlük kredin: **{daily}/{FREE_DAILY_CREDITS}**. Yenilenme: **UTC 00:00**.")


@bot.command(name="stats")
async def stats_cmd(ctx, target: discord.Member = None):
    target = target or ctx.author
    doc = await get_user_credits(target.id)
    success = int(doc.get("successful_obfuscations", 0))
    failed = int(doc.get("failed_obfuscations", 0))
    total = success + failed
    rate = (success / total * 100) if total else 0
    embed = discord.Embed(title=f"📊 {target.display_name} Stats", color=0x5865F2)
    embed.set_thumbnail(url=target.display_avatar.url)
    embed.add_field(name="Successful", value=f"**{success}**", inline=True)
    embed.add_field(name="Failed", value=f"**{failed}**", inline=True)
    embed.add_field(name="Success rate", value=f"**{rate:.1f}%**", inline=True)
    embed.add_field(name="Input chars", value=f"{doc.get('total_input_chars', 0):,}", inline=True)
    embed.add_field(name="Output chars", value=f"{doc.get('total_output_chars', 0):,}", inline=True)
    await ctx.reply(embed=embed)


@bot.command(name="history")
async def history_cmd(ctx):
    doc = await get_user_credits(ctx.author.id)
    rows = doc.get("history", [])[-8:]
    if not rows:
        await ctx.reply("Henüz işlem geçmişin yok.")
        return
    lines = []
    for row in reversed(rows):
        ts = row.get("timestamp", "").replace("T", " ")[:16]
        mark = "✅" if row.get("success") else "❌"
        lines.append(f"{mark} `{ts}` · `{row.get('filename','unknown')[:36]}` · {row.get('input_chars',0):,} → {row.get('output_chars',0):,}")
    embed = discord.Embed(title="🧾 Xemon History", description="\n".join(lines), color=0x5865F2)
    await ctx.reply(embed=embed)


@bot.command(name="gift")
async def gift_cmd(ctx, target: discord.Member = None, amount: int = 1):
    member = ctx.author
    premium = has_role(member, PREMIUM_ROLE)
    owner = member.id in OWNER_IDS or await bot.is_owner(member)
    if not premium and not owner:
        await ctx.reply("⛔ `.gift` sadece PREMIUM veya bot owner içindir.")
        return
    if not target or target.bot or target.id == member.id:
        await ctx.reply(f"Kullanım: `.gift @user [1-{MAX_GIFT}]`")
        return
    try:
        _, _, _, gift_used = await gift_credit(member.id, target.id, amount, unlimited=owner)
    except ValueError as exc:
        await ctx.reply(f"❌ {exc}")
        return
    left = "unlimited" if owner else str(max(0, PREMIUM_GIFT_DAILY - gift_used))
    await ctx.reply(f"🎁 {member.mention} → {target.mention}: **{amount}** bonus kredi. Kalan gift kotası: **{left}**")


@bot.command(name="setcredits")
@is_config_owner()
async def setcredits_cmd(ctx, target: discord.Member = None, amount: int = None):
    if not target or amount is None or amount < -100000 or amount > 100000:
        await ctx.reply("Kullanım: `.setcredits @user 10` (negatif değer bonus krediden düşer)")
        return
    doc = await get_user_credits(target.id)
    current = int(doc.get("bonus_credits", 0))
    new_value = max(0, current + amount)
    def mutate(data):
        d = _normalize_user(data["credits"].get(str(target.id)), target.id)
        _reset_daily_fields(d)
        d["bonus_credits"] = new_value
        data["credits"][str(target.id)] = d
    await mutate_data(mutate)
    await ctx.reply(f"✅ {target.mention} bonus kredisi: **{new_value}**")


@bot.command(name="resetcredits")
@is_config_owner()
async def resetcredits_cmd(ctx, target: discord.Member = None):
    if not target:
        await ctx.reply("Kullanım: `.resetcredits @user`")
        return
    def mutate(data):
        data["credits"][str(target.id)] = _new_user_doc(target.id)
    await mutate_data(mutate)
    await ctx.reply(f"♻️ {target.mention} kredi hesabı sıfırlandı.")


@bot.command(name="config")
@is_config_owner()
async def config_cmd(ctx, setting: str = None, value: str = None, value2: str = None):
    if not ctx.guild:
        await ctx.reply("`.config` yalnızca sunucuda kullanılabilir.")
        return
    cfg = await get_guild_config(ctx.guild.id)
    if setting is None:
        embed = discord.Embed(title="⚙️ Xemon Config", color=0x5865F2)
        embed.add_field(name="Anti-Tamper", value="ON" if cfg.get("anti_tamper", DEFAULT_ANTI_TAMPER) else "OFF", inline=True)
        embed.add_field(name="AT Debug", value="ON" if cfg.get("anti_tamper_debug", DEFAULT_ANTI_TAMPER_DEBUG) else "OFF", inline=True)
        embed.add_field(name="AT Strict", value="ON" if cfg.get("anti_tamper_strict", DEFAULT_ANTI_TAMPER_STRICT) else "OFF", inline=True)
        embed.add_field(name="Obfuscator Debug", value="ON" if cfg.get("obfuscator_debug", DEFAULT_OBFUSCATOR_DEBUG) else "OFF", inline=True)
        embed.set_footer(text=".config antitamper|atdebug|strict|obfdebug on|off")
        await ctx.reply(embed=embed)
        return
    key = setting.lower().replace("-", "_")
    aliases = {"antitamper": "anti_tamper", "atdebug": "anti_tamper_debug", "obfdebug": "obfuscator_debug", "strict": "anti_tamper_strict"}
    key = aliases.get(key, key)
    if key not in {"anti_tamper", "anti_tamper_debug", "anti_tamper_strict", "obfuscator_debug"}:
        await ctx.reply("❌ Bilinmeyen ayar.")
        return
    if value and value.lower() in {"on", "off"}:
        await _set_guild_config(ctx.guild.id, key, value.lower() == "on")
        await ctx.reply(f"✅ `{key}` = **{value.upper()}**")
    else:
        await ctx.reply(f"Kullanım: `.config {setting} on|off`")


@bot.command(name="ping")
async def ping_cmd(ctx):
    await ctx.reply(f"🏓 **{round(bot.latency * 1000)}ms**")


@bot.command(name="about")
async def about_cmd(ctx):
    embed = discord.Embed(title="Xemon XVM-5", description="Roblox/Luau odaklı bytecode obfuscator + Anti-Tamper + Discord automation.", color=0x00FF88)
    embed.add_field(name="Language", value="Lua + extended Luau control flow", inline=True)
    embed.add_field(name="VM", value="XVM-5 protected bytecode", inline=True)
    embed.add_field(name="Credits", value="Atomic daily + bonus pool", inline=True)
    await ctx.reply(embed=embed)


@bot.command(name="help")
async def help_cmd(ctx):
    embed = discord.Embed(title="🛡️ Xemon Help", color=0x00FF88)
    embed.add_field(name="Core", value="`.obf` · `.credits` · `.daily` · `.stats [@user]` · `.history` · `.about` · `.ping`", inline=False)
    embed.add_field(name="Premium", value=f"`.gift @user [1-{MAX_GIFT}]` · PREMIUM günlük **{PREMIUM_GIFT_DAILY}** gift kotası", inline=False)
    embed.add_field(name="Owner", value="`.setcredits @user amount` · `.resetcredits @user` · `.config ...`", inline=False)
    embed.set_footer(text="Failed obfuscation jobs refund the reserved credit automatically.")
    await ctx.reply(embed=embed)


@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandOnCooldown):
        await ctx.reply(f"⏱️ Bu komut için {error.retry_after:.1f}s beklemelisin.")
        return
    if isinstance(error, commands.CheckFailure):
        await ctx.reply("⛔ Bu komut için yetkin yok.")
        return
    if isinstance(error, commands.BadArgument):
        await ctx.reply("❌ Komut parametrelerini kontrol et. `.help` yazabilirsin.")
        return
    logger.exception("Unhandled command error", exc_info=error)
    await ctx.reply("❌ Beklenmeyen bir bot hatası oluştu.")


if __name__ == "__main__":
    bot.run(DISCORD_TOKEN)
