from __future__ import annotations

import json
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

from syntax_validator import validate_generated_lua


@dataclass
class Issue:
    severity: str
    code: str
    stage: str
    message: str
    details: str = ""


class DiagnosticReport:
    def __init__(self, source: str):
        self.source_length = len(source)
        self.issues: list[Issue] = []
        self.stages: list[dict[str, Any]] = []
        self.metrics: dict[str, Any] = {}
        self.ok = True

    def stage(self, name: str, status: str = "PASS", **metrics: Any) -> None:
        self.stages.append({"stage": name, "status": status, **metrics})

    def issue(self, severity: str, code: str, stage: str, message: str, details: str = "") -> None:
        self.issues.append(Issue(severity, code, stage, message, details))
        if severity in {"ERROR", "FATAL"}:
            self.ok = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "source_length": self.source_length,
            "metrics": self.metrics,
            "stages": self.stages,
            "issues": [asdict(i) for i in self.issues],
        }

    def to_text(self) -> str:
        lines = [
            "Xemon Obfuscator Diagnostic Report",
            "=" * 36,
            f"Status: {'PASS' if self.ok else 'FAIL'}",
            f"Source length: {self.source_length}",
            "",
            "STAGES",
            "------",
        ]
        for s in self.stages:
            extra = " ".join(f"{k}={v}" for k, v in s.items() if k not in {"stage", "status"})
            lines.append(f"[{s['status']}] {s['stage']}" + (f" | {extra}" if extra else ""))
        lines += ["", "METRICS", "-------"]
        for k, v in self.metrics.items():
            lines.append(f"{k}: {v}")
        lines += ["", "ISSUES", "------"]
        if not self.issues:
            lines.append("None")
        else:
            for i in self.issues:
                lines.append(f"[{i.severity}] {i.code} @ {i.stage}: {i.message}")
                if i.details:
                    lines.append(f"  details: {i.details}")
        return "\n".join(lines) + "\n"


def preflight_source(source: str, report: DiagnosticReport) -> None:
    """Detect constructs that are still outside the XVM frontend/runtime ABI.

    Extended control-flow and vararg syntax is now compiled by bytecode_vm.py,
    so those constructs are intentionally not rejected here anymore.
    """
    patterns = [
        # Constructs deliberately rejected by the current frontend/runtime.
    ]
    for pattern, code, message in patterns:
        if re.search(pattern, source):
            report.issue("ERROR", code, "PREFLIGHT", message)

    # Lua 5.1-compatible numeric syntax only. Exponents and hex-floats are rejected
    # rather than silently being mis-tokenized.
    if re.search(r"\b\d+(?:\.\d+)?[eE][+-]?\d+\b", source):
        report.issue("ERROR", "UNSUPPORTED_NUMBER_LITERAL", "PREFLIGHT", "Exponent-form numeric literals are not supported by the XVM lexer.")
    if re.search(r"0[xX][0-9A-Fa-f]+\.[0-9A-Fa-f]", source):
        report.issue("ERROR", "UNSUPPORTED_HEX_FLOAT", "PREFLIGHT", "Hexadecimal floating-point literals are not supported.")


def smoke_test_generated_lua(source: str, report: DiagnosticReport, timeout: float = 10.0) -> None:
    """Use the locally available LuaTeX runtime as a syntax/runtime smoke test.
    This is a host-runtime check, not a Roblox compatibility proof."""
    lua = shutil.which("luatex")
    if not lua:
        report.stage("HOST_LUA_SMOKE", "SKIP", reason="luatex not installed")
        report.metrics["host_lua_available"] = False
        return

    report.metrics["host_lua_available"] = True
    path = None
    try:
        with tempfile.NamedTemporaryFile("w", suffix=".lua", delete=False, encoding="utf-8") as f:
            f.write(source)
            path = f.name
        p = subprocess.run(
            [lua, "--luaonly", path],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if p.returncode != 0:
            report.issue("ERROR", "HOST_LUA_RUNTIME", "HOST_LUA_SMOKE", "Generated Lua did not execute cleanly in the host Lua runtime.", p.stderr[-1200:] or p.stdout[-1200:])
            report.stage("HOST_LUA_SMOKE", "FAIL", returncode=p.returncode)
        else:
            m = re.search(r"\[Xemon AT\] checks=(\d+) failed", p.stdout)
            if m and int(m.group(1)) > 0:
                report.issue("WARN", "AT_ENVIRONMENT_DEPENDENT", "HOST_LUA_SMOKE", "Anti-Tamper reported environment-dependent failures in the non-Roblox host runtime.", p.stdout[:1800])
            report.stage("HOST_LUA_SMOKE", "PASS", returncode=0, stdout_preview=p.stdout[:240])
    except subprocess.TimeoutExpired:
        report.issue("ERROR", "HOST_LUA_TIMEOUT", "HOST_LUA_SMOKE", "Generated Lua exceeded the smoke-test timeout.")
        report.stage("HOST_LUA_SMOKE", "FAIL", timeout=timeout)
    finally:
        if path:
            Path(path).unlink(missing_ok=True)


def validate_output(source: str, report: DiagnosticReport) -> None:
    try:
        validate_generated_lua(source)
        report.stage("GENERATED_LUA_VALIDATE", "PASS", one_line=("\n" not in source and "\r" not in source))
        report.metrics["output_lines"] = len(source.splitlines())
        report.metrics["contains_loadstring"] = "loadstring" in source.lower()
        report.metrics["contains_load_call"] = "load(" in source.lower()
        if report.metrics["contains_loadstring"] or report.metrics["contains_load_call"]:
            report.issue("ERROR", "DYNAMIC_LOAD_PRESENT", "GENERATED_LUA_VALIDATE", "Dynamic source compilation token found in generated output.")
    except Exception as exc:
        report.issue("ERROR", "GENERATED_LUA_SYNTAX", "GENERATED_LUA_VALIDATE", str(exc))
        report.stage("GENERATED_LUA_VALIDATE", "FAIL")


def blob_header(blob: bytes, report: DiagnosticReport, label: str) -> None:
    if len(blob) < 74:
        report.issue("ERROR", "BYTECODE_TRUNCATED", "BYTECODE", f"{label} bytecode is shorter than the XVM5 header.")
        report.stage(f"BYTECODE_{label}", "FAIL", size=len(blob))
        return
    magic = blob[:4]
    version = blob[4]
    if magic != b"XVM5":
        report.issue("ERROR", "BAD_XVM_HEADER", "BYTECODE", f"{label} blob magic is {magic!r}, expected XVM5.")
    if version != 5:
        report.issue("ERROR", "BAD_XVM_VERSION", "BYTECODE", f"{label} blob version is {version}, expected 5.")
    report.stage(f"BYTECODE_{label}", "PASS" if magic == b"XVM5" and version == 5 else "FAIL", size=len(blob), magic=magic.decode(errors="replace"), version=version)


def report_to_json(report: DiagnosticReport) -> str:
    return json.dumps(report.to_dict(), ensure_ascii=False, indent=2)
