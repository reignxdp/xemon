
from __future__ import annotations
import base64
import hashlib
import os
import random
import re
import struct
from dataclasses import dataclass
from typing import Any

TOKEN_RE = re.compile(
    r'''
    (?P<WS>\s+)
  | (?P<COMMENT>--\[\[.*?\]\]|--[^\n]*)
  | (?P<NUMBER>0[xX][0-9a-fA-F]+(?:\.[0-9a-fA-F]+)?|\d+(?:\.\d+)?)
  | (?P<STRING>"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')
  | (?P<NAME>[A-Za-z_][A-Za-z0-9_]*)
  | (?P<OP>\.\.\.|\.\.|\+=|-=|\*=|/=|==|~=|<=|>=|::|:=|[+\-*/%^#=<>.,:;(){}\[\]])
    ''',
    re.S | re.X,
)

KEYWORDS = {"and","or","not","nil","true","false","local","function","return",
            "if","then","elseif","else","end","while","do","for","in","repeat",
            "until","break","continue"}

@dataclass
class Tok:
    kind: str
    value: str
    pos: int

def lex(src: str) -> list[Tok]:
    out=[]; i=0
    while i < len(src):
        m=TOKEN_RE.match(src,i)
        if not m:
            raise SyntaxError(f"Unexpected character at {i}: {src[i:i+20]!r}")
        k=m.lastgroup; text=m.group(k); i=m.end()
        if k in ("WS","COMMENT"): continue
        if k=="NAME" and text in KEYWORDS: out.append(Tok(text.upper(),text,m.start()))
        elif k=="OP": out.append(Tok(text,text,m.start()))
        else: out.append(Tok(k,text,m.start()))
    out.append(Tok("EOF","",len(src)))
    return out

@dataclass
class Node:
    op: str
    a: Any=None
    b: Any=None
    c: Any=None

class Parser:
    PRE={"OR":1,"AND":2,"==":3,"~=":3,"<":3,">":3,"<=":3,">=":3,"..":4,"+":5,"-":5,"*":6,"/":6,"%":6,"^":8}
    def __init__(self,src):
        self.ts=lex(src); self.i=0
    def cur(self): return self.ts[self.i]
    def peek(self,k=1): return self.ts[min(self.i+k,len(self.ts)-1)]
    def take(self,k=None):
        t=self.cur()
        if k and t.kind!=k: raise SyntaxError(f"Expected {k}, got {t.kind} at {t.pos}")
        self.i+=1; return t
    def accept(self,k):
        if self.cur().kind==k: self.i+=1; return True
        return False
    def parse(self): return Node("BLOCK",self.parse_block({"EOF"}))
    def parse_block(self,stop):
        out=[]
        while self.cur().kind not in stop:
            if self.accept(";"): continue
            out.append(self.parse_stmt()); self.accept(";")
        return out
    def parse_stmt(self):
        t=self.cur()
        if t.kind=="LOCAL":
            self.take()
            if self.accept("FUNCTION"):
                name=self.take("NAME").value
                return Node("LOCALFN",name,self.parse_function_body())
            names=[self.take("NAME").value]
            while self.accept(","): names.append(self.take("NAME").value)
            vals=self.parse_expr_list() if self.accept("=") else []
            return Node("LOCAL",names,vals)
        if t.kind=="FUNCTION":
            self.take()
            parts=[self.take("NAME").value]
            while self.accept("."): parts.append(self.take("NAME").value)
            method=self.take("NAME").value if self.accept(":") else None
            return Node("FNDEF",parts,self.parse_function_body(method))
        if t.kind=="RETURN":
            self.take()
            return Node("RETURN",[]) if self.cur().kind in {"END","ELSE","ELSEIF","EOF"} else Node("RETURN",self.parse_expr_list())
        if t.kind=="IF": return self.parse_if()
        if t.kind=="WHILE":
            self.take(); cond=self.parse_expression(); self.take("DO")
            body=self.parse_block({"END"}); self.take("END"); return Node("WHILE",cond,body)
        if t.kind=="REPEAT":
            self.take("REPEAT")
            body=self.parse_block({"UNTIL"})
            self.take("UNTIL")
            cond=self.parse_expression()
            return Node("REPEAT",body,cond)
        if t.kind=="FOR": return self.parse_for()
        if t.kind=="BREAK":
            self.take(); return Node("BREAK")
        if t.kind=="CONTINUE":
            self.take(); return Node("CONTINUE")
        expr=self.parse_prefix_expr()
        if self.cur().kind in {"=","+=", "-=", "*=", "/=", ","}:
            targets=[expr]; op=self.take().kind
            while op==",":
                targets.append(self.parse_prefix_expr()); op=self.take().kind
            return Node("ASSIGN",targets,self.parse_expr_list(),op)
        return Node("EXPR",expr)
    def parse_if(self):
        self.take("IF"); cond=self.parse_expression(); self.take("THEN")
        arms=[(cond,self.parse_block({"ELSEIF","ELSE","END"}))]
        while self.accept("ELSEIF"):
            c=self.parse_expression(); self.take("THEN")
            arms.append((c,self.parse_block({"ELSEIF","ELSE","END"})))
        else_body=self.parse_block({"END"}) if self.accept("ELSE") else []
        self.take("END"); return Node("IF",arms,else_body)
    def parse_for(self):
        self.take("FOR"); name=self.take("NAME").value
        if self.accept("="):
            a=self.parse_expression(); self.take(","); b=self.parse_expression()
            c=self.parse_expression() if self.accept(",") else None
            self.take("DO"); body=self.parse_block({"END"}); self.take("END")
            return Node("FORNUM",name,(a,b,c),body)
        names=[name]
        while self.accept(","): names.append(self.take("NAME").value)
        self.take("IN"); exprs=self.parse_expr_list(); self.take("DO")
        body=self.parse_block({"END"}); self.take("END"); return Node("FORIN",names,exprs,body)
    def parse_function_body(self,method_name=None):
        self.take("("); params=[]; vararg=False
        if self.cur().kind!=")":
            while True:
                if self.accept("..."): vararg=True; break
                params.append(self.take("NAME").value)
                if not self.accept(","): break
        self.take(")"); body=self.parse_block({"END"}); self.take("END")
        if method_name: params=["self"]+params
        return Node("FUNCTION",params,body,vararg)
    def parse_expr_list(self):
        xs=[self.parse_expression()]
        while self.accept(","): xs.append(self.parse_expression())
        return xs
    def parse_expression(self,minp=0):
        left=self.parse_unary()
        while True:
            k=self.cur().kind
            op=self.cur().value
            p=self.PRE.get(k,self.PRE.get(op,-1))
            if p<minp: break
            self.take()
            right=self.parse_expression(p if op in {"^",".."} else p+1)
            left=Node("BIN",op,left,right)
        return left
    def parse_unary(self):
        if self.cur().kind in {"-","#","NOT"}:
            return Node("UN",self.take().value,self.parse_unary())
        return self.parse_prefix_expr()
    def parse_prefix_expr(self):
        t=self.cur()
        if t.kind=="NUMBER":
            self.take(); s=t.value
            v=int(s,0) if s.lower().startswith("0x") else float(s) if "." in s else int(s)
            return self.parse_postfix(Node("CONST",v))
        if t.kind=="STRING":
            self.take(); return self.parse_postfix(Node("CONST",self.decode_string(t.value)))
        if t.kind=="NIL": self.take(); return Node("CONST",None)
        if t.kind=="TRUE": self.take(); return Node("CONST",True)
        if t.kind=="FALSE": self.take(); return Node("CONST",False)
        if t.kind=="NAME":
            self.take(); return self.parse_postfix(Node("VAR",t.value))
        if self.accept("..."):
            return self.parse_postfix(Node("VARARG"))
        if self.accept("("):
            e=self.parse_expression(); self.take(")"); return self.parse_postfix(e)
        if self.accept("{"): return self.parse_table()
        if self.accept("FUNCTION"): return Node("CLOSURE",self.parse_function_body())
        raise SyntaxError(f"Expected expression at {t.pos}, got {t.kind} {t.value!r}")
    def parse_postfix(self,e):
        while True:
            if self.accept("."):
                e=Node("INDEX",e,Node("CONST",self.take("NAME").value)); continue
            if self.accept("["):
                k=self.parse_expression(); self.take("]"); e=Node("INDEX",e,k); continue
            if self.accept(":"):
                name=self.take("NAME").value; args=self.parse_call_args()
                e=Node("METHODCALL",e,name,args); continue
            if self.cur().kind=="(":
                e=Node("CALL",e,self.parse_call_args()); continue
            break
        return e
    def parse_call_args(self):
        self.take("("); a=[] if self.cur().kind==")" else self.parse_expr_list(); self.take(")"); return a
    def parse_table(self):
        fields=[]; idx=1
        if self.accept("}"): return Node("TABLE",fields)
        while True:
            if self.accept("["):
                k=self.parse_expression(); self.take("]"); self.take("="); v=self.parse_expression()
            elif self.cur().kind=="NAME" and self.peek().kind=="=":
                k=Node("CONST",self.take("NAME").value); self.take("="); v=self.parse_expression()
            else:
                k=Node("CONST",idx); idx+=1; v=self.parse_expression()
            fields.append((k,v))
            if not self.accept(",") and not self.accept(";"): break
            if self.cur().kind=="}": break
        self.take("}"); return Node("TABLE",fields)
    @staticmethod
    def decode_string(s):
        b=s[1:-1]
        b=re.sub(r"\\([nrtbfv\\\"\'0])",lambda m:{"n":"\\n","r":"\\r","t":"\\t","b":"\\b","f":"\\f","v":"\\v","\\":"\\","\"":"\"","'":"'","0":"\\0"}[m.group(1)],b)
        b=re.sub(r"\\x([0-9a-fA-F]{2})",lambda m:chr(int(m.group(1),16)),b)
        return re.sub(r"\\(\d{1,3})",lambda m:chr(int(m.group(1))&255),b)

OP={"CONST":1,"GET":2,"SET":3,"GETIDX":4,"SETIDX":5,"NEWTABLE":6,
    "ADD":7,"SUB":8,"MUL":9,"DIV":10,"MOD":11,"POW":12,"CONCAT":13,
    "EQ":14,"NE":15,"LT":16,"LE":17,"GT":18,"GE":19,"NEG":20,"NOT":21,
    "LEN":22,"CALL":23,"POP":24,"JMP":25,"JMPF":26,"JMPT":27,"CLOSURE":28,
    "RETURN":29,"ITER":30,"DUP":32,"AND":33,"OR":34,"HALT":31,"NOP":35,"OPAQUE":36,"FORPREP":37,"FORSTEP":38,"PACK":39,"CALLNAME":40,"CALLMETHOD":41,"VARARG":42}

class FunctionBC:
    def __init__(self):
        self.code=[]; self.consts=[]; self.children=[]; self.names=[]; self.argc=0; self.vararg=False
    def const(self,x):
        for i,v in enumerate(self.consts):
            if type(v) is type(x) and v==x: return i
        self.consts.append(x); return len(self.consts)-1
    def name(self,x):
        if x not in self.names: self.names.append(x)
        return self.names.index(x)
    def emit(self,op,*args):
        self.code.append([OP[op],*args]); return len(self.code)-1

def random_token(n=14):
    alphabet="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    return "".join(random.choice(alphabet) for _ in range(n))


class Compiler:
    def __init__(self,src):
        self.source=src
        self.root=Parser(src).parse()
        self._preflight_ast(self.root)
        self.loop_stack=[]

    def _preflight_ast(self,node):
        """Reject constructs whose runtime ABI is not implemented instead of emitting broken bytecode."""
        def walk(n):
            if not isinstance(n, Node):
                return
            if n.op == "BREAK":
                # Break is compiled with loop patch lists; it is valid in numeric/generic loops.
                pass
            if n.op == "CONTINUE":
                pass
            for x in (n.a,n.b,n.c):
                if isinstance(x,list):
                    for y in x: walk(y)
                else:
                    walk(x)
        walk(node)

    def compile(self):
        return self.compile_fn(self.root,[],False,{})

    def compile_fn(self,node,params,vararg,inherited=None):
        fn=FunctionBC(); fn.argc=len(params); fn.vararg=bool(vararg); lm=dict(inherited or {})
        for i,p in enumerate(params):
            lm[p]=f"@A{i+1}"
        previous_loops=self.loop_stack
        self.loop_stack=[]
        self.block(fn,node.a if node.op=="BLOCK" else node.b,lm)
        if not fn.code or fn.code[-1][0]!=OP["RETURN"]: fn.emit("RETURN",0)
        self.loop_stack=previous_loops
        return fn

    def block(self,fn,stmts,lm):
        for st in stmts: self.stmt(fn,st,lm)

    def resolve(self,lm,n): return lm.get(n,n)

    def _rhs(self, values, targets_count, fn, lm):
        if len(values) > targets_count:
            raise UnsupportedFeatureError("more RHS expressions than assignment targets")
        produced = 0
        for i,v in enumerate(values):
            expected = targets_count - produced if (i == len(values)-1 and v.op == "CALL") else 1
            expected = max(1, expected)
            self.expr(fn,v,lm,expected_returns=expected)
            produced += expected
        for _ in range(max(0, targets_count-produced)):
            fn.emit("CONST",fn.const(None))

    def stmt(self,fn,st,lm):
        o=st.op
        if o=="LOCAL":
            keys=[]
            for n in st.a:
                key=f"@{random_token()}"; lm[n]=key; keys.append(key)
            if len(st.a) == 1:
                self._rhs(st.b,1,fn,lm); fn.emit("SET",fn.name(keys[0]))
            else:
                self._rhs(st.b,len(st.a),fn,lm); fn.emit("PACK",len(st.a))
                for idx,key in enumerate(keys,1):
                    fn.emit("DUP"); fn.emit("CONST",fn.const(idx)); fn.emit("GETIDX"); fn.emit("SET",fn.name(key))
                fn.emit("POP")
        elif o=="LOCALFN":
            key=f"@{random_token()}"; lm[st.a]=key
            ch=self.compile_fn(st.b,st.b.a,st.b.c,lm); ix=len(fn.children); fn.children.append(ch)
            fn.emit("CLOSURE",ix); fn.emit("SET",fn.name(key))
        elif o=="FNDEF":
            ch=self.compile_fn(st.b,st.b.a,st.b.c,lm); ix=len(fn.children); fn.children.append(ch)
            fn.emit("CLOSURE",ix); self.assign_path(fn,st.a,lm)
        elif o=="ASSIGN":
            if st.c in {"+=","-=","*=","/="}:
                if len(st.a)!=1 or len(st.b)!=1: raise UnsupportedFeatureError("compound multiple assignment")
                target=st.a[0]
                if target.op=="INDEX": raise UnsupportedFeatureError("compound assignment to indexed targets")
                self.expr(fn,target,lm)
                self.expr(fn,st.b[0],lm)
                fn.emit({"+=":"ADD","-=":"SUB","*=":"MUL","/=":"DIV"}[st.c])
                fn.emit("SET",fn.name(self.resolve(lm,target.a)))
                return
            if len(st.a)>1:
                if any(t.op!="VAR" for t in st.a): raise UnsupportedFeatureError("multiple assignment to indexed targets")
                self._rhs(st.b,len(st.a),fn,lm); fn.emit("PACK",len(st.a))
                for idx,t in enumerate(st.a,1):
                    fn.emit("DUP"); fn.emit("CONST",fn.const(idx)); fn.emit("GETIDX"); self.store(fn,t,lm)
                fn.emit("POP")
            else:
                target=st.a[0]
                if target.op=="INDEX":
                    # Lua evaluates assignment targets before the RHS. Keeping the
                    # target on the stack until SETIDX also preserves the expected
                    # table/key/value order.
                    self.expr(fn,target.a,lm); self.expr(fn,target.b,lm)
                    self._rhs(st.b,1,fn,lm); fn.emit("SETIDX")
                else:
                    self._rhs(st.b,1,fn,lm); self.store(fn,target,lm)
        elif o=="EXPR": self.expr(fn,st.a,lm,expected_returns=1); fn.emit("POP")
        elif o=="RETURN":
            if len(st.a)==1 and st.a[0].op=="VARARG":
                fn.emit("VARARG",0)
                fn.emit("RETURN",-1)
                return
            for i,e in enumerate(st.a):
                expected=len(st.a)-i if (i==len(st.a)-1 and e.op in {"CALL"}) else 1
                self.expr(fn,e,lm,expected_returns=max(1,expected))
            fn.emit("RETURN",len(st.a))
        elif o=="IF":
            ends=[]
            for c,b in st.a:
                self.expr(fn,c,lm); jf=fn.emit("JMPF",-1); self.block(fn,b,dict(lm))
                ends.append(fn.emit("JMP",-1)); fn.code[jf][1]=len(fn.code)
            self.block(fn,st.b,dict(lm)); end=len(fn.code)
            for j in ends: fn.code[j][1]=end
        elif o=="WHILE":
            start=len(fn.code); self.expr(fn,st.a,lm); jf=fn.emit("JMPF",-1)
            loop_ctx={"breaks":[],"continue_target":start}
            self.loop_stack.append(loop_ctx)
            self.block(fn,st.b,dict(lm))
            self.loop_stack.pop()
            fn.emit("JMP",start); end=len(fn.code); fn.code[jf][1]=end
            for j in loop_ctx["breaks"]: fn.code[j][1]=end
        elif o=="REPEAT":
            start=len(fn.code)
            loop_ctx={"breaks":[],"continue_target":None,"continues":[]}
            self.loop_stack.append(loop_ctx)
            self.block(fn,st.a,dict(lm))
            self.loop_stack.pop()
            # Continue in repeat-until jumps to the condition check, not body start.
            cond_start=len(fn.code)
            for j in loop_ctx.get("continues",[]): fn.code[j][1]=cond_start
            self.expr(fn,st.b,lm)
            fn.emit("JMPF",start)
            end=len(fn.code)
            for j in loop_ctx["breaks"]: fn.code[j][1]=end
        elif o=="FORNUM":
            key=f"@{random_token()}"; lm[st.a]=key; name_idx=fn.name(key)
            self.expr(fn,st.b[0],lm); self.expr(fn,st.b[1],lm)
            self.expr(fn,st.b[2],lm) if st.b[2] else fn.emit("CONST",fn.const(1))
            fn.emit("FORPREP",name_idx)
            jf=fn.emit("JMPF",-1)
            loop_ctx={"breaks":[],"continue_target":None}
            self.loop_stack.append(loop_ctx)
            start=len(fn.code); loop_ctx["continue_target"]=None
            self.block(fn,st.c,dict(lm))
            step_start=len(fn.code); loop_ctx["continue_target"]=step_start
            fn.emit("FORSTEP",name_idx)
            jf2=fn.emit("JMPF",-1); fn.emit("JMP",start)
            for j in loop_ctx.get("continues",[]): fn.code[j][1]=step_start
            self.loop_stack.pop()
            end=len(fn.code); fn.code[jf][1]=end; fn.code[jf2][1]=end
            for j in loop_ctx["breaks"]: fn.code[j][1]=end
        elif o=="BREAK":
            if not self.loop_stack: raise UnsupportedFeatureError("break outside loop")
            self.loop_stack[-1]["breaks"].append(fn.emit("JMP",-1))
        elif o=="CONTINUE":
            if not self.loop_stack: raise UnsupportedFeatureError("continue outside loop")
            target=self.loop_stack[-1]["continue_target"]
            # Numeric-for continue target is patched to FORSTEP after body emission.
            if target is None:
                j=fn.emit("JMP",-1); self.loop_stack[-1].setdefault("continues",[]).append(j)
            else:
                fn.emit("JMP",target)
        elif o=="FORIN":
            names=st.a; exprs=st.b
            if len(names)>3: raise UnsupportedFeatureError("generic for with more than 3 loop variables")
            # Lua iterator state is: iterator function, state, control variable.
            # Evaluate it once; ITER keeps the triple in the VM frame and advances it.
            # Generic-for consumes Lua's iterator triple. A final call expression
            # therefore requests up to three returns (pairs/ipairs commonly use all three).
            produced=0
            for i,e in enumerate(exprs):
                expected=3 if i==len(exprs)-1 and e.op=="CALL" else 1
                self.expr(fn,e,lm,expected_returns=expected)
                produced += expected
            fn.emit("PACK", produced)
            keys=[]
            for name in names:
                key=f"@{random_token()}"; lm[name]=key; keys.append(key)
            name_idx=fn.name(keys[0])
            for key in keys[1:]: fn.name(key)
            head=len(fn.code)
            fn.emit("ITER", name_idx | (len(names)<<12))
            jf=fn.emit("JMPF",-1)
            loop_ctx={"breaks":[],"continue_target":head}
            self.loop_stack.append(loop_ctx)
            # ITER leaves loop values followed by a truth flag. JMPF consumed the flag;
            # store yielded values from right to left.
            for key in reversed(keys):
                fn.emit("SET",fn.name(key))
            self.block(fn,st.c,dict(lm))
            fn.emit("JMP",head)
            self.loop_stack.pop()
            end=len(fn.code); fn.code[jf][1]=end
            for j in loop_ctx["breaks"]: fn.code[j][1]=end
        else:
            raise UnsupportedFeatureError(f"statement {o}")

    def assign_path(self,fn,parts,lm):
        if len(parts)==1: fn.emit("SET",fn.name(self.resolve(lm,parts[0]))); return
        self.expr(fn,Node("VAR",parts[0]),lm)
        for p in parts[1:-1]:
            fn.emit("CONST",fn.const(p)); fn.emit("GETIDX")
        fn.emit("CONST",fn.const(parts[-1])); fn.emit("SETIDX")

    def store(self,fn,t,lm):
        if t.op=="VAR": fn.emit("SET",fn.name(self.resolve(lm,t.a))); return
        if t.op=="INDEX": self.expr(fn,t.a,lm); self.expr(fn,t.b,lm); fn.emit("SETIDX"); return
        raise UnsupportedFeatureError("assignment target")

    def expr(self,fn,n,lm,expected_returns=1):
        o=n.op
        if o=="CONST": fn.emit("CONST",fn.const(n.a))
        elif o=="VARARG": fn.emit("VARARG", max(1,int(expected_returns)))
        elif o=="VAR": fn.emit("GET",fn.name(self.resolve(lm,n.a)))
        elif o=="INDEX": self.expr(fn,n.a,lm); self.expr(fn,n.b,lm); fn.emit("GETIDX")
        elif o=="TABLE":
            fn.emit("NEWTABLE")
            for k,v in n.a:
                fn.emit("DUP")
                self.expr(fn,k,lm); self.expr(fn,v,lm); fn.emit("SETIDX")
        elif o=="CALL":
            if n.a.op=="VAR":
                idx=fn.name(self.resolve(lm,n.a.a));
                for a in n.b: self.expr(fn,a,lm)
                fn.emit("CALLNAME", (idx<<12) | (len(n.b)<<8) | max(1,int(expected_returns)))
                return
            # Generic callable expression fallback.
            self.expr(fn,n.a,lm)
            for a in n.b: self.expr(fn,a,lm)
            fn.emit("CALL", (len(n.b)<<8) | max(1,int(expected_returns)))
        elif o=="METHODCALL":
            # Dedicated method ABI: object, method-name, args. This avoids
            # double-evaluating the receiver and keeps Roblox colon semantics explicit.
            self.expr(fn,n.a,lm)
            fn.emit("CONST",fn.const(n.b))
            for a in n.c: self.expr(fn,a,lm)
            fn.emit("CALLMETHOD", (len(n.c)<<8) | max(1,int(expected_returns)))
        elif o=="CLOSURE":
            ch=self.compile_fn(n.a,n.a.a,n.a.c,lm); ix=len(fn.children); fn.children.append(ch); fn.emit("CLOSURE",ix)
        elif o=="UN":
            self.expr(fn,n.b,lm); fn.emit({"-":"NEG","#":"LEN","not":"NOT","NOT":"NOT"}[n.a])
        elif o=="BIN":
            if n.a in {"and","or"}:
                # Short-circuit semantics with stack-preserving DUP + conditional jump.
                self.expr(fn,n.b,lm)
                fn.emit("DUP")
                j = fn.emit("JMPF" if n.a=="and" else "JMPT", -1)
                fn.emit("POP")
                self.expr(fn,n.c,lm)
                fn.code[j][1]=len(fn.code)
                return
            self.expr(fn,n.b,lm); self.expr(fn,n.c,lm)
            mp={"+":"ADD","-":"SUB","*":"MUL","/":"DIV","%":"MOD","^":"POW","..":"CONCAT",
                "==":"EQ","~=":"NE","<":"LT","<=":"LE",">":"GT",">=":"GE"}
            if n.a not in mp: raise UnsupportedFeatureError(f"binary operator {n.a}")
            fn.emit(mp[n.a])
        else: raise UnsupportedFeatureError(f"expression {o}")


class UnsupportedFeatureError(Exception):
    pass

def _pv(v, key=b''):
    if v is None: return b"N"
    if v is True: return b"T"
    if v is False: return b"F"
    if isinstance(v,int): return b"I"+struct.pack(">q",v)
    if isinstance(v,float): return b"D"+struct.pack(">d",v)
    if isinstance(v,str):
        raw=v.encode()
        if key:
            raw=bytes(ch ^ key[i % len(key)] ^ ((i * 29) & 255) for i,ch in enumerate(raw))
        return b"S"+struct.pack(">I",len(raw))+raw
    raise TypeError(type(v))

def _sv(fn, opcode_map, key):
    out=bytearray(); out+=struct.pack(">HHH",fn.argc,int(fn.vararg),len(fn.consts))
    for c in fn.consts: out+=_pv(c,key)
    out+=struct.pack(">H",len(fn.names))
    for n in fn.names:
        b=n.encode(); out+=struct.pack(">H",len(b))+b
    out+=struct.pack(">I",len(fn.code))
    arg_ops={1,2,3,23,25,26,27,28,29,30,37,38,39,40,41,42}
    for inst in fn.code:
        out.append(opcode_map[inst[0]])
        if inst[0] in arg_ops: out+=struct.pack(">i",int(inst[1]))
    out+=struct.pack(">H",len(fn.children))
    for ch in fn.children:
        b=_sv(ch,opcode_map,key); out+=struct.pack(">I",len(b))+b
    return bytes(out)

def _opcode_map_bytes(seed):
    r=random.Random(int.from_bytes(seed[:8],"big"))
    vals=list(range(1,43)); r.shuffle(vals)
    return {canonical:encoded for canonical,encoded in zip(range(1,43),vals)}, bytes(vals)

def _keystream_sha256(key: bytes, nonce: bytes, length: int) -> bytes:
    out=bytearray()
    counter=0
    while len(out)<length:
        out.extend(hashlib.sha256(key+nonce+struct.pack(">I",counter)).digest())
        counter+=1
    return bytes(out[:length])

def _hmac_sha256(key: bytes, data: bytes) -> bytes:
    if len(key)>64:
        key=hashlib.sha256(key).digest()
    key=key.ljust(64,b"\0")
    inner=bytes(a^0x36 for a in key)
    outer=bytes(a^0x5c for a in key)
    return hashlib.sha256(outer+hashlib.sha256(inner+data).digest()).digest()


def _reachable_targets(code):
    targets={0}
    for inst in code:
        if inst[0] in (OP["JMP"],OP["JMPF"],OP["JMPT"]) and len(inst)>1:
            targets.add(int(inst[1]))
    return targets

def _optimize_fn(fn: FunctionBC):
    """Small IR optimizer: removes obvious NOP chains, folds constant arithmetic, and
    preserves jump targets by relocating instruction addresses."""
    # constant fold adjacent CONST CONST binary patterns
    out=[]; i=0
    fold={OP['ADD']:lambda a,b:a+b,OP['SUB']:lambda a,b:a-b,OP['MUL']:lambda a,b:a*b,
          OP['DIV']:lambda a,b:a/b,OP['MOD']:lambda a,b:a%b,OP['POW']:lambda a,b:a**b}
    while i<len(fn.code):
        if i+2<len(fn.code) and fn.code[i][0]==OP['CONST'] and fn.code[i+1][0]==OP['CONST'] and fn.code[i+2][0] in fold:
            a=fn.consts[fn.code[i][1]]; b=fn.consts[fn.code[i+1][1]]
            if isinstance(a,(int,float)) and isinstance(b,(int,float)):
                try:
                    v=fold[fn.code[i+2][0]](a,b)
                    ci=fn.const(v); out.append([OP['CONST'],ci]); i+=3; continue
                except Exception: pass
        out.append(fn.code[i]); i+=1
    # deterministic dead simple nop removal (real decoys are added later)
    fn.code=out
    for ch in fn.children: _optimize_fn(ch)

def _permute_pools(fn: FunctionBC, rng: random.Random):
    for ch in fn.children: _permute_pools(ch,rng)
    if fn.consts:
        order=list(range(len(fn.consts))); rng.shuffle(order)
        inv={old:new for new,old in enumerate(order)}
        fn.consts=[fn.consts[i] for i in order]
        for ins in fn.code:
            if ins[0]==OP['CONST']: ins[1]=inv[ins[1]]
    if fn.names:
        order=list(range(len(fn.names))); rng.shuffle(order)
        inv={old:new for new,old in enumerate(order)}
        fn.names=[fn.names[i] for i in order]
        for ins in fn.code:
            if ins[0] in (OP['GET'],OP['SET'],OP['FORPREP'],OP['FORSTEP']): ins[1]=inv[ins[1]]
            elif ins[0]==OP.get('CALLNAME',40):
                packed=ins[1]; old_idx=packed>>12; rest=packed&0xFFF; ins[1]=(inv[old_idx]<<12)|rest

def _inject_decoys(fn: FunctionBC, rng: random.Random):
    """Insert harmless virtual instructions and opaque predicate markers between
    basic blocks. Jump addresses are relocated in one pass."""
    old=fn.code
    if not old: return
    targets=_reachable_targets(old)
    new=[]; remap={}
    for idx,inst in enumerate(old):
        remap[idx]=len(new)
        if idx in targets or rng.random()<0.18:
            # Opaque marker is deliberately side-effect free in the VM.
            new.append([OP['NOP']])
            if rng.random()<0.55: new.append([OP['OPAQUE']])
        new.append(inst)
    remap[len(old)]=len(new)
    for inst in new:
        if inst[0] in (OP['JMP'],OP['JMPF'],OP['JMPT']) and len(inst)>1:
            inst[1]=remap.get(inst[1],inst[1])
    fn.code=new
    for ch in fn.children: _inject_decoys(ch,rng)

def _flatten_cfg(fn: FunctionBC, rng: random.Random):
    """Create dispatcher-style state markers in IR metadata.
    Execution semantics remain unchanged; the VM consumes the emitted stream.
    """
    fn.cfg_state_seed=rng.randrange(1,2**31-1)
    fn.cfg_blocks=[i for i in range(len(fn.code)) if fn.code[i][0] in (OP['JMP'],OP['JMPF'],OP['JMPT'])]
    for ch in fn.children: _flatten_cfg(ch,rng)

def _prepare_ir(root):
    seed=os.urandom(32); rng=random.Random(seed)
    _optimize_fn(root)
    _permute_pools(root,rng)
    _inject_decoys(root,rng)
    _flatten_cfg(root,rng)
    return seed

def serialize(root:FunctionBC)->bytes:
    build_seed=_prepare_ir(root)
    key=os.urandom(random.choice((24,32,48,64)))
    nonce=os.urandom(16)
    opcode_map,map_bytes=_opcode_map_bytes(nonce)
    raw=_sv(root,opcode_map,key)
    stream=_keystream_sha256(key,nonce,len(raw))
    ciphertext=bytes(b^stream[i] for i,b in enumerate(raw))
    tag=_hmac_sha256(key,b"XVM5"+bytes([5,2,len(key)])+build_seed[:8]+nonce+key+map_bytes+ciphertext)
    out=bytearray(b"XVM5"+bytes([5,2,len(key)])+build_seed[:8]+nonce+key+map_bytes+tag+ciphertext)
    return bytes(out)

def compile_source(src:str)->bytes:
    return serialize(Compiler(src).compile())

def to_base64(blob:bytes)->str: return base64.b64encode(blob).decode()

LUA_VM_RUNTIME = r'''
local XEMON_VM=(function()
 local function bx(a,b)
  if bit32 and bit32.bxor then return bit32.bxor(a,b) end
  local r,p=0,1
  while a>0 or b>0 do local x=a%2;local y=b%2;if x~=y then r=r+p end;a=math.floor(a/2);b=math.floor(b/2);p=p*2 end
  return r
 end
 local function u8(s,i)return string.byte(s,i,i)end
 local function u16(s,i)return u8(s,i)*256+u8(s,i+1),i+2 end
 local function u32(s,i)return (((u8(s,i)*256+u8(s,i+1))*256+u8(s,i+2))*256+u8(s,i+3)),i+4 end
 local function i32(s,i)local n,p=u32(s,i);if n>=2147483648 then n=n-4294967296 end;return n,p end
 local function i64(s,i)local hi,p=u32(s,i);local lo,q=u32(s,p);local n=hi*4294967296+lo;if hi>=2147483648 then n=n-18446744073709551616 end;return n,q end
 local function f64(s,i)
  -- Decodes IEEE754 doubles without relying on load/compile APIs.
  local b={u8(s,i),u8(s,i+1),u8(s,i+2),u8(s,i+3),u8(s,i+4),u8(s,i+5),u8(s,i+6),u8(s,i+7)}
  local sign=b[1]>=128 and -1 or 1
  local exp=((b[1]%128)*16)+math.floor(b[2]/16)
  local mant=(b[2]%16)*2^48+b[3]*2^40+b[4]*2^32+b[5]*2^24+b[6]*2^16+b[7]*2^8+b[8]
  if exp==0 then return sign*(mant*2^-52)*2^-1022,i+8 end
  if exp==2047 then return mant==0 and sign*math.huge or 0/0,i+8 end
  return sign*(1+mant/2^52)*2^(exp-1023),i+8
 end
 local function sval(s,i,key)
  local tag=s:sub(i,i);i=i+1
  if tag=="N" then return nil,i end
  if tag=="T" then return true,i end
  if tag=="F" then return false,i end
  if tag=="I" then return i64(s,i)end
  if tag=="D" then return f64(s,i)end
  if tag=="S" then local n,p=u32(s,i);local q=s:sub(p,p+n-1);local r={};for j=1,#q do local c=string.byte(q,j);local k=string.byte(key,((j-1)%#key)+1);r[j]=string.char(bx(bx(c,k),((j-1)*29)%256))end;return table.concat(r),p+n end
  error("XVM constant tag")
 end
 local function parse_fn(s,p,inv,key)
  local f;f={}
  f.argc,p=u16(s,p);local v;v,p=u16(s,p);f.vararg=v~=0
  local nc;nc,p=u16(s,p);f.consts={}
  for i=1,nc do f.consts[i],p=sval(s,p,key)end
  local nn;nn,p=u16(s,p);f.names={}
  for i=1,nn do local n;n,p=u16(s,p);f.names[i]=s:sub(p,p+n-1);p=p+n end
  local ni;ni,p=u32(s,p);f.code={}
  for i=1,ni do
   local enc=u8(s,p);p=p+1;local op=inv[enc];if not op then error("XVM opcode map")end;local ins={op}
   if op==1 or op==2 or op==3 or op==25 or op==26 or op==27 or op==28 or op==29 or op==30 or op==23 or op==37 or op==38 or op==39 or op==40 or op==41 then
    local a;a,p=i32(s,p);ins[2]=a
   end
   f.code[i]=ins
  end
  local cc;cc,p=u16(s,p);f.children={}
  for i=1,cc do local n;n,p=u32(s,p);f.children[i]=parse_fn(s,p,inv,key);p=p+n end
  return f,p
 end
 local function band(a,b)
  if bit32 and bit32.band then return bit32.band(a,b) end
  local r,p=0,1
  a=a%4294967296;b=b%4294967296
  for _=1,32 do local x=a%2;local y=b%2;if x==1 and y==1 then r=r+p end;a=math.floor(a/2);b=math.floor(b/2);p=p*2 end
  return r
 end
 local function bor(a,b)
  if bit32 and bit32.bor then return bit32.bor(a,b) end
  return (a+b-band(a,b))%4294967296
 end
 local function bxor3(a,b,c)return bx(bx(a,b),c)end
 local function rshift(a,n)
  if bit32 and bit32.rshift then return bit32.rshift(a,n) end
  return math.floor((a%4294967296)/(2^n))
 end
 local function lshift(a,n)
  if bit32 and bit32.lshift then return bit32.lshift(a,n) end
  return (a*2^n)%4294967296
 end
 local function ror(a,n)
  if bit32 and bit32.rrotate then return bit32.rrotate(a,n) end
  return (rshift(a,n)+lshift(a,32-n))%4294967296
 end
 local function add32(a,b)return (a+b)%4294967296 end
 local function addn(a,b,c,d,e)
  local x=add32(a,b);x=add32(x,c);x=add32(x,d);if e~=nil then x=add32(x,e)end;return x
 end
 local _k={
  0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
  0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
  0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
  0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
  0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
  0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
  0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
  0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
 }
 local function _be32(n)
  n=n%4294967296
  return string.char(math.floor(n/16777216)%256,math.floor(n/65536)%256,math.floor(n/256)%256,n%256)
 end
 local function _u64be(n)
  n=math.floor(n)
  local hi=math.floor(n/4294967296)%4294967296
  local lo=n%4294967296
  return _be32(hi).._be32(lo)
 end
 local function _sha256(msg)
  local len=#msg
  local bitlen=len*8
  local pad=string.char(0x80)
  local rem=(len+1)%64
  local zeros=(56-rem)%64
  msg=msg..pad..string.rep("\0",zeros).._u64be(bitlen)
  local H={0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19}
  local W={}
  for base=1,#msg,64 do
   for i=0,15 do W[i+1]=u32(msg,base+i*4) end
   for i=17,64 do
    local x=W[i-15];local y=W[i-2]
    local s0=bxor3(ror(x,7),ror(x,18),rshift(x,3))
    local s1=bxor3(ror(y,17),ror(y,19),rshift(y,10))
    W[i]=addn(W[i-16],s0,W[i-7],s1)
   end
   local a,b,c,d,e,f,g,h=H[1],H[2],H[3],H[4],H[5],H[6],H[7],H[8]
   for i=1,64 do
    local S1=bxor3(ror(e,6),ror(e,11),ror(e,25))
    local ch=bx(band(e,f),band((4294967295-e)%4294967296,g))
    local t1=addn(h,S1,ch,_k[i],W[i])
    local S0=bxor3(ror(a,2),ror(a,13),ror(a,22))
    local maj=bor(bor(band(a,b),band(a,c)),band(b,c))
    local t2=add32(S0,maj)
    h=g;g=f;f=e;e=add32(d,t1);d=c;c=b;b=a;a=add32(t1,t2)
   end
   H[1]=add32(H[1],a);H[2]=add32(H[2],b);H[3]=add32(H[3],c);H[4]=add32(H[4],d)
   H[5]=add32(H[5],e);H[6]=add32(H[6],f);H[7]=add32(H[7],g);H[8]=add32(H[8],h)
  end
  local out="";for i=1,8 do out=out.._be32(H[i]) end;return out
 end
 local function _hmac256(key,msg)
  if #key>64 then key=_sha256(key) end
  key=key..string.rep("\0",64-#key)
  local iop="";local oop="";for i=1,64 do local c=string.byte(key,i);iop=iop..string.char(bx(c,0x36));oop=oop..string.char(bx(c,0x5c))end
  return _sha256(oop.._sha256(iop..msg))
 end
 local function _stream(key,nonce,n)
  local out="";local counter=0
  while #out<n do
   out=out.._sha256(key..nonce.._be32(counter));counter=counter+1
  end
  return out:sub(1,n)
 end
 local function decode(blob)
  if blob:sub(1,4)~="XVM5" then error("XVM header")end
  if string.byte(blob,5)~=5 then error("XVM version")end
  if string.byte(blob,6)~=2 then error("XVM cipher version")end
  local keylen=string.byte(blob,7);if not keylen or keylen<24 or keylen>64 then error("XVM key length")end
  local build=blob:sub(8,15);local nonce=blob:sub(16,31);local key=blob:sub(32,31+keylen)
  if #key~=keylen then error("XVM key")end
  local mapStart=32+keylen;local inv={}
  for canonical=1,42 do local encoded=string.byte(blob,mapStart+canonical-1);if not encoded then error("XVM opcode map")end;inv[encoded]=canonical end
  local tagStart=mapStart+42;local tag=blob:sub(tagStart,tagStart+31)
  local cipherStart=tagStart+32;local ciphertext=blob:sub(cipherStart)
  if #tag~=32 or #ciphertext==0 then error("XVM payload")end
  local signed=blob:sub(1,31+keylen+42)..ciphertext
  local want=_hmac256(key,signed)
  if want~=tag then error("XVM integrity")end
  local stream=_stream(key,nonce,#ciphertext);local raw={}
  for i=1,#ciphertext do raw[i]=string.char(bx(string.byte(ciphertext,i),string.byte(stream,i))) end
  local data=table.concat(raw)
  return parse_fn(data,1,inv,key)
 end
 local _unpack=((type(table)=="table" and type(table.unpack)=="function") and table.unpack) or ((type(unpack)=="function") and unpack)
 if type(_unpack)~="function" then
  _unpack=function(t)
   if type(t)~="table" then return t end
   local n=#t
   if n==0 then return nil end
   if n==1 then return t[1] end
   if n==2 then return t[1],t[2] end
   if n==3 then return t[1],t[2],t[3] end
   if n==4 then return t[1],t[2],t[3],t[4] end
   return t[1],t[2],t[3],t[4],t[5]
  end
 end
 local function _env()
  -- Capture the actual script environment first. Roblox/Luau still exposes
  -- getfenv for compatibility; _G alone can miss script-scoped globals.
  if type(getfenv)=="function" then
   local ok,e=pcall(getfenv,1)
   if ok and type(e)=="table" then return e end
  end
  if type(_ENV)=="table" then return _ENV end
  if type(_G)=="table" then return _G end
  return {}
 end
 -- Some Luau/Roblox execution contexts expose standard globals through the
 -- script environment without mirroring them into the table returned above.
 -- Keep direct host references as a final lookup layer so CALLNAME("print")
 -- and other ordinary global calls cannot become a false nil target.
 local _builtins={
  print=print,type=type,tostring=tostring,tonumber=tonumber,
  pairs=pairs,ipairs=ipairs,next=next,select=select,
  pcall=pcall,xpcall=xpcall,error=error,assert=assert,
  getmetatable=getmetatable,setmetatable=setmetatable,
  rawget=rawget,rawset=rawset,rawequal=rawequal,
  string=string,table=table,math=math,coroutine=coroutine,
  utf8=utf8,os=os
 }
 -- Roblox/Luau hosts can expose engine globals through a separate
 -- execution environment rather than the ordinary _G table.
 local _hostenvs={}
 local function _capture_hostenv(fn)
  if type(fn)=="function" then
   local ok,e=pcall(fn)
   if ok and type(e)=="table" then _hostenvs[#_hostenvs+1]=e end
  end
 end
 _capture_hostenv(getgenv)
 _capture_hostenv(getrenv)
 local function truth(v)return v~=false and v~=nil end
 local function closure(proto,env,run)return {__xvm=true,proto=proto,env=env,run=run}end
 local function getv(frame,key)
  local e=frame.env
  while e do
   if e.__locals and e.__locals[key] then return e[key] end
   local v=e[key];if v~=nil then return v end
   e=e.__parent
  end
  local r=frame.root
  if type(r)=="table" then
   local v=r[key];if v~=nil then return v end
  end
  if type(_G)=="table" then
   local v=_G[key];if v~=nil then return v end
  end
  for i=1,#_hostenvs do
   local h=_hostenvs[i]
   local v=h[key]
   if v~=nil then return v end
  end
  local b=_builtins[key]
  if b~=nil then return b end
  return nil
 end
 local function setv(frame,key,v)
  local e=frame.env
  while e do
   if e.__locals and e.__locals[key] then e[key]=v;return end
   e=e.__parent
  end
  frame.env[key]=v;frame.env.__locals=frame.env.__locals or {};frame.env.__locals[key]=true
 end
 local function run(proto,args,parent,root)
  local f={env={__parent=parent,__locals={}},root=root,stack={},top=0,pc=1}
  local function push(x)f.top=f.top+1;f.stack[f.top]=x end
  local function pop()local x=f.stack[f.top];f.stack[f.top]=nil;f.top=f.top-1;return x end
  local function expand_args(raw)
   local out={}
   for i=1,#raw do
    local v=raw[i]
    if type(v)=="table" and v.__xvm_vararg then
     for j=1,#v.values do out[#out+1]=v.values[j] end
    else out[#out+1]=v end
   end
   return out
  end
  local function call_native(fn,aa)
   local packed=expand_args(aa);return pcall(fn,_unpack(packed))
  end
  for i=1,#args do f.env["@A"..i]=args[i];f.env.__locals["@A"..i]=true end
  for i=proto.argc+1,#args do f.varargs[#f.varargs+1]=args[i] end
  while true do
   local ins=proto.code[f.pc];if not ins then return nil end;f.pc=f.pc+1
   local op=ins[1];local a=ins[2]
   if op==1 then push(proto.consts[a+1])
   elseif op==2 then push(getv(f,proto.names[a+1]))
   elseif op==3 then setv(f,proto.names[a+1],pop())
   elseif op==4 then
    local k=pop();local t=pop();
    if t==nil then error("XVM index: attempt to index nil")end
    local ok,v=pcall(function() return t[k] end);if not ok then error(v)end;push(v)
   elseif op==5 then
    local v=pop();local k=pop();local t=pop();
    if t==nil then error("XVM index assignment: attempt to index nil")end
    local ok,err=pcall(function() t[k]=v end);if not ok then error(err)end
   elseif op==6 then push({})
   elseif op==7 then local b=pop();local x=pop();push(x+b)
   elseif op==8 then local b=pop();local x=pop();push(x-b)
   elseif op==9 then local b=pop();local x=pop();push(x*b)
   elseif op==10 then local b=pop();local x=pop();push(x/b)
   elseif op==11 then local b=pop();local x=pop();push(x%b)
   elseif op==12 then local b=pop();local x=pop();push(x^b)
   elseif op==13 then local b=pop();local x=pop();push(tostring(x)..tostring(b))
   elseif op==14 then local b=pop();local x=pop();push(x==b)
   elseif op==15 then local b=pop();local x=pop();push(x~=b)
   elseif op==16 then local b=pop();local x=pop();push(x<b)
   elseif op==17 then local b=pop();local x=pop();push(x<=b)
   elseif op==18 then local b=pop();local x=pop();push(x>b)
   elseif op==19 then local b=pop();local x=pop();push(x>=b)
   elseif op==20 then push(-pop())
   elseif op==21 then push(not truth(pop()))
   elseif op==22 then push(#pop())
   elseif op==40 then
    local packed=a;local namei=math.floor(packed/4096);local n=math.floor((packed%4096)/256);local retc=packed%256;if retc<1 then retc=1 end
    local aa={};for j=n,1,-1 do aa[j]=pop()end
    local fn=getv(f,proto.names[namei+1]);if fn==nil and _G then fn=_G[proto.names[namei+1]] end
    if type(fn)=="table" and fn.__xvm then
      local rr={run(fn.proto,aa,fn.env,root)};for j=1,retc do push(rr[j])end
    elseif type(fn)=="function" then
      for j=1,#aa do local av=aa[j];if type(av)=="table" and av.__xvm then local pp=av.proto;local ee=av.env;aa[j]=function(...)return run(pp,{...},ee,root)end end end
      local packedr={call_native(fn,aa)};if not packedr[1] then error(packedr[2])end;for j=1,retc do push(packedr[j+1])end
    else error("XVM call target nil: "..proto.names[namei+1]) end
   elseif op==41 then
    local packed=a;local n=math.floor(packed/256);local retc=packed%256;if retc<1 then retc=1 end
    local aa={};for j=n,1,-1 do aa[j]=pop()end;local key=pop();local obj=pop()
    if obj==nil then error("XVM method receiver nil: "..tostring(key))end
    local ok,fn=pcall(function()return obj[key]end);if not ok then error(fn)end
    if type(fn)=="table" and fn.__xvm then
      local ma={obj};for j=1,#aa do ma[#ma+1]=aa[j] end
      local rr={run(fn.proto,ma,fn.env,root)};for j=1,retc do push(rr[j])end
    elseif type(fn)=="function" then
      for j=1,#aa do local av=aa[j];if type(av)=="table" and av.__xvm then local pp=av.proto;local ee=av.env;aa[j]=function(...)return run(pp,{...},ee,root)end end end
      local packedr={pcall(fn,obj,_unpack(expand_args(aa)))};if not packedr[1] then error(packedr[2])end;for j=1,retc do push(packedr[j+1])end
    else error("XVM method target nil: "..tostring(key)) end
   elseif op==23 then
    local packed=a;local n=math.floor(packed/256);local retc=packed%256;if retc<1 then retc=1 end
    local aa={};for j=n,1,-1 do aa[j]=pop()end;local fn=pop()
    local function push_results(...)
     local rr={...}
     for j=1,retc do push(rr[j]) end
    end
    if type(fn)=="table" and fn.__xvm then
     push_results(run(fn.proto,aa,fn.env,root))
    elseif type(fn)=="function" then
     for j=1,#aa do
      local av=aa[j]
      if type(av)=="table" and av.__xvm then
       local p=av.proto;local e=av.env
       aa[j]=function(...) local va={...};return run(p,va,e,root)end
      end
     end
     local packed={call_native(fn,aa)};if not packed[1] then error(packed[2])end
     for j=1,retc do push(packed[j+1]) end
    else
     -- Luau/Roblox can expose callable objects through a __call metamethod.
     -- Treat them as native callables instead of reporting a misleading target error.
     local mt=nil
     if type(fn)=="table" or type(fn)=="userdata" then
      local mok,m=pcall(getmetatable,fn);if mok then mt=m end
     end
     local callmeta=mt and mt.__call or nil
     if type(callmeta)=="function" then
      local packed={pcall(callmeta,fn,_unpack(expand_args(aa)))};if not packed[1] then error(packed[2])end
      for j=1,retc do push(packed[j+1]) end
     else
      error("XVM call target: "..tostring(type(fn)))
     end
    end
   elseif op==24 then pop()
   elseif op==25 then f.pc=a+1
   elseif op==26 then if not truth(pop())then f.pc=a+1 end
   elseif op==27 then if truth(pop())then f.pc=a+1 end
   elseif op==28 then push(closure(proto.children[a+1],f.env,run))
   elseif op==29 then
    local n=a
    if n<0 then return _unpack(f.varargs) end
    local r={};for j=n,1,-1 do r[j]=pop()end
    if n>0 and type(r[1])=="table" and r[1].__xvm_vararg then return _unpack(r[1].values) end
    return _unpack(r)
   elseif op==31 then return nil
   elseif op==32 then push(f.stack[f.top])
   elseif op==33 then local b=pop();local x=pop();push(truth(x) and b or x)
   elseif op==34 then local b=pop();local x=pop();push(truth(x) and x or b)
   elseif op==35 then -- polymorphic NOP
   elseif op==36 then local q=(f.pc*17+7)%23;if q<0 then error("XVM opaque predicate")end
   elseif op==39 then
    local n=a;local t={};for j=n,1,-1 do t[j]=pop()end;push(t)
   elseif op==37 then
    local step=pop();local limit=pop();local init=pop();if step==0 then error("XVM numeric for step is zero")end
    f.forstate=f.forstate or {};f.forstate[a]={limit=limit,step=step,current=init,name=proto.names[a+1]}
    setv(f,proto.names[a+1],init);push((step>0 and init<=limit) or (step<0 and init>=limit))
   elseif op==38 then
    local st=f.forstate and f.forstate[a];if not st then error("XVM for state")end;st.current=st.current+st.step;setv(f,st.name,st.current);push((st.step>0 and st.current<=st.limit) or (st.step<0 and st.current>=st.limit))
   elseif op==30 then
    -- Generic-for iterator bridge. First pass consumes the packed iterator triple;
    -- subsequent passes reuse the saved iterator/state/control values.
    local packed=a;local namei=packed%4096;local count=math.floor(packed/4096)
    f.iterstate=f.iterstate or {}
    local st=f.iterstate[namei]
    if not st then
      local triple=pop();if type(triple)~="table" then error("XVM iterator setup")end
      st={fn=triple[1],state=triple[2],control=triple[3]};f.iterstate[namei]=st
    end
    if type(st.fn)~="function" then error("XVM iterator is not callable")end
    local ok,a1,a2,a3,a4=pcall(st.fn,st.state,st.control)
    if not ok then error(a1)end
    if a1==nil then push(false) else
      st.control=a1
      local vals={a1,a2,a3,a4}
      for j=count,1,-1 do push(vals[j]) end
      push(true)
    end
   elseif op==42 then
    local n=a
    if n<=0 then push({__xvm_vararg=true,values=f.varargs})
    else for j=1,n do push(f.varargs[j]) end end
   else error("XVM opcode "..tostring(op))end
  end
 end
 return function(blob,env)local e=env or _env();return run(decode(blob),{},e,e)end
end)()
'''
