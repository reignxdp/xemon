import random
import os
from bytecode_vm import compile_source, LUA_VM_RUNTIME
from syntax_validator import validate_generated_lua
from anti_tamper_v2 import ANTI_TAMPER_V2
from diagnostics import DiagnosticReport, preflight_source, validate_output, blob_header, smoke_test_generated_lua, report_to_json

_NOISE = '!@#$?&%^~<>|'
_NOISE_POOL = _NOISE + 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'


def _compact_lua(src):
    """Minify Lua/Luau without touching quoted strings."""
    out=[]; i=0; n=len(src); quote=None; prev=''
    while i<n:
        c=src[i]
        if quote:
            out.append(c)
            if c=='\\' and i+1<n:
                out.append(src[i+1]); i+=2; continue
            if c==quote: quote=None
            i+=1; prev=c; continue
        if c in "'\"":
            quote=c; out.append(c); i+=1; prev=c; continue
        if c=='-' and i+1<n and src[i+1]=='-':
            i+=2
            if i<n and src[i]=='[':
                end=src.find(']]', i+1)
                i=n if end<0 else end+2
            else:
                end=src.find('\n', i)
                i=n if end<0 else end+1
            continue
        if c.isspace():
            j=i
            while j<n and src[j].isspace(): j+=1
            nxt=src[j] if j<n else ''
            if out and nxt and ((out[-1].isalnum() or out[-1] in '_') and (nxt.isalnum() or nxt=='_')):
                out.append(' ')
            i=j; continue
        out.append(c); i+=1; prev=c
    return ''.join(out)


def _mangle_identifiers(src, names):
    """Rename selected identifiers while preserving strings/comments."""
    mapping={name: 'l'+''.join(random.choice('l1Ii') for _ in range(random.randint(8,15))) for name in names}
    out=[]; i=0; n=len(src); quote=None
    while i<n:
        c=src[i]
        if quote:
            out.append(c)
            if c=='\\' and i+1<n: out.append(src[i+1]); i+=2; continue
            if c==quote: quote=None
            i+=1; continue
        if c in "'\"": quote=c; out.append(c); i+=1; continue
        if c=='-' and i+1<n and src[i+1]=='-':
            j=src.find('\n',i)
            if j<0: out.append(src[i:]); break
            out.append(src[i:j]); i=j; continue
        if c.isalpha() or c=='_':
            j=i+1
            while j<n and (src[j].isalnum() or src[j]=='_'): j+=1
            word=src[i:j]
            out.append(mapping.get(word,word)); i=j; continue
        out.append(c); i+=1
    return ''.join(out)


def _strip_lua_comments(src):
    out=[]; i=0; n=len(src); quote=None
    while i<n:
        c=src[i]
        if quote:
            out.append(c)
            if c=='\\' and i+1<n:
                out.append(src[i+1]); i+=2; continue
            if c==quote: quote=None
            i+=1; continue
        if c in "\"'":
            quote=c; out.append(c); i+=1; continue
        if c=='-' and i+1<n and src[i+1]=='-':
            while i<n and src[i]!='\n': i+=1
            if i<n: out.append('\n'); i+=1
            continue
        out.append(c); i+=1
    return ''.join(out)



class LuaObfuscator:
    def __init__(self):
        self.used_names = set()

    def _gen_name(self, min_len=10, max_len=18):
        chars = 'l1Ii'
        starters = 'lIi'
        length = random.randint(min_len, max_len)
        while True:
            name = random.choice(starters) + ''.join(random.choice(chars) for _ in range(length - 1))
            if name not in self.used_names:
                self.used_names.add(name)
                return name

    def _num_lit(self, low=0x1000, high=0xFFFFFF):
        val = random.randint(low, high)
        fmt = random.randint(0, 2)
        if fmt == 0:
            return f"0x{val:X}"
        elif fmt == 1:
            return f"0b{bin(val)[2:]}"
        else:
            return f"0x{val:x}"

    def _math_expr(self, target):
        a = random.randint(0x1000, 0xFFFF)
        b = random.randint(0x100, 0xFFF)
        c = target - a + b
        fa, fb, fc = self._fmt_int(a), self._fmt_int(b), self._fmt_int(abs(c))
        return f"{fa}-{fb}+{fc}" if c >= 0 else f"{fa}-{fb}-{fc}"

    def _fmt_int(self, val):
        fmt = random.randint(0, 2)
        if fmt == 0:
            return f"0x{val:X}"
        elif fmt == 1:
            return f"0b{bin(val)[2:]}"
        else:
            return f"0x{val:x}"

    def _rand_math(self):
        a = random.randint(0x1000, 0xFFFFFF)
        b = random.randint(0x100, 0xFFFF)
        op = random.choice(['+', '-', '*'])
        if op == '*':
            b = random.randint(1, 0xF)
        return f"{self._fmt_int(a)}{op}{self._fmt_int(b)}"

    def _noise_str(self, mn=8, mx=30):
        n = random.randint(mn, mx)
        s = list(random.choice(_NOISE_POOL) for _ in range(n))
        for _ in range(random.randint(3, 8)):
            s[random.randint(0, n-1)] = random.choice('!@#!@#!@#$%^')
        return ''.join(s)

    def _junk_entry(self):
        key = self._num_lit(0x100000, 0xFFFFFF)
        t = random.randint(0, 7)
        if t == 0:
            n = random.randint(4, 15)
            esc = ''.join(f'\\{random.randint(32, 126):03d}' for _ in range(n))
            val = f'"@#{esc}#@"'
        elif t == 1:
            val = self._rand_math()
        elif t == 2:
            val = random.choice(["true", "false"])
        elif t == 3:
            vn = self._gen_name(6, 8)
            val = f"function({vn})return {vn} end"
        elif t == 4:
            val = f'"@#{self._noise_str()}#@"'
        elif t == 5:
            n = random.randint(3, 8)
            esc = ''.join(f'\\{random.randint(32, 126):03d}' for _ in range(n))
            val = f'"@#{esc}{self._noise_str(3, 8)}#@"'
        elif t == 6:
            noise = ''.join(random.choice('!@#$%^&*~<>|') for _ in range(random.randint(12, 40)))
            val = f'"@#{noise}#@"'
        else:
            noise = ''.join(random.choice('!@#$%^&*~<>|') for _ in range(random.randint(8, 30)))
            val = f'"{noise}"'
        return f"[{key}]={val}"

    def _byte_expr(self, target):
        a = random.randint(0x100, 0xFFF)
        b = random.randint(0x10, 0xFF)
        c = target - a + b
        fa, fb, fc = self._fmt_int(a), self._fmt_int(b), self._fmt_int(abs(c))
        return f"{fa}-{fb}+{fc}" if c >= 0 else f"{fa}-{fb}-{fc}"

    def _junk_stmt(self):
        t = random.randint(0, 5)
        if t == 0:
            return f"local {self._gen_name()}={self._num_lit()};"
        elif t == 1:
            return f"local {self._gen_name()}={self._rand_math()};"
        elif t == 2:
            fn, p = self._gen_name(), self._gen_name(6, 8)
            return f"local {fn}=function({p})return {p}+{self._num_lit()} end;"
        elif t == 3:
            return f'local {self._gen_name()}="@#{self._noise_str()}#@";'
        elif t == 4:
            noise = ''.join(random.choice('!@#!@#$%^&*~<>|!@#') for _ in range(random.randint(15, 50)))
            return f'local {self._gen_name()}="@#{noise}#@";'
        else:
            return f'local {self._gen_name()}="{self._noise_str()}";'

    def _junk_block(self, mn=5, mx=15):
        """Junk stmts wrapped in do...end to avoid Luau local register overflow."""
        count = random.randint(mn, mx)
        stmts = ''.join(self._junk_stmt() for _ in range(count))
        return f"do {stmts}end;"

    def _obfuscate_anti_tamper_inline(self, junk_entries=300, junk_block_size=(5, 12)):
        """INLINE anti-tamper with 31 checks + perf/timing. XOR-encrypted strings."""
        xor_key = random.randint(0x21, 0x7E)

        S = [
            # Globals (0-16) — XOR encrypted
            'CFrame','math','Random','error','task','pcall',
            'typeof','game','workspace','Instance','os','tostring',
            'Vector3','Vector2','UDim2','Region3int16','Vector3int16',
            # Keys (17-69) — XOR encrypted
            'Angles','rad','RightVector','UpVector','LookVector','Dot',
            'abs','max','new','NextNumber','Name','wait','function',
            'Loaded','IsDescendantOf','Parent','GetService','Players',
            'ClassName','IsClient','IsRunning','LocalPlayer','RunService',
            'Folder','BindableEvent','Event','Connect','Fire','Destroy',
            'tick','clock','find','DataModel','NonExistentProperty','X',
            'hits','xemon was here',
            'RemoteEvent','OnServerEvent','FireServer','Part','Original',
            'Clone','Cross','Z','Min','Y','Max','Lerp','Scale',
            'NextInteger','FindFirstChild','Something',
            # Bootstrap (70-74) — stored UNENCODED (needed to build decoder)
            'string','byte','char','bit32','bxor',
        ]

        used_keys = set()
        ekeys = []
        for _ in S:
            while True:
                k = random.randint(0x100000, 0xFFFFFF)
                if k not in used_keys:
                    used_keys.add(k)
                    ekeys.append(k)
                    break

        all_entries = []
        for idx, (key, s) in enumerate(zip(ekeys, S)):
            if idx >= 70:
                esc = ''.join(f'\\{b}' for b in s.encode('utf-8'))
            else:
                esc = ''.join(f'\\{b ^ xor_key}' for b in s.encode('utf-8'))
            all_entries.append(f'[{self._fmt_int(key)}]="{esc}"')
        for _ in range(junk_entries):
            all_entries.append(self._junk_entry())
        random.shuffle(all_entries)

        def K(i):
            return self._math_expr(ekeys[i])

        v = {}
        for n in [
            'T','E',
            'CF','MT','RN','ER','TK','PC','TO','GM','WS','IN','OS','TS',
            'V3','V2','UD','R3I','V3I',
            'kAng','krd','kRV','kUV','kLV','kDt','kab','kmx','kn','kNN',
            'kN','kw','kf','kL','kI','kP','kG','kPl','kC','kIc','kIr',
            'kLp','kRs','kFo','kBe','kEv','kCo','kFi','kDe','kTi','kCl',
            'kFn','kDm','kNe','kX','kH','kE',
            'kRE','kOSE','kFS','kPt','kOr','kCln','kCrs','kZ','kMn','kY',
            'kMx','kLrp','kSc','kNI','kFFC','kSm',
            'cR','aH','gI','pF','tF',
            'SL','SB','SC','BT','BX','xd','xk',
        ]:
            v[n] = self._gen_name()

        jb_min, jb_max = junk_block_size

        o = []

        # junk preamble
        o.append(self._junk_block(jb_min, jb_max))

        # table
        o.append(f"local {v['T']}={{{';'.join(all_entries)}}};")

        # junk (wrapped)
        o.append(self._junk_block(jb_min, jb_max))

        # bootstrap
        o.append(f"local {v['E']}=((type(_ENV)==\"table\" and _ENV) or _G);")

        # XOR decode setup: get string.byte, string.char, bit32.bxor from unencoded bootstrap entries
        o.append(f"local {v['SL']}={v['E']}[{v['T']}[{K(70)}]];")
        o.append(f"local {v['SB']}={v['SL']}[{v['T']}[{K(71)}]];")
        o.append(f"local {v['SC']}={v['SL']}[{v['T']}[{K(72)}]];")
        o.append(f"local {v['BT']}={v['E']}[{v['T']}[{K(73)}]];")
        o.append(f"local {v['BX']}={v['BT']}[{v['T']}[{K(74)}]];")
        o.append(f"local {v['xk']}={self._math_expr(xor_key)};")
        xp = self._gen_name(6, 8)
        xr = self._gen_name(6, 8)
        xi = self._gen_name(6, 8)
        o.append(f"local {v['xd']}=function({xp})local {xr}='';for {xi}=0x1,#{xp} do {xr}={xr}..{v['SC']}({v['BX']}({v['SB']}({xp},{xi}),{v['xk']}));end;return {xr};end;")

        o.append(self._junk_block(jb_min, jb_max))

        # globals (0-16) — decoded via xdec
        for vn, i in [('CF',0),('MT',1),('RN',2),('ER',3),('TK',4),('PC',5),
                       ('TO',6),('GM',7),('WS',8),('IN',9),('OS',10),('TS',11),
                       ('V3',12),('V2',13),('UD',14),('R3I',15),('V3I',16)]:
            o.append(f"local {v[vn]}={v['E']}[{v['xd']}({v['T']}[{K(i)}])];")

        o.append(self._junk_block(jb_min, jb_max))

        # keys (17-69) — decoded via xdec
        for vn, i in [('kAng',17),('krd',18),('kRV',19),('kUV',20),('kLV',21),
                       ('kDt',22),('kab',23),('kmx',24),('kn',25),('kNN',26),
                       ('kN',27),('kw',28),('kf',29),('kL',30),('kI',31),
                       ('kP',32),('kG',33),('kPl',34),('kC',35),('kIc',36),
                       ('kIr',37),('kLp',38),('kRs',39),('kFo',40),('kBe',41),
                       ('kEv',42),('kCo',43),('kFi',44),('kDe',45),('kTi',46),
                       ('kCl',47),('kFn',48),('kDm',49),('kNe',50),('kX',51),
                       ('kH',52),('kE',53),
                       ('kRE',54),('kOSE',55),('kFS',56),('kPt',57),('kOr',58),
                       ('kCln',59),('kCrs',60),('kZ',61),('kMn',62),('kY',63),
                       ('kMx',64),('kLrp',65),('kSc',66),('kNI',67),('kFFC',68),
                       ('kSm',69)]:
            o.append(f"local {v[vn]}={v['xd']}({v['T']}[{K(i)}]);")

        o.append(self._junk_block(jb_min, jb_max))

        # state: checkResults + addHit + gameInstance
        ah = self._gen_name(6, 8)
        ah2 = self._gen_name(6, 8)
        o.append(f"local {v['cR']}={{[{v['kH']}]={{}}}};")
        o.append(f"local {v['aH']}=function({ah}) local {ah2}={v['cR']}[{v['kH']}];{ah2}[#{ah2}+1]={ah} end;")
        o.append(f"local {v['gI']}={v['GM']};")

        o.append(self._junk_block(jb_min, jb_max))

        # ===== CHECK 16: CFrame vector lengths =====
        cf16 = self._gen_name(6, 8)
        id16 = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {cf16}={v['CF']}[{v['kAng']}]({v['MT']}[{v['krd']}](45),{v['MT']}[{v['krd']}](30),{v['MT']}[{v['krd']}](60));local {id16}={cf16}[{v['kRV']}][{v['kDt']}]({cf16}[{v['kRV']}],{cf16}[{v['kRV']}])+{cf16}[{v['kUV']}][{v['kDt']}]({cf16}[{v['kUV']}],{cf16}[{v['kUV']}])+{cf16}[{v['kLV']}][{v['kDt']}]({cf16}[{v['kLV']}],{cf16}[{v['kLV']}]);if {v['MT']}[{v['kab']}]({id16}-3)>=0.001 then {v['aH']}(16) end end);")
        o.append(self._junk_block(jb_min, jb_max))

        # ===== CHECK 17: CFrame orthogonality individual =====
        cf17 = self._gen_name(6, 8)
        d1 = self._gen_name(6, 8)
        d2 = self._gen_name(6, 8)
        d3 = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {cf17}={v['CF']}[{v['kAng']}]({v['MT']}[{v['krd']}](45),{v['MT']}[{v['krd']}](30),{v['MT']}[{v['krd']}](60));local {d1}={v['MT']}[{v['kab']}]({cf17}[{v['kRV']}][{v['kDt']}]({cf17}[{v['kRV']}],{cf17}[{v['kUV']}]));local {d2}={v['MT']}[{v['kab']}]({cf17}[{v['kRV']}][{v['kDt']}]({cf17}[{v['kRV']}],{cf17}[{v['kLV']}]));local {d3}={v['MT']}[{v['kab']}]({cf17}[{v['kUV']}][{v['kDt']}]({cf17}[{v['kUV']}],{cf17}[{v['kLV']}]));if {d1}>=0.001 or {d2}>=0.001 or {d3}>=0.001 then {v['aH']}(17) end end);")

        # ===== CHECK 18: CFrame orthogonality sum =====
        cf18 = self._gen_name(6, 8)
        sl18 = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {cf18}={v['CF']}[{v['kAng']}]({v['MT']}[{v['krd']}](45),{v['MT']}[{v['krd']}](30),{v['MT']}[{v['krd']}](60));local {sl18}={v['MT']}[{v['kab']}]({cf18}[{v['kRV']}][{v['kDt']}]({cf18}[{v['kRV']}],{cf18}[{v['kUV']}]))+{v['MT']}[{v['kab']}]({cf18}[{v['kRV']}][{v['kDt']}]({cf18}[{v['kRV']}],{cf18}[{v['kLV']}]))+{v['MT']}[{v['kab']}]({cf18}[{v['kUV']}][{v['kDt']}]({cf18}[{v['kUV']}],{cf18}[{v['kLV']}]));if {sl18}>=0.003 then {v['aH']}(18) end end);")
        o.append(self._junk_block(jb_min, jb_max))

        # ===== CHECK 19: CFrame orthogonality max =====
        cf19 = self._gen_name(6, 8)
        mx19 = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {cf19}={v['CF']}[{v['kAng']}]({v['MT']}[{v['krd']}](45),{v['MT']}[{v['krd']}](30),{v['MT']}[{v['krd']}](60));local {mx19}={v['MT']}[{v['kmx']}]({v['MT']}[{v['kab']}]({cf19}[{v['kRV']}][{v['kDt']}]({cf19}[{v['kRV']}],{cf19}[{v['kUV']}])),{v['MT']}[{v['kab']}]({cf19}[{v['kRV']}][{v['kDt']}]({cf19}[{v['kRV']}],{cf19}[{v['kLV']}])),{v['MT']}[{v['kab']}]({cf19}[{v['kUV']}][{v['kDt']}]({cf19}[{v['kUV']}],{cf19}[{v['kLV']}])));if {mx19}>=0.001 then {v['aH']}(19) end end);")

        o.append(self._junk_block(jb_min, jb_max))

        # ===== CHECK 20: Random NextNumber =====
        rn20 = self._gen_name(6, 8)
        rn20v = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {rn20}={v['RN']}[{v['kn']}]();local {rn20v}={rn20}[{v['kNN']}]({rn20});if {rn20v}<0 or {rn20v}>1 then {v['aH']}(20) end end);")

        o.append(self._junk_block(jb_min, jb_max))

        # ===== CHECK 21: RemoteEvent =====
        rem21 = self._gen_name(6, 8)
        rcv21 = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {rem21}={v['IN']}[{v['kn']}]({v['kRE']});local {rcv21}=false;{rem21}[{v['kOSE']}][{v['kCo']}]({rem21}[{v['kOSE']}],function() {rcv21}=true end);{rem21}[{v['kFS']}]({rem21});{v['TK']}[{v['kw']}]();if not {rcv21} then {v['aH']}(21) end;{rem21}[{v['kDe']}]({rem21}) end);")
        o.append(self._junk_block(jb_min, jb_max))

        # ===== CHECK 22: Clone =====
        op22 = self._gen_name(6, 8)
        cl22 = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {op22}={v['IN']}[{v['kn']}]({v['kPt']});{op22}[{v['kN']}]={v['kOr']};local {cl22}={op22}[{v['kCln']}]({op22});if {cl22}[{v['kN']}]~={v['kOr']} or {cl22}=={op22} then {v['aH']}(22) end;{op22}[{v['kDe']}]({op22});if {cl22} then {cl22}[{v['kDe']}]({cl22}) end end);")

        o.append(self._junk_block(jb_min, jb_max))

        # ===== CHECK 23: Vector3 Cross =====
        va23 = self._gen_name(6, 8)
        vb23 = self._gen_name(6, 8)
        cr23 = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {va23}={v['V3']}[{v['kn']}](1,0,0);local {vb23}={v['V3']}[{v['kn']}](0,1,0);local {cr23}={va23}[{v['kCrs']}]({va23},{vb23});if {cr23}[{v['kZ']}]~=1 then {v['aH']}(23) end end);")

        # ===== CHECK 24: Vector3 Min =====
        va24 = self._gen_name(6, 8)
        vb24 = self._gen_name(6, 8)
        mn24 = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {va24}={v['V3']}[{v['kn']}](5,2,8);local {vb24}={v['V3']}[{v['kn']}](3,4,6);local {mn24}={va24}[{v['kMn']}]({va24},{vb24});if {mn24}[{v['kX']}]~=3 or {mn24}[{v['kY']}]~=2 or {mn24}[{v['kZ']}]~=6 then {v['aH']}(24) end end);")
        o.append(self._junk_block(jb_min, jb_max))

        # ===== CHECK 25: Vector3 Max =====
        va25 = self._gen_name(6, 8)
        vb25 = self._gen_name(6, 8)
        mx25 = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {va25}={v['V3']}[{v['kn']}](5,2,8);local {vb25}={v['V3']}[{v['kn']}](3,4,6);local {mx25}={va25}[{v['kMx']}]({va25},{vb25});if {mx25}[{v['kX']}]~=5 or {mx25}[{v['kY']}]~=4 or {mx25}[{v['kZ']}]~=8 then {v['aH']}(25) end end);")

        o.append(self._junk_block(jb_min, jb_max))

        # ===== CHECK 26: UDim2 Lerp =====
        ua26 = self._gen_name(6, 8)
        ub26 = self._gen_name(6, 8)
        lr26 = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {ua26}={v['UD']}[{v['kn']}](0,0,0,0);local {ub26}={v['UD']}[{v['kn']}](1,0,1,0);local {lr26}={ua26}[{v['kLrp']}]({ua26},{ub26},0.5);if {v['MT']}[{v['kab']}]({lr26}[{v['kX']}][{v['kSc']}]-0.5)>=0.001 then {v['aH']}(26) end end);")
        o.append(self._junk_block(jb_min, jb_max))

        # ===== CHECK 27: Random NextInteger =====
        rg27 = self._gen_name(6, 8)
        ri27 = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {rg27}={v['RN']}[{v['kn']}]();local {ri27}={rg27}[{v['kNI']}]({rg27},1,10);if {ri27}<1 or {ri27}>10 then {v['aH']}(27) end end);")

        o.append(self._junk_block(jb_min, jb_max))

        # ===== CHECK 28: Region3int16 =====
        suc28 = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {suc28}={v['PC']}(function() return {v['R3I']}[{v['kn']}]({v['V3I']}[{v['kn']}](0,0,0),{v['V3I']}[{v['kn']}](10,10,10)) end);if not {suc28} then {v['aH']}(28) end end);")

        # ===== CHECK 29: FindFirstChild recursive =====
        pt29 = self._gen_name(6, 8)
        dp29 = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {pt29}={v['IN']}[{v['kn']}]({v['kPt']});local {dp29}={pt29}[{v['kFFC']}]({pt29},{v['kSm']},true);if {dp29}~=nil then {v['aH']}(29) end;{pt29}[{v['kDe']}]({pt29}) end);")

        o.append(self._junk_block(jb_min, jb_max))

        # ===== CHECK 30: Vector2 Dot =====
        va30 = self._gen_name(6, 8)
        vb30 = self._gen_name(6, 8)
        dt30 = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {va30}={v['V2']}[{v['kn']}](1,0);local {vb30}={v['V2']}[{v['kn']}](0,1);local {dt30}={va30}[{v['kDt']}]({va30},{vb30});if {dt30}~=0 then {v['aH']}(30) end end);")

        # ===== CHECK 31: Vector3 Dot =====
        va31 = self._gen_name(6, 8)
        vb31 = self._gen_name(6, 8)
        dt31 = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {va31}={v['V3']}[{v['kn']}](1,0,0);local {vb31}={v['V3']}[{v['kn']}](0,1,0);local {dt31}={va31}[{v['kDt']}]({va31},{vb31});if {dt31}~=0 then {v['aH']}(31) end end);")

        o.append(self._junk_block(jb_min, jb_max))

        # ===== OLD CHECKS 1-15 =====
        # 1
        o.append(f"{v['PC']}(function() if {v['gI']} and {v['gI']}[{v['kL']}]==nil then {v['aH']}(1) end end);")
        # 2
        t = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {t}={v['WS']};if {t} and not {t}[{v['kI']}]({t},{v['gI']}) then {v['aH']}(2) end end);")
        # 3
        o.append(f"{v['PC']}(function() if {v['gI']} and {v['gI']}[{v['kP']}]~=nil then {v['aH']}(3) end end);")
        o.append(self._junk_block(jb_min, jb_max))
        # 4
        t = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {t}={v['gI']} and {v['gI']}[{v['kG']}]({v['gI']},{v['kPl']});if {t} and {t}[{v['kC']}]~={v['kPl']} then {v['aH']}(4) end end);")
        # 5
        t = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {t}={v['IN']}[{v['kn']}]({v['IN']},{v['kFo']});if {v['TO']}({t})~={v['xd']}({v['T']}[{K(9)}]) then {v['aH']}(5) end;{t}[{v['kDe']}]({t}) end);")
        # 6
        t = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {t}={v['gI']} and {v['gI']}[{v['kG']}]({v['gI']},{v['kRs']});if {t} and {t}[{v['kIc']}] and {t}[{v['kIc']}]({t})~=true then {v['aH']}(6) end end);")
        o.append(self._junk_block(jb_min, jb_max))
        # 7
        ts7 = self._gen_name(6, 8)
        te7 = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {ts7}={v['OS']}[{v['kTi']}]();{v['TK']}[{v['kw']}]();local {te7}={v['OS']}[{v['kTi']}]();if({te7}-{ts7})<0 then {v['aH']}(7) end end);")
        # 8
        tf8 = self._gen_name(6, 8)
        ts8 = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {tf8}=function() end;local {ts8}={v['TS']}({tf8});if {ts8}[{v['kFn']}]({ts8},{v['kf']})==nil then {v['aH']}(8) end end);")
        # 9
        o.append(f"{v['PC']}(function() if {v['gI']} and {v['gI']}[{v['kC']}]~={v['kDm']} then {v['aH']}(9) end end);")
        o.append(self._junk_block(jb_min, jb_max))
        # 10
        tp10 = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {tp10}={v['PC']}(function() return {v['gI']}[{v['kNe']}] end);if {tp10} then {v['aH']}(10) end end);")
        # 11
        t = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {t}={v['gI']} and {v['gI']}[{v['kG']}]({v['gI']},{v['kRs']});if {t} and {t}[{v['kIr']}] and not {t}[{v['kIr']}]({t}) then {v['aH']}(11) end end);")
        o.append(self._junk_block(jb_min, jb_max))
        # 12
        tp12 = self._gen_name(6, 8)
        tl12 = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {tp12}={v['gI']} and {v['gI']}[{v['kG']}]({v['gI']},{v['kPl']});local {tl12}={tp12} and {tp12}[{v['kLp']}];if {tl12} and {tl12}[{v['kP']}]~={tp12} then {v['aH']}(12) end end);")
        # 13
        t = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {t}={v['IN']}[{v['kn']}]({v['IN']},{v['kFo']});{t}[{v['kN']}]={v['kX']};if {t}[{v['kN']}]~={v['kX']} then {v['aH']}(13) end;{t}[{v['kDe']}]({t}) end);")
        # 14
        tb14 = self._gen_name(6, 8)
        tf14 = self._gen_name(6, 8)
        tev14 = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {tb14}={v['IN']}[{v['kn']}]({v['IN']},{v['kBe']});local {tf14}=false;local {tev14}={tb14}[{v['kEv']}];{tev14}[{v['kCo']}]({tev14},function() {tf14}=true end);{tb14}[{v['kFi']}]({tb14});{v['TK']}[{v['kw']}]();if not {tf14} then {v['aH']}(14) end;{tb14}[{v['kDe']}]({tb14}) end);")
        o.append(self._junk_block(jb_min, jb_max))
        # 15
        ts15 = self._gen_name(6, 8)
        te15 = self._gen_name(6, 8)
        o.append(f"{v['PC']}(function() local {ts15}={v['OS']}[{v['kCl']}]();{v['TK']}[{v['kw']}](0.05);local {te15}={v['OS']}[{v['kCl']}]();if({te15}-{ts15})<0.01 then {v['aH']}(15) end end);")

        o.append(self._junk_block(jb_min, jb_max))

        # performance test
        ps = self._gen_name(6, 8)
        pc2 = self._gen_name(6, 8)
        pi = self._gen_name(6, 8)
        o.append(f"local {v['pF']}=function() local {ps}={v['OS']}[{v['kCl']}]();local {pc2}=0;for {pi}=1,10000 do {pc2}={pc2}+1 end;return({v['OS']}[{v['kCl']}]()-{ps})<0.05 end;")

        # timing test
        fc = self._gen_name(6, 8)
        sc = self._gen_name(6, 8)
        ti = self._gen_name(6, 8)
        st = self._gen_name(6, 8)
        et = self._gen_name(6, 8)
        o.append(f"local {v['tF']}=function() local {fc},{sc}=0,0;for {ti}=1,5 do local {st}={v['OS']}[{v['kCl']}]();{v['TK']}[{v['kw']}](0.01);local {et}={v['OS']}[{v['kCl']}]();if({et}-{st})>0.005 then {fc}={fc}+1 else {sc}={sc}+1 end end;return {fc}>2 end;")

        o.append(self._junk_block(jb_min, jb_max))

        # final validation
        pr = self._gen_name(6, 8)
        tr = self._gen_name(6, 8)
        o.append(f"local {pr}={v['pF']}();if not {pr} then {v['aH']}(101) end;")
        o.append(f"local {tr}={v['tF']}();if not {tr} then {v['aH']}(102) end;")
        o.append(f"if #{v['cR']}[{v['kH']}]>0 or not {pr} or not {tr} then {v['ER']}({v['kE']}) end;")

        o.append(self._junk_block(jb_min*2, jb_max*2))

        return ''.join(o)

    def _obfuscate_vm_block(self, code, anti_tamper_source=None, anti_tamper_debug=False, anti_tamper_strict=False, report=None):
        """Compile source and optional anti-tamper source into separate XVM5 blobs.
        No source form of the anti-tamper is emitted; both programs are interpreted by
        the same protected VM runtime."""
        user_blob = compile_source(code)
        anti_blob = compile_source(anti_tamper_source) if anti_tamper_source else None
        if report is not None:
            blob_header(user_blob, report, "USER")
            report.metrics["user_bytecode_size"] = len(user_blob)
            if anti_blob is not None:
                blob_header(anti_blob, report, "ANTI_TAMPER")
                report.metrics["anti_tamper_bytecode_size"] = len(anti_blob)
            report.metrics["anti_tamper_execution"] = "xvm_bytecode" if anti_blob is not None else "disabled"
        def pack_blob(blob):
            chunk_size = 192
            chunks = [blob[i:i + chunk_size] for i in range(0, len(blob), chunk_size)]
            perm = list(range(len(chunks))); random.shuffle(perm)
            ordered = [chunks[original_index] for original_index in perm]
            inverse = [0] * len(perm)
            for pos, original_index in enumerate(perm): inverse[original_index] = pos + 1
            return ordered, inverse

        def lua_bytes(bs):
            return '"' + ''.join("\\%03d" % b for b in bs) + '"'

        def emit_chunks(blob):
            chunks, inverse = pack_blob(blob)
            tbl=self._gen_name(); order=self._gen_name(); parts=self._gen_name(); idx=self._gen_name(); encvar=self._gen_name()
            o=[]; o.append('local '+tbl+'={')
            for pos in range(len(chunks)):
                o.append(lua_bytes(chunks[pos])+',')
            o.append('};local '+order+'={'+','.join(str(x) for x in inverse)+'};local '+parts+'={};for '+idx+'=1,#'+order+' do '+parts+'['+idx+']='+tbl+'['+order+'['+idx+']];end;local '+encvar+'=table.concat('+parts+');')
            return ''.join(o), encvar

        user_decl, user_enc = emit_chunks(user_blob)
        anti_decl, anti_enc = emit_chunks(anti_blob) if anti_blob is not None else ('', None)
        vm_runtime=LUA_VM_RUNTIME
        vm_names=["XEMON_VM","bx","u8","u16","u32","i32","i64","f64","sval","parse_fn","f","decode","truth","closure","getv","setv","run","frame","push","pop","proto","args","parent","root","blob","env","nonce","inv","canonical","encoded","raw","data","want","h","ins","op","a","b","x","t","k","v","j","fn","aa","r","ok","r1","r2","r3","r4","r5","flags","build","chk","h1","h2"]
        vm_alias='l'+''.join(random.choice('l1Ii') for _ in range(16))
        vm_runtime=vm_runtime.replace('XEMON_VM',vm_alias)
        vm_runtime=_mangle_identifiers(vm_runtime,vm_names[1:])
        vm_runtime=_compact_lua(vm_runtime)
        callenv='((type(_ENV)=="table" and _ENV) or _G)'
        launch=[]
        if anti_tamper_source:
            at_fn=self._gen_name(); at_ok=self._gen_name(); at_res=self._gen_name()
            launch.append('local '+at_fn+'=function()return '+vm_alias+'('+anti_enc+',((type(_ENV)=="table" and _ENV) or _G));end;')
            launch.append('local '+at_ok+','+at_res+'=pcall('+at_fn+');if not '+at_ok+' then if '+("true" if anti_tamper_debug else "false")+' then print("[Xemon AT VM ERROR] "..tostring('+at_res+')) end;if '+("true" if anti_tamper_strict else "false")+' then return end;elseif '+("true" if anti_tamper_strict else "false")+' and '+at_res+'~=true then return end;')
        userv=self._gen_name()
        launch.append('local '+userv+'='+user_enc+';return '+vm_alias+'('+userv+',((type(_ENV)=="table" and _ENV) or _G));')
        return anti_decl + user_decl + vm_runtime + ''.join(launch)

    def obfuscate_with_report(self, code, include_anti_tamper=True, anti_tamper_debug=False, anti_tamper_strict=False, run_host_smoke=True):
        report = DiagnosticReport(code or "")
        report.stage("INPUT", "PASS", chars=len(code or ""))
        if not code or not code.strip():
            result = "--[[ Obfuscated With Xemon | XVM-5 ]]local _=false;return _"
            report.stage("EMPTY_INPUT", "PASS")
            validate_output(result, report)
            return result, report

        preflight_source(code, report)
        report.stage("PREFLIGHT", "PASS" if not any(i.severity=="ERROR" for i in report.issues if i.stage=="PREFLIGHT") else "FAIL")
        if any(i.severity=="ERROR" for i in report.issues if i.stage=="PREFLIGHT"):
            return None, report

        at_source = None
        if include_anti_tamper:
            at_source = _strip_lua_comments(ANTI_TAMPER_V2)
            at_source = _compact_lua(at_source)
            debug_literal = "true" if anti_tamper_debug else "false"
            strict_literal = "true" if anti_tamper_strict else "false"
            at_source = "local XEMON_AT_DEBUG=" + debug_literal + ";local XEMON_AT_STRICT=" + strict_literal + ";" + at_source
            preflight_source(at_source, report)
            if any(i.severity=="ERROR" for i in report.issues if i.stage=="PREFLIGHT"):
                return None, report
            report.stage("ANTI_TAMPER_COMPILE_INPUT", "PASS", chars=len(at_source), debug=anti_tamper_debug)

        try:
            payload = self._obfuscate_vm_block(code, at_source, anti_tamper_debug=anti_tamper_debug, anti_tamper_strict=anti_tamper_strict, report=report)
            report.stage("BYTECODE_PACK", "PASS")
        except Exception as exc:
            report.issue("ERROR", "COMPILE_FAILURE", "BYTECODE_COMPILE", str(exc))
            report.stage("BYTECODE_PACK", "FAIL")
            return None, report

        result = "--[[ Obfuscated With Xemon | XVM-5 ]]" + _compact_lua(payload)
        report.metrics["output_length"] = len(result)
        report.metrics["output_growth"] = round(len(result) / max(1, len(code)), 3)
        validate_output(result, report)
        if run_host_smoke and not any(i.severity=="ERROR" for i in report.issues):
            smoke_test_generated_lua(result, report)
        return result, report

    def obfuscate(self, code, include_anti_tamper=True, anti_tamper_debug=False, anti_tamper_strict=False):
        result, report = self.obfuscate_with_report(code, include_anti_tamper, anti_tamper_debug, anti_tamper_strict, run_host_smoke=False)
        if result is None:
            issues = "; ".join(i.message for i in report.issues if i.severity in {"ERROR", "FATAL"})
            raise ValueError(issues or "obfuscation failed")
        validate_generated_lua(result)
        return result
