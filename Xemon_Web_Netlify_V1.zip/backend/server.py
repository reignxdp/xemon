from fastapi import FastAPI, APIRouter, HTTPException
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
import os
import logging
from pathlib import Path
from pydantic import BaseModel
from typing import Optional
from lua_obfuscator import LuaObfuscator

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

app = FastAPI()
api_router = APIRouter(prefix="/api")

class ObfuscateRequest(BaseModel):
    code: str

class ObfuscateResponse(BaseModel):
    obfuscated_code: str
    original_length: int
    obfuscated_length: int
    backend: str = "xvm-5"
    anti_tamper: bool = True
    loadstring_free: bool = True

@api_router.get("/")
async def root():
    return {"message": "Lua Obfuscator API - Extreme Edition"}

@api_router.post("/obfuscate", response_model=ObfuscateResponse)
async def obfuscate_code(request: ObfuscateRequest):
    if not request.code or not request.code.strip():
        raise HTTPException(status_code=400, detail="Code cannot be empty")
    try:
        obfuscator = LuaObfuscator()
        obfuscated = obfuscator.obfuscate(request.code)
        return ObfuscateResponse(
            obfuscated_code=obfuscated,
            original_length=len(request.code),
            obfuscated_length=len(obfuscated),
            backend="xvm-5",
            anti_tamper=True,
            loadstring_free="loadstring" not in obfuscated and "load(" not in obfuscated
        )
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Obfuscation error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Obfuscation failed: {str(e)}")

app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

