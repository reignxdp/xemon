#!/bin/bash
# Start the Discord bot in background with auto-restart
cd /app/backend
while true; do
    echo "[$(date)] Starting xemon bot..."
    /root/.venv/bin/python bot.py >> /var/log/bot.out.log 2>> /var/log/bot.err.log
    echo "[$(date)] Bot crashed, restarting in 5s..."
    sleep 5
done
