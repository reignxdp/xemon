
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from lua_obfuscator import LuaObfuscator
from bytecode_vm import compile_source


def test_bytecode_has_xvm_header():
    blob = compile_source("print(1)")
    assert blob[:5] == b"XVM5\x05"


def test_common_programs_compile():
    samples = [
        "print(1)",
        "local x=2; print(x+3)",
        'local function greet(name) print("Hello, "..name) end greet("World")',
        'local t={a=1,b=2}; print(t.a+t.b)',
        'if 1 < 2 then print("yes") else print("no") end',
        'local x=0; while x < 3 do print(x); x=x+1 end',
    ]
    for src in samples:
        blob = compile_source(src)
        assert blob.startswith(b"XVM5")
        assert len(blob) > 20


def test_output_is_loadstring_free():
    out = LuaObfuscator().obfuscate("print('x')", include_anti_tamper=True)
    assert "loadstring" not in out
    assert not re.search(r"\bload\s*\(", out)
    assert "XVM-5" in out


def test_build_specific_encoding_changes():
    a=compile_source("local secret=123; print(secret)")
    b=compile_source("local secret=123; print(secret)")
    assert a != b
    assert b"secret" not in a


def test_integrity_header_present():
    blob=compile_source("print(1)")
    assert len(blob) > 60
    assert blob[5:21] != bytes(16)


def test_extended_luau_control_flow_compiles():
    samples = [
        "local i=0; repeat i=i+1 until i>=3; print(i)",
        "local i=0; while true do i=i+1; if i>=3 then break end end; print(i)",
        "local s=0; for i=1,5 do if i==3 then continue end; s=s+i end; print(s)",
        "local s=0; for k,v in pairs({a=1,b=2}) do s=s+v end; print(s)",
        "local function f(a,...) return ... end; print(f(1,2,3))",
    ]
    for src in samples:
        blob=compile_source(src)
        assert blob.startswith(b"XVM5")
        assert len(blob) > 30
