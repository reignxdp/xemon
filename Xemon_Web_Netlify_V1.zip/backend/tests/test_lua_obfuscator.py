"""
Lua Obfuscator API Tests
Tests for POST /api/obfuscate endpoint and obfuscation quality
"""
import pytest
import requests
import os
import re
import subprocess

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')

class TestObfuscatorAPI:
    """Tests for the /api/obfuscate endpoint"""
    
    def test_api_root_returns_message(self):
        """Test that API root endpoint returns expected message"""
        response = requests.get(f"{BASE_URL}/api/")
        assert response.status_code == 200
        data = response.json()
        assert "message" in data
        assert "Lua Obfuscator" in data["message"]
        print(f"PASS: API root returns: {data['message']}")
    
    def test_obfuscate_returns_correct_response_shape(self):
        """Test that obfuscate endpoint returns correct response structure"""
        response = requests.post(
            f"{BASE_URL}/api/obfuscate",
            json={"code": "print(1)"}
        )
        assert response.status_code == 200
        data = response.json()
        
        # Verify response shape
        assert "obfuscated_code" in data, "Missing obfuscated_code field"
        assert "original_length" in data, "Missing original_length field"
        assert "obfuscated_length" in data, "Missing obfuscated_length field"
        
        # Verify types
        assert isinstance(data["obfuscated_code"], str)
        assert isinstance(data["original_length"], int)
        assert isinstance(data["obfuscated_length"], int)
        
        print(f"PASS: Response shape correct - original: {data['original_length']}, obfuscated: {data['obfuscated_length']}")
    
    def test_obfuscate_output_50k_plus_chars(self):
        """Test that output is 50k+ characters even for small inputs"""
        response = requests.post(
            f"{BASE_URL}/api/obfuscate",
            json={"code": "print(1)"}
        )
        assert response.status_code == 200
        data = response.json()
        
        obfuscated_length = data["obfuscated_length"]
        assert obfuscated_length >= 50000, f"Output length {obfuscated_length} is less than 50k"
        print(f"PASS: Output length is {obfuscated_length} chars (>= 50k)")
    
    def test_obfuscate_contains_xemon_header(self):
        """Test that output contains xemon header comment"""
        response = requests.post(
            f"{BASE_URL}/api/obfuscate",
            json={"code": "print(1)"}
        )
        assert response.status_code == 200
        data = response.json()
        
        obfuscated = data["obfuscated_code"]
        assert "-- Obfuscated with xemon" in obfuscated, "Missing xemon header"
        print("PASS: Output contains xemon header")
    
    def test_obfuscate_source_code_hidden(self):
        """Test that original source code is completely hidden"""
        original_code = "print('Hello World')"
        response = requests.post(
            f"{BASE_URL}/api/obfuscate",
            json={"code": original_code}
        )
        assert response.status_code == 200
        data = response.json()
        
        obfuscated = data["obfuscated_code"]
        # Check that plaintext from original is not visible
        assert "print('Hello World')" not in obfuscated, "Original code visible in output"
        assert "Hello World" not in obfuscated, "Original string visible in output"
        print("PASS: Source code is completely hidden")
    
    def test_obfuscate_uses_confusing_variable_names(self):
        """Test that output uses confusing variable names (l, 1, I, i pattern)"""
        response = requests.post(
            f"{BASE_URL}/api/obfuscate",
            json={"code": "print(1)"}
        )
        assert response.status_code == 200
        data = response.json()
        
        obfuscated = data["obfuscated_code"]
        # Look for variable names that only contain l, 1, I, i
        confusing_pattern = re.compile(r'\b[lIi][l1Ii]{5,}\b')
        matches = confusing_pattern.findall(obfuscated)
        assert len(matches) > 10, f"Not enough confusing variable names found: {len(matches)}"
        print(f"PASS: Found {len(matches)} confusing variable names")
    
    def test_obfuscate_uses_hex_notation(self):
        """Test that output contains hex notation (0x...)"""
        response = requests.post(
            f"{BASE_URL}/api/obfuscate",
            json={"code": "print(1)"}
        )
        assert response.status_code == 200
        data = response.json()
        
        obfuscated = data["obfuscated_code"]
        hex_pattern = re.compile(r'0x[0-9A-Fa-f]+')
        matches = hex_pattern.findall(obfuscated)
        assert len(matches) > 100, f"Not enough hex literals found: {len(matches)}"
        print(f"PASS: Found {len(matches)} hex literals")
    
    def test_obfuscate_uses_decimal_escape_sequences(self):
        """Test that output contains decimal escape string sequences (\\NNN format)"""
        response = requests.post(
            f"{BASE_URL}/api/obfuscate",
            json={"code": "print(1)"}
        )
        assert response.status_code == 200
        data = response.json()
        
        obfuscated = data["obfuscated_code"]
        # Look for decimal escape sequences like \116\069
        escape_pattern = re.compile(r'\\[0-9]{3}')
        matches = escape_pattern.findall(obfuscated)
        assert len(matches) > 50, f"Not enough decimal escape sequences found: {len(matches)}"
        print(f"PASS: Found {len(matches)} decimal escape sequences")
    
    def test_empty_input_returns_400(self):
        """Test that empty input returns 400 error, not 500"""
        response = requests.post(
            f"{BASE_URL}/api/obfuscate",
            json={"code": ""}
        )
        assert response.status_code == 400, f"Expected 400, got {response.status_code}"
        data = response.json()
        assert "detail" in data
        print(f"PASS: Empty input returns 400 with message: {data['detail']}")
    
    def test_whitespace_only_input_returns_400(self):
        """Test that whitespace-only input returns 400 error, not 500"""
        response = requests.post(
            f"{BASE_URL}/api/obfuscate",
            json={"code": "   \n\t  "}
        )
        assert response.status_code == 400, f"Expected 400, got {response.status_code}"
        data = response.json()
        assert "detail" in data
        print(f"PASS: Whitespace-only input returns 400 with message: {data['detail']}")


class TestLuaSyntaxValidity:
    """Tests for Lua 5.3 syntax validity of obfuscated output"""
    
    def test_obfuscated_code_is_valid_lua53(self):
        """Test that obfuscated code is valid Lua 5.3 syntax"""
        response = requests.post(
            f"{BASE_URL}/api/obfuscate",
            json={"code": "print(1)"}
        )
        assert response.status_code == 200
        data = response.json()
        
        obfuscated = data["obfuscated_code"]
        
        # Write to temp file and run with lua5.3
        with open("/tmp/test_obfuscated.lua", "w") as f:
            f.write(obfuscated)
        
        result = subprocess.run(
            ["/usr/bin/lua5.3", "/tmp/test_obfuscated.lua"],
            capture_output=True,
            text=True,
            timeout=10
        )
        
        assert result.returncode == 0, f"Lua execution failed: {result.stderr}"
        assert result.stdout.strip() == "1", f"Expected output '1', got '{result.stdout.strip()}'"
        print("PASS: Obfuscated code executes correctly in Lua 5.3")
    
    def test_obfuscated_complex_code_executes(self):
        """Test that more complex obfuscated code executes correctly"""
        original_code = """
local function greet(name)
    print("Hello, " .. name)
    return true
end
greet("World")
"""
        response = requests.post(
            f"{BASE_URL}/api/obfuscate",
            json={"code": original_code}
        )
        assert response.status_code == 200
        data = response.json()
        
        obfuscated = data["obfuscated_code"]
        
        with open("/tmp/test_complex.lua", "w") as f:
            f.write(obfuscated)
        
        result = subprocess.run(
            ["/usr/bin/lua5.3", "/tmp/test_complex.lua"],
            capture_output=True,
            text=True,
            timeout=10
        )
        
        assert result.returncode == 0, f"Lua execution failed: {result.stderr}"
        assert "Hello, World" in result.stdout, f"Expected 'Hello, World' in output, got: {result.stdout}"
        print("PASS: Complex obfuscated code executes correctly")
    
    def test_no_binary_literals_in_output(self):
        """Test that output does NOT contain binary literals (0B...) - invalid in Lua 5.3"""
        response = requests.post(
            f"{BASE_URL}/api/obfuscate",
            json={"code": "print(1)"}
        )
        assert response.status_code == 200
        data = response.json()
        
        obfuscated = data["obfuscated_code"]
        binary_pattern = re.compile(r'0[bB][01]+')
        matches = binary_pattern.findall(obfuscated)
        assert len(matches) == 0, f"Found invalid binary literals: {matches[:5]}"
        print("PASS: No binary literals in output (Lua 5.3 compatible)")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
