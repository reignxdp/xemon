import asyncio
import os
import sys
from pathlib import Path

os.environ.setdefault("DISCORD_BOT_TOKEN", "test-token")
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import bot


def run(coro):
    return asyncio.run(coro)


def test_daily_and_bonus_are_separate(monkeypatch, tmp_path):
    path = tmp_path / "xemon_data.json"
    monkeypatch.setattr(bot, "DATA_FILE", path)
    monkeypatch.setattr(bot, "DATA_LOCK", asyncio.Lock())

    async def scenario():
        for _ in range(bot.FREE_DAILY_CREDITS):
            assert await bot.reserve_credit(100)
        assert await bot.reserve_credit(100) is None
        await bot.add_bonus_credits(100, 2)
        assert await bot.reserve_credit(100)
        assert await bot.reserve_credit(100)
        assert await bot.reserve_credit(100) is None
        doc = await bot.get_user_credits(100)
        assert doc["daily_used"] == bot.FREE_DAILY_CREDITS
        assert doc["bonus_credits"] == 0
    run(scenario())


def test_failed_job_can_refund(monkeypatch, tmp_path):
    path = tmp_path / "xemon_data.json"
    monkeypatch.setattr(bot, "DATA_FILE", path)
    monkeypatch.setattr(bot, "DATA_LOCK", asyncio.Lock())

    async def scenario():
        receipt = await bot.reserve_credit(200)
        assert receipt["source"] == "daily"
        assert (await bot.get_user_credits(200))["daily_used"] == 1
        await bot.refund_credit(200, receipt)
        assert (await bot.get_user_credits(200))["daily_used"] == 0
    run(scenario())
