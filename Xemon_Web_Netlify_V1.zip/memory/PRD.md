# XemonObf - Lua Obfuscator PRD

## Original Problem Statement
Discord bot + web frontend Lua obfuscator. Requirements:
1. Proportional file sizes (small code = small output)
2. @# characters must be functional (removing them breaks code)
3. AI-resistant: byte sequences must NOT be statically decodable

## Architecture
- **Backend**: FastAPI (Python) - `/app/backend/server.py`
- **Frontend**: React - `/app/frontend/src/`
- **Core Logic**: `/app/backend/lua_obfuscator.py`
- **Discord Bot**: `/app/backend/bot.py`

## What's Been Implemented

### XOR Encryption (Jan 2026) — AI Resistance
- **Anti-tamper strings**: All 70 functional strings (CFrame, Players, math, etc.) XOR-encrypted with random key
- **Code chunks**: User code bytes XOR-encrypted with separate random key
- **Runtime decoder**: `xdec` function uses `bit32.bxor` + `string.byte` + `string.char` to decode at runtime
- **Bootstrap entries**: Only 5 library names (string, byte, char, bit32, bxor) stored unencoded — needed to build decoder
- **Result**: AI reading byte sequences gets gibberish, not readable strings

### Functional @# Frame Markers
- Every code chunk: `@#` prefix (bytes 64,35) + XOR'd payload + `#@` suffix (bytes 35,64)
- Decoder strips frames with `string.sub(chunk, 3, #chunk-2)`, then XOR-decodes
- Both `@#` bytes and `#` (length operator) are structurally required

### Proportional File Sizing
| Input Size | Output Size | AT Junk | CB Junk |
|------------|------------|---------|---------|
| < 100 chars | ~35 KB | 80 | 25 |
| < 500 chars | ~75 KB | 200 | 60 |
| < 2000 chars | ~95 KB | 500 | 200 |
| 2000+ chars | ~193 KB | 1000 | 500 |

### Core Features
- 31 anti-tamper checks with XOR-encrypted string lookups
- Hidden loadstring via individual byte entries
- Luau register safety with do...end blocks
- Discord bot with credit system
- Web frontend with code editor

## Backlog
- P1: Discord bot token integration
- P2: Frontend UI enhancements
- P3: Multi-layer XOR (different key per chunk)
