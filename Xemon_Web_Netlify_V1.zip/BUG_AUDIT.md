# Xemon XVM-5 Obfuscator Bug Audit

## Scope
Static review of the XVM compiler, bytecode serializer/runtime, generated-Lua validator, Anti-Tamper compilation path, Discord configuration path, and host-Lua smoke tests.

## Findings fixed in this update

| ID | Severity | Area | Finding | Fix |
|---|---|---|---|---|
| XVM-001 | Critical | VM CALL ABI | Multi-return native calls could corrupt multiple assignment state. | CALL now carries argument-count + expected-return-count; multi-assignment uses PACK. |
| XVM-002 | Critical | Compiler | Multiple assignment could evaluate/store values in the wrong order. | RHS is fully materialized before target stores; PACK preserves positional semantics. |
| XVM-003 | High | Compiler | `and` / `or` were eager instead of short-circuiting. | Lowered with DUP + conditional jump. |
| XVM-004 | High | Compiler | Numeric `for` lowering used the generic ITER path and produced nil loop variables. | Added FORPREP/FORSTEP VM instructions and name-pool remapping. |
| XVM-005 | High | Compiler | Compound assignment (`+=`, `-=`, `*=`, `/=`) parsed but ignored its operator semantics. | Explicit lowering to read/operate/store. |
| XVM-006 | High | Runtime | Global lookup used `root[key] or _G[key]`, turning `false` into a missing value. | Nil-sensitive lookup now checks `~= nil`. |
| XVM-007 | High | Runtime | Unsupported generic `for`, `repeat`, `break`, and vararg constructs could reach incomplete lowering. | Strict preflight rejects them with diagnostic codes instead of generating known-bad bytecode. |
| XVM-008 | Medium | Source lexer | Unsupported number forms (exponent/hex-float) could be mis-tokenized. | Preflight rejects them explicitly. |
| XVM-009 | Medium | Generated output | Syntax issues could be discovered only after Roblox execution. | One-line delimiter/operator/string validator runs before output. |
| XVM-010 | Medium | Debugging | Anti-Tamper and VM failures lacked a stage-by-stage report. | Added diagnostic pipeline and `.config obfuscator debug on`. |
| XVM-011 | Medium | Configuration | Anti-Tamper debug existed, but there was no compiler/obfuscator debug switch. | Added persistent per-guild Obfuscator Debug configuration. |
| XVM-012 | Medium | Regression coverage | Several VM semantic paths were not covered by the existing test suite. | Added numeric-for, compound assignment, multi-assignment, short-circuit, pcall multi-return, closure capture, and method tests. |

## Intentionally rejected features

These are not silently emitted anymore:

- generic `for ... in ... do`
- `repeat ... until`
- `break`
- vararg functions / `...`
- long-bracket strings/comments
- exponent-form and hexadecimal floating-point literals
- multiple assignment to indexed targets
- assignment forms requiring more complex multi-return expansion than the current ABI can prove safely

A rejected source now returns a structured diagnostic rather than a later `nil value`, stack corruption, or unrelated Roblox error.

## Remaining compatibility boundary

The host smoke test uses the locally available `luatex --luaonly` runtime. It proves generated Lua can parse/execute in that host runtime; it does **not** prove every Roblox/Luau API behaves identically. Roblox-only Anti-Tamper checks therefore remain environment-dependent. The diagnostic report marks those host-only AT failures as `WARN/AT_ENVIRONMENT_DEPENDENT`, not compiler/runtime errors.

## Current verification

- Existing XVM-5 tests: PASS
- Regression suite: PASS
- Numeric `for`: PASS
- Compound assignment: PASS
- Multiple assignment: PASS
- `pcall` multi-return: PASS
- `and` / `or` short-circuit: PASS
- Closure capture: PASS
- Method call: PASS
- Unsupported-feature diagnostics: PASS
- Generated-Lua validation: PASS
- Anti-Tamper bootstrap smoke tests: PASS
