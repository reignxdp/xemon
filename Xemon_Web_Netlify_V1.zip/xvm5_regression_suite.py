from pathlib import Path
import subprocess, sys, tempfile
sys.path.insert(0, str(Path(__file__).parent / 'backend'))
from lua_obfuscator import LuaObfuscator
from syntax_validator import validate_generated_lua

BASE = Path(__file__).parent
CASES = {
    'basic_print': 'print("x")',
    'closure_params': 'local function f(a)return a+1 end;print(f(2))',
    'table_index': 'local t={a=1};print(t.a)',
    'table_multi': 'local t={a=1,b=2};print(t.a+t.b)',
    'while_loop': 'local x=0;while x<3 do x=x+1 end;print(x)',
    'method_shape': 'local t={f=function(self,x)return x+1 end};print(t:f(2))',
    'numeric_for': 'local s=0;for i=1,5 do s=s+i end;print(s)',
    'compound_assignment': 'local x=5;x+=2;x*=3;print(x)',
    'multi_assignment': 'local a,b=1,2;a,b=b,a;print(a,b)',
    'pcall_multi_return': 'local ok,res=pcall(function() return 7 end);print(type(ok),res,ok)',
    'short_circuit_and': 'local a=false;local b=a and print("BAD");print("OK")',
    'short_circuit_or': 'local a=true;local b=a or print("BAD");print("OK")',
    'closure_capture': 'local x=4;local function f(a)return a+x end;print(f(3))',
    'method_call': 'local t={v=4,f=function(self,x)return self.v+x end};print(t:f(3))',
}


def run_lua(path):
    p = subprocess.run(['luatex', '--luaonly', str(path)], capture_output=True, text=True)
    return p.returncode, p.stdout, p.stderr

obf = LuaObfuscator()
for name, src in CASES.items():
    out = obf.obfuscate(src, include_anti_tamper=False)
    assert len(out.splitlines()) == 1, name
    assert 'loadstring' not in out.lower(), name
    assert 'load(' not in out.lower(), name
    validate_generated_lua(out)
    path = Path(tempfile.gettempdir()) / f'xvm5_{name}.lua'
    path.write_text(out)
    rc, stdout, stderr = run_lua(path)
    assert rc == 0, (name, stderr)

# Anti-tamper bootstrap must not crash the host when Roblox-only APIs are absent.
for i in range(3):
    out = obf.obfuscate('print("x")', include_anti_tamper=True)
    assert len(out.splitlines()) == 1
    assert 'loadstring' not in out.lower()
    assert 'load(' not in out.lower()
    validate_generated_lua(out)
    path = Path(tempfile.gettempdir()) / f'xvm5_at_{i}.lua'
    path.write_text(out)
    rc, stdout, stderr = run_lua(path)
    assert rc == 0, stderr

# Unsupported features must fail early with structured diagnostic codes.
unsupported = {
    'generic_for': 'for k,v in pairs({a=1}) do print(k,v) end',
    'vararg': 'local function f(...) return 1 end',
    'repeat': 'repeat print(1) until true',
}
for name, src in unsupported.items():
    result, report = obf.obfuscate_with_report(src, include_anti_tamper=False, run_host_smoke=False)
    assert result is None, name
    assert report.issues and report.issues[0].severity == 'ERROR', name

# Debug report must include all major pipeline stages.
result, report = obf.obfuscate_with_report('print("debug-ok")', include_anti_tamper=True, anti_tamper_debug=True, run_host_smoke=True)
assert result is not None and report.ok
stage_names = [s['stage'] for s in report.stages]
for required in ('INPUT','PREFLIGHT','BYTECODE_USER','BYTECODE_PACK','GENERATED_LUA_VALIDATE','HOST_LUA_SMOKE'):
    assert required in stage_names, required

# Two builds must differ.
a = obf.obfuscate(CASES['closure_params'], False)
b = obf.obfuscate(CASES['closure_params'], False)
assert a != b

print('XVM-5 regression suite: PASS')
print('cases:', len(CASES))
print('anti_tamper_bootstrap: 3/3 PASS')
print('unsupported_feature_diagnostics: 3/3 PASS')
print('debug_report_pipeline: PASS')
print('polymorphism: PASS')
