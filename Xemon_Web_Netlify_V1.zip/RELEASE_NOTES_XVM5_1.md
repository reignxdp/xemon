# Xemon XVM-5.1

## Compiler/runtime
- Added `repeat ... until` lowering.
- Added `break` and loop-aware `continue` lowering.
- Added generic `for ... in` iterator ABI with Lua iterator triple support.
- Added vararg functions and `...` argument expansion.
- Added return-all-varargs handling for `return ...`.
- Expanded opcode map from 41 to 42 canonical opcodes and updated XVM5 decoding offsets.

## Discord bot
- Daily and bonus credits are separate pools.
- Credit reservation is atomic within the bot process.
- Failed obfuscation automatically refunds the reserved credit.
- Added per-user success/failure counters, character statistics and history.
- Added `.daily`, `.stats`, `.history`, `.ping`, `.about`, `.setcredits`, `.resetcredits`.
- Premium gifting now has a daily quota; owner gifting remains unlimited.
- Added file-size limits, command cooldown and clearer failure handling.

## Security / packaging
- Production `.env` is excluded from the release archive.
- Added `backend/.env.example`.
