# Xemon Web

Static Netlify frontend for Xemon XVM-5.1. No user login is required.

## Local

```bash
npm install
REACT_APP_BACKEND_URL=http://localhost:8000 npm start
```

## Netlify

The repository root contains `netlify.toml`. Set `REACT_APP_BACKEND_URL` to the public HTTPS API endpoint.
