import "@/App.css";
import { Toaster } from "@/components/ui/sonner";
import ObfuscatorApp from "@/components/ObfuscatorApp";

function App() {
  return (
    <div className="App">
      <ObfuscatorApp />
      <Toaster position="top-right" theme="dark" />
    </div>
  );
}

export default App;
