import React, { useEffect, useState } from 'react';
import { Light as SyntaxHighlighter } from 'react-syntax-highlighter';
import lua from 'react-syntax-highlighter/dist/esm/languages/hljs/lua';
import { atomOneDark } from 'react-syntax-highlighter/dist/esm/styles/hljs';

SyntaxHighlighter.registerLanguage('lua', lua);

const CodeEditor = ({ title, value, onChange, placeholder, readOnly = false, testId }) => {
  const [lines, setLines] = useState(0);
  const [chars, setChars] = useState(0);

  useEffect(() => {
    if (value) {
      setLines(value.split('\n').length);
      setChars(value.length);
    } else {
      setLines(0);
      setChars(0);
    }
  }, [value]);

  return (
    <div className="relative flex flex-col h-full bg-zinc-950">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-zinc-800 bg-zinc-900/50">
        <div>
          <h2 className="text-lg sm:text-xl font-semibold tracking-tight text-zinc-100">{title}</h2>
        </div>
        <div className="flex items-center gap-4 text-xs font-mono text-zinc-400">
          <span>{lines} lines</span>
          <span className="text-zinc-700">•</span>
          <span>{chars} chars</span>
        </div>
      </div>

      {/* Editor */}
      <div className="flex-1 overflow-hidden relative">
        {value ? (
          <div className="h-full overflow-auto">
            <SyntaxHighlighter
              language="lua"
              style={atomOneDark}
              customStyle={{
                margin: 0,
                padding: '1rem',
                background: 'transparent',
                fontSize: '0.875rem',
                lineHeight: '1.5',
                fontFamily: '"JetBrains Mono", monospace',
                height: '100%'
              }}
              showLineNumbers
              wrapLines
            >
              {value}
            </SyntaxHighlighter>
          </div>
        ) : null}
        
        <textarea
          data-testid={testId}
          value={value}
          onChange={(e) => !readOnly && onChange(e.target.value)}
          placeholder={placeholder}
          readOnly={readOnly}
          disabled={readOnly}
          className={`absolute inset-0 w-full h-full resize-none bg-transparent p-4 font-mono text-sm text-zinc-300 focus:outline-none focus:ring-0 selection:bg-emerald-500/30 ${value ? 'opacity-0 pointer-events-none' : 'opacity-100'} ${readOnly ? 'cursor-not-allowed' : ''}`}
          spellCheck={false}
        />
      </div>
    </div>
  );
};

export default CodeEditor;
