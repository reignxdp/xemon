import React, { useMemo, useState } from 'react';
import axios from 'axios';
import { toast } from 'sonner';
import { Code2, Copy, Download, FileCode2, Github, Info, Menu, Play, ShieldCheck, Sparkles, Trash2, X, Zap } from 'lucide-react';
import CodeEditor from './CodeEditor';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL || '';
const API = `${BACKEND_URL.replace(/\/$/, '')}/api`;

const EXAMPLE = `-- Xemon / Luau\nlocal function greet(name, ...)\n    print("Hello, " .. name)\n    return true, ...\nend\n\nfor i, value in ipairs({"X", "V", "M"}) do\n    print(i, value)\nend\n\ngreet("World", 1, 2, 3)`;

const ObfuscatorApp = () => {
  const [inputCode, setInputCode] = useState(EXAMPLE);
  const [outputCode, setOutputCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [mobileInfo, setMobileInfo] = useState(false);
  const [level, setLevel] = useState('Extreme');
  const [stats, setStats] = useState(null);

  const inputStats = useMemo(() => ({
    lines: inputCode ? inputCode.split('\n').length : 0,
    chars: inputCode.length,
  }), [inputCode]);

  const outputStats = useMemo(() => ({
    lines: outputCode ? outputCode.split('\n').length : 0,
    chars: outputCode.length,
  }), [outputCode]);

  const handleObfuscate = async () => {
    if (!inputCode.trim()) return toast.error('Paste some Luau code first.');
    if (inputCode.length > 500_000) return toast.error('Maximum source size is 500 KB.');
    setLoading(true);
    setStats(null);
    try {
      const response = await axios.post(`${API}/obfuscate`, { code: inputCode }, { timeout: 60000 });
      setOutputCode(response.data.obfuscated_code || '');
      setStats(response.data);
      toast.success('Obfuscation complete', { description: `${response.data.original_length} → ${response.data.obfuscated_length} characters` });
    } catch (error) {
      toast.error('Obfuscation failed', { description: error.response?.data?.detail || error.message });
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = async () => {
    if (!outputCode) return toast.error('Nothing to copy.');
    await navigator.clipboard.writeText(outputCode);
    toast.success('Output copied.');
  };

  const handleDownload = () => {
    if (!outputCode) return toast.error('Nothing to download.');
    const blob = new Blob([outputCode], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'xemon-obfuscated.lua';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  const clear = () => { setInputCode(''); setOutputCode(''); setStats(null); };

  return (
    <div className="min-h-screen bg-[#07090b] text-zinc-100 selection:bg-emerald-400/30">
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(circle_at_20%_0%,rgba(16,185,129,.11),transparent_32%),radial-gradient(circle_at_90%_20%,rgba(34,197,94,.06),transparent_28%)]" />
      <header className="sticky top-0 z-30 border-b border-white/5 bg-[#07090b]/85 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-[1500px] items-center justify-between px-4 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="grid h-9 w-9 place-items-center rounded-lg border border-emerald-400/20 bg-emerald-400/10 text-emerald-300"><Zap size={18} /></div>
            <div><div className="font-semibold tracking-tight">Xemon</div><div className="text-[10px] uppercase tracking-[.24em] text-zinc-500">XVM · Luau Enhanced</div></div>
          </div>
          <nav className="hidden items-center gap-6 text-sm text-zinc-400 sm:flex">
            <a href="#workspace" className="hover:text-white">Obfuscator</a>
            <a href="#features" className="hover:text-white">Features</a>
            <a href="#about" className="hover:text-white">About</a>
            <a href="https://github.com" target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 hover:text-white"><Github size={15}/> GitHub</a>
          </nav>
          <button onClick={() => setMobileInfo(!mobileInfo)} className="rounded-lg border border-white/10 p-2 text-zinc-400 sm:hidden">{mobileInfo ? <X size={18}/> : <Menu size={18}/>}</button>
        </div>
        {mobileInfo && <div className="border-t border-white/5 px-4 py-3 sm:hidden"><a href="#workspace" className="mr-5 text-sm text-zinc-300">Obfuscator</a><a href="#features" className="text-sm text-zinc-300">Features</a></div>}
      </header>

      <main className="relative mx-auto max-w-[1500px] px-4 pb-20 pt-10 sm:px-6 sm:pt-14">
        <section className="mx-auto max-w-4xl text-center">
          <div className="mx-auto mb-5 inline-flex items-center gap-2 rounded-full border border-emerald-400/15 bg-emerald-400/5 px-3 py-1.5 text-xs font-medium text-emerald-300"><Sparkles size={14}/> Free · No account required</div>
          <h1 className="text-4xl font-semibold tracking-[-.04em] text-white sm:text-6xl">Protect your Luau code.</h1>
          <p className="mx-auto mt-5 max-w-2xl text-sm leading-6 text-zinc-400 sm:text-base">Xemon turns Luau source into VM-protected output with XVM-5.1, integrity checks and modern Luau compatibility.</p>
        </section>

        <section id="workspace" className="mt-10 overflow-hidden rounded-2xl border border-white/8 bg-[#0b0e11] shadow-2xl shadow-black/30">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/6 px-4 py-3 sm:px-5">
            <div className="flex items-center gap-2"><FileCode2 size={17} className="text-emerald-300"/><span className="text-sm font-medium">Obfuscator</span><span className="rounded-md border border-white/8 bg-white/[.03] px-2 py-0.5 text-[10px] uppercase tracking-wider text-zinc-500">XVM-5.1</span></div>
            <div className="flex items-center gap-2">
              <select value={level} onChange={e => setLevel(e.target.value)} className="rounded-lg border border-white/10 bg-[#080a0c] px-3 py-2 text-xs text-zinc-300 outline-none"><option>Extreme</option><option>Standard</option><option>Lite</option></select>
              <button onClick={clear} className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 px-3 py-2 text-xs text-zinc-400 hover:bg-white/5 hover:text-white"><Trash2 size={14}/> Clear</button>
            </div>
          </div>

          <div className="grid min-h-[560px] grid-cols-1 lg:grid-cols-2 lg:divide-x lg:divide-white/6">
            <CodeEditor title="Source" value={inputCode} onChange={setInputCode} placeholder="Paste Luau code..." testId="code-input-textarea" />
            <CodeEditor title="Protected output" value={outputCode} onChange={setOutputCode} placeholder="Your protected output will appear here..." readOnly testId="code-output-textarea" />
          </div>

          <div className="flex flex-col gap-3 border-t border-white/6 bg-white/[.015] p-4 sm:flex-row sm:items-center sm:justify-between sm:px-5">
            <div className="flex flex-wrap gap-x-5 gap-y-1 text-[11px] text-zinc-500"><span>{inputStats.lines} input lines</span><span>{inputStats.chars.toLocaleString()} input chars</span>{stats && <span className="text-emerald-300">{stats.anti_tamper ? 'Integrity enabled' : 'Integrity disabled'}</span>}{outputCode && <span>{outputStats.chars.toLocaleString()} output chars</span>}</div>
            <div className="flex flex-wrap gap-2">
              <button onClick={handleCopy} disabled={!outputCode} className="inline-flex items-center justify-center gap-2 rounded-lg border border-white/10 px-4 py-2.5 text-xs font-medium text-zinc-300 transition hover:bg-white/5 disabled:cursor-not-allowed disabled:opacity-35"><Copy size={15}/> Copy</button>
              <button onClick={handleDownload} disabled={!outputCode} className="inline-flex items-center justify-center gap-2 rounded-lg border border-white/10 px-4 py-2.5 text-xs font-medium text-zinc-300 transition hover:bg-white/5 disabled:cursor-not-allowed disabled:opacity-35"><Download size={15}/> Download</button>
              <button onClick={handleObfuscate} disabled={loading} className="inline-flex min-w-36 items-center justify-center gap-2 rounded-lg bg-emerald-400 px-5 py-2.5 text-xs font-semibold text-black transition hover:bg-emerald-300 disabled:cursor-wait disabled:opacity-60"><Play size={15} fill="currentColor"/>{loading ? 'Processing…' : `Obfuscate · ${level}`}</button>
            </div>
          </div>
        </section>

        <section id="features" className="mt-16 grid gap-3 md:grid-cols-3">
          {[['VM protection','XVM bytecode keeps the execution path away from the browser.'],['Luau ready','Modern control flow and vararg syntax are handled by XVM-5.1.'],['No account','The first version stays frictionless: open, paste, protect, download.']].map(([title, text]) => <div key={title} className="rounded-xl border border-white/7 bg-white/[.02] p-5"><ShieldCheck size={18} className="mb-4 text-emerald-300"/><h3 className="text-sm font-semibold">{title}</h3><p className="mt-2 text-xs leading-5 text-zinc-500">{text}</p></div>)}
        </section>

        <section id="about" className="mt-10 flex flex-col gap-3 rounded-xl border border-white/7 bg-white/[.02] p-5 sm:flex-row sm:items-center sm:justify-between"><div className="flex gap-3"><Info size={17} className="mt-0.5 text-zinc-500"/><p className="max-w-3xl text-xs leading-5 text-zinc-500">Xemon is currently running as a frontend shell. The production API URL is configured with <code className="text-zinc-300">REACT_APP_BACKEND_URL</code>; keep the XVM engine server-side when deploying.</p></div><Code2 size={20} className="hidden text-zinc-700 sm:block"/></section>
      </main>
      <footer className="border-t border-white/5 px-6 py-8 text-center text-[11px] text-zinc-600">Xemon · XVM-5.1 Luau Enhanced</footer>
    </div>
  );
};

export default ObfuscatorApp;
