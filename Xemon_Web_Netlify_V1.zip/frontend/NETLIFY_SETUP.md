# Xemon Netlify deployment

1. Push this repository to GitHub.
2. In Netlify, choose **Add new project → Import an existing project** and select the GitHub repository.
3. Netlify will read `netlify.toml` automatically.
4. Add environment variable `REACT_APP_BACKEND_URL` with the public HTTPS URL of the Xemon API.
5. Deploy.

The frontend does not require user login. Keep the XVM engine on the API host; never expose the backend source or secrets through the frontend build.
