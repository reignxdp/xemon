import requests
import re

def debug_local_count():
    """Debug the local count issue by examining the obfuscated output"""
    
    # Get obfuscated code
    url = "https://integrity-validator.preview.emergentagent.com/api/obfuscate"
    response = requests.post(url, json={"code": 'print("test")'})
    
    if response.status_code != 200:
        print(f"Error: {response.status_code}")
        return
    
    obfuscated = response.json()['obfuscated_code']
    
    print("=== DEBUGGING LOCAL COUNT ===")
    
    # 1. Count all local declarations
    all_locals = re.findall(r'local\s+\w+', obfuscated)
    print(f"Total local declarations: {len(all_locals)}")
    
    # 2. Count locals inside do...end blocks
    do_blocks = re.findall(r'do\s+(.*?)end;', obfuscated, re.DOTALL)
    locals_in_do_blocks = 0
    for block in do_blocks:
        block_locals = re.findall(r'local\s+\w+', block)
        locals_in_do_blocks += len(block_locals)
    
    print(f"Locals inside do...end blocks: {locals_in_do_blocks}")
    print(f"Locals outside do...end blocks: {len(all_locals) - locals_in_do_blocks}")
    
    # 3. Show first few do...end blocks
    print(f"\nFound {len(do_blocks)} do...end blocks")
    for i, block in enumerate(do_blocks[:3]):
        block_locals = re.findall(r'local\s+\w+', block)
        print(f"Block {i+1}: {len(block_locals)} locals")
        print(f"  Content preview: {block[:100]}...")
    
    # 4. Show some top-level locals
    code_without_do = re.sub(r'do\s+.*?end;', '', obfuscated, flags=re.DOTALL)
    top_level_locals = re.findall(r'local\s+(\w+)', code_without_do)
    print(f"\nFirst 10 top-level locals: {top_level_locals[:10]}")
    
    # 5. Check for specific patterns that might be causing issues
    # Look for locals that should be wrapped but aren't
    junk_local_pattern = r'local\s+[lIi1]+\s*='
    junk_locals = re.findall(junk_local_pattern, code_without_do)
    print(f"Potential unwrapped junk locals: {len(junk_locals)}")
    
    # 6. Check the structure around anti-tamper code
    anti_tamper_locals = re.findall(r'local\s+(\w+)\s*=.*?(?:getfenv|pcall)', code_without_do)
    print(f"Anti-tamper related locals: {len(anti_tamper_locals)}")
    print(f"Anti-tamper locals: {anti_tamper_locals[:10]}")

if __name__ == "__main__":
    debug_local_count()