# Xemon XVM-5 — Final Compatibility & Bug Audit

## Executive summary

The previous Roblox `attempt to call a nil value`, `XVM call target`, silent Anti-Tamper stop, and XVM header/integrity regressions were caused by several independent VM/compiler boundary problems rather than a single syntax issue.

This update focuses on correctness first. Obfuscation features remain enabled, but the runtime now fails with diagnostic context instead of producing malformed bytecode or silently stopping the user program.

## Fixed issues

1. **Script environment resolution**
   - Runtime now prefers the actual script environment through `getfenv(1)` when available, then `_ENV`, then `_G`.
   - This is important because Roblox/Luau exposes a large set of globals through the script environment. Luau still supports `getfenv` for backward compatibility. See Luau compatibility documentation.

2. **Falsey global/local lookup**
   - `getv()` no longer treats `false` as a missing value.
   - Frame-local declarations are tracked explicitly, preventing writes to a global when a local currently contains `nil`.

3. **Native callable bridge**
   - Native Lua/Luau functions are called through a protected adapter.
   - XVM closures passed into native APIs such as `pcall`/event connections are converted into real Lua functions.
   - Callable objects with `__call` are supported with protected metamethod lookup.

4. **Indexed access diagnostics**
   - `GETIDX` and `SETIDX` now provide deterministic errors for nil targets and protect the underlying property/index operation with `pcall`.

5. **Anti-Tamper false positives**
   - Environment probes are advisory by default.
   - Anti-Tamper no longer kills the user program solely because an environment probe fails.
   - A separate `strict` setting is available when hard-fail semantics are desired.

6. **Anti-Tamper debug visibility**
   - Debug mode prints the failing test IDs.
   - VM bootstrap errors are surfaced as `[Xemon AT VM ERROR] ...` instead of disappearing inside `pcall`.

7. **Function/closure ABI**
   - Parameter slots use a stable internal ABI.
   - Closure environments preserve tracked locals.
   - Native callback adapters preserve closure behavior across the Lua/VM boundary.

8. **Multiple returns / assignments**
   - CALL return counts are carried in the bytecode instruction.
   - `PACK` normalizes multiple-return assignment handling.
   - Final-call expansion in return and assignment contexts is accounted for.

9. **Numeric `for`**
   - Added explicit `FORPREP`/`FORSTEP` VM instructions.
   - Name-pool permutation now remaps loop variable operands.

10. **Table literals and indexed assignment**
    - Table literal insertion preserves the table on the stack.
    - Assignment target evaluation order matches Lua semantics for indexed targets.

11. **One-line/syntax safety**
    - Generated output continues to be one line.
    - Delimiter/string/comment balancing is checked.
    - Legacy/dynamic compilation tokens are scanned.
    - Bare Lua-5.3-style `~`, `&`, `|`, shifts, and `//` are rejected from the generated output.

12. **Unsupported feature handling**
    - Generic `for`, `break`, `repeat/until`, `continue`, varargs, Luau type declarations, `export type`, and `::` casts are rejected by diagnostics instead of being lowered into invalid bytecode.

## Verification

- Python compile check: PASS
- Existing XVM tests: **10/10 PASS**
- Regression suite: PASS
- Regression semantic cases: **14**
- Anti-Tamper bootstrap cases: **3/3 PASS**
- Unsupported-feature diagnostic cases: **3/3 PASS**
- Polymorphism test: PASS
- Generated-output stress test: **360/360 PASS** across 30 builds × 12 programs
- One-line invariant: PASS across stress output
- Bare bitwise `~` scan: PASS across stress output
- Host mock-Roblox smoke: user code successfully executed after Anti-Tamper diagnostics; environment-only probe failures were reported instead of terminating the program.

## Important Roblox compatibility note

The host container cannot execute the Roblox engine itself. The mock test validates the XVM/compiler boundary and the fact that environment-probe failures no longer suppress user execution; it does not certify every Roblox engine API.

Roblox documents Luau as its Lua-derived scripting language and exposes globals, classes, callbacks, and libraries through the engine runtime. The current task library and global APIs should therefore be treated as platform-specific integration points rather than ordinary Lua tables/functions.

## Recommended debug configuration

```text
.config obfuscator debug on
.config antitamper debug on
.config antitamper strict off
```

Use `strict on` only when intentional hard-fail Anti-Tamper behavior is desired.
