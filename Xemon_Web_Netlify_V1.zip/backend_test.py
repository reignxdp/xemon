#!/usr/bin/env python3
"""
Comprehensive backend test for Lua Obfuscator API
Tests all specified features including @# frame markers functionality
"""

import requests
import sys
import re
from datetime import datetime

class LuaObfuscatorTester:
    def __init__(self, base_url="https://dense-script.preview.emergentagent.com"):
        self.base_url = base_url
        self.api_url = f"{base_url}/api"
        self.tests_run = 0
        self.tests_passed = 0
        self.failed_tests = []
        self.test_results = []

    def log_test(self, name, success, details=""):
        """Log test result"""
        self.tests_run += 1
        if success:
            self.tests_passed += 1
            print(f"✅ {name} - PASSED")
        else:
            print(f"❌ {name} - FAILED: {details}")
            self.failed_tests.append(f"{name}: {details}")
        
        self.test_results.append({
            "test": name,
            "passed": success,
            "details": details
        })
        return success

    def test_api_root(self):
        """Test GET /api/ returns API info"""
        try:
            response = requests.get(f"{self.api_url}/", timeout=10)
            success = response.status_code == 200
            if success:
                data = response.json()
                expected_msg = "Lua Obfuscator API - Extreme Edition"
                success = data.get("message") == expected_msg
                details = f"Response: {data}" if not success else ""
            else:
                details = f"Status: {response.status_code}"
            return self.log_test("API Root", success, details)
        except Exception as e:
            return self.log_test("API Root", False, str(e))

    def test_empty_code_error(self):
        """Test empty code returns 400 error"""
        try:
            response = requests.post(
                f"{self.api_url}/obfuscate",
                json={"code": ""},
                timeout=10
            )
            success = response.status_code == 400
            details = f"Status: {response.status_code}" if not success else ""
            return self.log_test("Empty code error", success, details)
        except Exception as e:
            return self.log_test("Empty code error", False, str(e))

    def test_whitespace_only_code_error(self):
        """Test whitespace-only code returns 400 error"""
        try:
            response = requests.post(
                f"{self.api_url}/obfuscate",
                json={"code": "   \n\t  "},
                timeout=10
            )
            success = response.status_code == 400
            details = f"Status: {response.status_code}" if not success else ""
            return self.log_test("Whitespace-only code error", success, details)
        except Exception as e:
            return self.log_test("Whitespace-only code error", False, str(e))

    def test_small_code_obfuscation(self):
        """Test small code (<100 chars) produces ~30-35 KB output"""
        small_code = 'print("Hello World")'  # 20 chars
        try:
            response = requests.post(
                f"{self.api_url}/obfuscate",
                json={"code": small_code},
                timeout=15
            )
            if response.status_code != 200:
                return self.log_test("Small code obfuscation", False, f"Status: {response.status_code}")
            
            data = response.json()
            obfuscated = data["obfuscated_code"]
            size_kb = len(obfuscated) / 1024
            
            # Check size is proportional (30-35 KB for small code)
            size_ok = 25 <= size_kb <= 40  # Allow some variance
            
            success = size_ok and len(obfuscated) > len(small_code) * 100
            details = f"Size: {size_kb:.1f} KB (expected 30-35 KB)" if not size_ok else f"Size: {size_kb:.1f} KB"
            
            # Store for frame marker testing
            self.small_obfuscated = obfuscated
            
            return self.log_test("Small code obfuscation", success, details)
        except Exception as e:
            return self.log_test("Small code obfuscation", False, str(e))

    def test_large_code_obfuscation(self):
        """Test large code (5000+ chars) scales proportionally to ~180-200 KB"""
        # Generate large code
        large_code = 'print("Hello World")\n' * 250  # ~5000 chars
        try:
            response = requests.post(
                f"{self.api_url}/obfuscate",
                json={"code": large_code},
                timeout=30
            )
            if response.status_code != 200:
                return self.log_test("Large code obfuscation", False, f"Status: {response.status_code}")
            
            data = response.json()
            obfuscated = data["obfuscated_code"]
            size_kb = len(obfuscated) / 1024
            
            # Check size scales proportionally (180-200 KB for large code)
            size_ok = 150 <= size_kb <= 250  # Allow some variance
            
            success = size_ok and len(obfuscated) > len(large_code) * 20
            details = f"Size: {size_kb:.1f} KB (expected 180-200 KB)" if not size_ok else f"Size: {size_kb:.1f} KB"
            
            # Store for frame marker testing
            self.large_obfuscated = obfuscated
            
            return self.log_test("Large code obfuscation", success, details)
        except Exception as e:
            return self.log_test("Large code obfuscation", False, str(e))

    def test_frame_markers_present(self):
        """Test @# frame markers are present in obfuscated code"""
        if not hasattr(self, 'small_obfuscated'):
            return self.log_test("Frame markers present", False, "No obfuscated code to test")
        
        # Look for \64\35 (=@#) and \35\64 (=#@) byte sequences
        code = self.small_obfuscated
        
        # Count frame marker patterns
        prefix_pattern = r'\\64\\35'  # @# prefix
        suffix_pattern = r'\\35\\64'  # #@ suffix
        
        prefix_count = len(re.findall(prefix_pattern, code))
        suffix_count = len(re.findall(suffix_pattern, code))
        
        # Should have multiple chunks with frame markers
        success = prefix_count > 0 and suffix_count > 0 and prefix_count == suffix_count
        details = f"Prefix markers: {prefix_count}, Suffix markers: {suffix_count}"
        
        return self.log_test("Frame markers present", success, details)

    def test_string_sub_hidden_keys(self):
        """Test hidden 'string' and 'sub' keys are embedded in the table"""
        if not hasattr(self, 'small_obfuscated'):
            return self.log_test("String/sub hidden keys", False, "No obfuscated code to test")
        
        code = self.small_obfuscated
        
        # Look for individual character encodings of "string" and "sub"
        # string = s(115), t(116), r(114), i(105), n(110), g(103)
        # sub = s(115), u(117), b(98)
        
        string_chars = [115, 116, 114, 105, 110, 103]  # "string"
        sub_chars = [115, 117, 98]  # "sub"
        
        string_found = all(f"\\{char}" in code for char in string_chars)
        sub_found = all(f"\\{char}" in code for char in sub_chars)
        
        success = string_found and sub_found
        details = f"String chars found: {string_found}, Sub chars found: {sub_found}"
        
        return self.log_test("String/sub hidden keys", success, details)

    def test_loadstring_hidden(self):
        """Test loadstring is properly hidden in the table"""
        if not hasattr(self, 'small_obfuscated'):
            return self.log_test("Loadstring hidden", False, "No obfuscated code to test")
        
        code = self.small_obfuscated
        
        # Look for individual character encodings of "loadstring"
        # loadstring = l(108), o(111), a(97), d(100), s(115), t(116), r(114), i(105), n(110), g(103)
        loadstring_chars = [108, 111, 97, 100, 115, 116, 114, 105, 110, 103]
        
        # Check if loadstring appears as plain text (should not)
        plain_loadstring = "loadstring" in code
        
        # Check if individual chars are encoded
        chars_encoded = all(f"\\{char}" in code for char in loadstring_chars)
        
        success = not plain_loadstring and chars_encoded
        details = f"Plain loadstring found: {plain_loadstring}, Chars encoded: {chars_encoded}"
        
        return self.log_test("Loadstring hidden", success, details)

    def test_anti_tamper_checks(self):
        """Test all 31 anti-tamper checks are present"""
        if not hasattr(self, 'small_obfuscated'):
            return self.log_test("Anti-tamper checks", False, "No obfuscated code to test")
        
        code = self.small_obfuscated
        
        # Look for anti-tamper check patterns - check for numbers 1-31 in function calls
        found_checks = 0
        for i in range(1, 32):  # 1-31
            if f'({i})' in code:
                found_checks += 1
        
        # Also check for performance/timing checks (101, 102)
        perf_checks = 0
        if '(101)' in code:
            perf_checks += 1
        if '(102)' in code:
            perf_checks += 1
        
        # Should have most of the 31 checks plus performance checks
        success = found_checks >= 25  # Allow some variance
        details = f"Found {found_checks}/31 anti-tamper checks, {perf_checks}/2 performance checks"
        
        return self.log_test("Anti-tamper checks", success, details)

    def test_decoder_functionality(self):
        """Test decoder function uses string.sub with # (length) operator"""
        if not hasattr(self, 'small_obfuscated'):
            return self.log_test("Decoder functionality", False, "No obfuscated code to test")
        
        code = self.small_obfuscated
        
        # Look for decoder pattern that uses string.sub with length operator
        # Pattern should include: string.sub(chunk, 3, #chunk-2)
        # In obfuscated form this might appear as variables but the structure should be there
        
        # Look for the key patterns:
        # 1. Use of # (length operator)
        # 2. Subtraction by 2 (to remove 2-byte suffix)
        # 3. Starting from position 3 (to skip 2-byte prefix)
        
        length_op_pattern = r'#[a-zA-Z_][a-zA-Z0-9_]*-0x2'  # #var-2 pattern
        start_pos_pattern = r'0x3,'  # Starting position 3
        
        length_op_found = bool(re.search(length_op_pattern, code))
        start_pos_found = start_pos_pattern in code
        
        success = length_op_found and start_pos_found
        details = f"Length operator found: {length_op_found}, Start pos 3 found: {start_pos_found}"
        
        return self.log_test("Decoder functionality", success, details)

    def test_functional_frame_markers(self):
        """Test that @# frame markers are functional (removing them breaks execution)"""
        if not hasattr(self, 'small_obfuscated'):
            return self.log_test("Functional frame markers", False, "No obfuscated code to test")
        
        code = self.small_obfuscated
        
        # The key test is that the decoder MUST use string.sub to strip the frame markers
        # If we find the decoder pattern, the frame markers are functional
        
        # Look for the specific decoder pattern that strips @# frames
        # The decoder should call string.sub(chunk, 3, #chunk-2)
        # This strips 2 bytes from start (64,35) and 2 bytes from end (35,64)
        
        # Pattern: variable assignment with string.sub call
        decoder_pattern = r'[a-zA-Z_][a-zA-Z0-9_]*\.\.[a-zA-Z_][a-zA-Z0-9_]*\([a-zA-Z_][a-zA-Z0-9_]*,0x3,#[a-zA-Z_][a-zA-Z0-9_]*-0x2\)'
        
        functional_decoder = bool(re.search(decoder_pattern, code))
        
        # Also check that frame markers are actually present in the data
        frame_markers_in_data = '\\64\\35' in code and '\\35\\64' in code
        
        success = functional_decoder and frame_markers_in_data
        details = f"Functional decoder: {functional_decoder}, Frame markers in data: {frame_markers_in_data}"
        
        return self.log_test("Functional frame markers", success, details)

    def run_all_tests(self):
        """Run all tests and return summary"""
        print("🚀 Starting Lua Obfuscator Backend Tests")
        print("=" * 50)
        
        # Basic API tests
        self.test_api_root()
        self.test_empty_code_error()
        self.test_whitespace_only_code_error()
        
        # Obfuscation functionality tests
        self.test_small_code_obfuscation()
        self.test_large_code_obfuscation()
        
        # Frame marker and decoder tests
        self.test_frame_markers_present()
        self.test_string_sub_hidden_keys()
        self.test_loadstring_hidden()
        self.test_anti_tamper_checks()
        self.test_decoder_functionality()
        self.test_functional_frame_markers()
        
        print("=" * 50)
        print(f"📊 Test Results: {self.tests_passed}/{self.tests_run} passed")
        
        if self.tests_passed == self.tests_run:
            print("🎉 All tests passed!")
            return True
        else:
            print("❌ Some tests failed")
            for failure in self.failed_tests:
                print(f"  - {failure}")
            return False

def main():
    tester = LuaObfuscatorTester()
    success = tester.run_all_tests()
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())