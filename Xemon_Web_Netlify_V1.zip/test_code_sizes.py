import requests
import re

def test_different_code_sizes():
    """Test with different code sizes to see if local count scales"""
    
    test_cases = [
        ('print("small")', "Small code"),
        ('for i=1,10 do print(i) end', "Medium code"),
        ('function test() local x = 5; for i=1,100 do x = x + i end; return x end; test()', "Large code")
    ]
    
    url = "https://integrity-validator.preview.emergentagent.com/api/obfuscate"
    
    for code, description in test_cases:
        print(f"\n=== {description} ===")
        print(f"Input: {code}")
        
        response = requests.post(url, json={"code": code})
        
        if response.status_code != 200:
            print(f"Error: {response.status_code}")
            continue
        
        obfuscated = response.json()['obfuscated_code']
        
        # Count locals
        all_locals = re.findall(r'local\s+\w+', obfuscated)
        
        # Count locals in do...end blocks
        do_blocks = re.findall(r'do\s+(.*?)end;', obfuscated, re.DOTALL)
        locals_in_do_blocks = 0
        for block in do_blocks:
            block_locals = re.findall(r'local\s+\w+', block)
            locals_in_do_blocks += len(block_locals)
        
        top_level_locals = len(all_locals) - locals_in_do_blocks
        
        print(f"Total locals: {len(all_locals)}")
        print(f"Locals in do...end: {locals_in_do_blocks}")
        print(f"Top-level locals: {top_level_locals}")
        print(f"Luau limit check: {'✅ PASS' if top_level_locals < 200 else '❌ FAIL'}")
        print(f"Do...end blocks: {len(do_blocks)}")

if __name__ == "__main__":
    test_different_code_sizes()