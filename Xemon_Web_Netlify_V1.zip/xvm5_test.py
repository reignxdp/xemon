from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parent / 'backend'))
from lua_obfuscator import LuaObfuscator
from bytecode_vm import compile_source
from anti_tamper_v2 import ANTI_TAMPER_V2

samples = [
    'print(1+2)',
    'local x=1; local y=2; print(x+y)',
    'local function f(a,b) return a*b end; print(f(3,4))',
    'local t={a=1,b=2}; print(t.a+t.b)',
    'local x=0; while x<3 do x=x+1 end; print(x)',
    'local s="hello"; if s=="hello" then print(s) else print("no") end',
]
for src in samples:
    blob = compile_source(src)
    assert blob[:4] == b'XVM5'

at_blob = compile_source(ANTI_TAMPER_V2)
assert at_blob[:4] == b'XVM5'

obf = LuaObfuscator().obfuscate(samples[2], include_anti_tamper=True)
assert len(obf.splitlines()) == 1
assert 'loadstring' not in obf
assert 'load(' not in obf
assert 'secret' not in obf
assert 'Detected Virtual Machine' not in obf
assert 'test(7' not in obf

other = LuaObfuscator().obfuscate(samples[2], include_anti_tamper=True)
assert obf != other
print('XVM-5 tests: 10/10 passed')
print('output_length:', len(obf))
